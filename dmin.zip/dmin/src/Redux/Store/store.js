import { configureStore } from "@reduxjs/toolkit";

import gameReducer from "../Slices/GameSlice";
import authReducer from '../Slices/authSlice';
export const store = configureStore({
reducer:{

    game:gameReducer,
    auth:authReducer,
}
}) 