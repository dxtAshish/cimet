import React from 'react';

const MenuCard = ({ data }) => {
  return (
    <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 p-4">
      {data.map((item) => (
        <div 
          key={item._id} 
          className="bg-white rounded-lg shadow-lg overflow-hidden transform transition duration-300 hover:scale-105 hover:shadow-2xl"
        >
          <div className="md:flex">
            {/* Image Section */}
            <div className="md:w-1/3">
              <img 
                src={item.thumbnail || "https://via.placeholder.com/150"} 
                className="w-full h-48 object-cover md:h-full" 
                alt={item.title} 
              />
            </div>

            {/* Details Section */}
            <div className="md:w-2/3 p-4 flex flex-col justify-between">
              <div>
                <h2 className="font-bold text-xl text-gray-800 mb-2">{item.title}</h2> 
                <p className="text-gray-600 mb-4">{item.description}</p> 
              </div>
              <div className="flex justify-between items-center">
                <h3 className="font-bold text-lg text-gray-800">{`₹${item.price}`}</h3>
                <button className="bg-green-500 text-white px-3 py-1 rounded-full hover:bg-green-600 transition duration-200">
                  Add to Cart
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default MenuCard;
