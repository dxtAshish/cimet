export const validateRegister = (formData) => {
  const errors = {};

  if (!formData.fullName.trim()) {
    errors.fullName = 'Full name is required';
  } else if (!/^[a-zA-Z\s'-]+$/.test(formData.fullName)) {
    errors.fullName = 'Full name must contain only letters, spaces, hyphens, or apostrophes';
  }

  if (!formData.email) {
    errors.email = 'Email is required';
  } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(formData.email)) {
    errors.email = 'Email address is invalid';
  }

  if (!formData.password) {
    errors.password = 'Password is required';
  } else if (formData.password.length < 6) {
    errors.password = 'Password must be at least 6 characters';
  }

  if (!formData.confirmPassword) {
    errors.confirmPassword = 'Confirm Password is required';
  } else if (formData.password !== formData.confirmPassword) {
    errors.confirmPassword = 'Passwords do not match';
  }

  return errors;
};

export const validateLogin = (email, password) => {
  const errors = {};

  if (!email) {
    errors.email = 'Email is required';
  } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(email)) {
    errors.email = 'Email address is invalid';
  }

  if (!password) {
    errors.password = 'Password is required';
  }

  return errors;
};



export const validateDynamicForm = (formData, fields) => {
  const errors = {};

  fields.forEach((field) => {
    const value = formData[field.key];

  
    if (field.type === "text") {
      if (!value) {
        errors[field.key] = `${field.label} is required`;
      } else if (value.length < 3) {
        errors[field.key] = `${field.label} must be at least 3 characters`;
      } else if (value.length > 100) {
        errors[field.key] = `${field.label} must be less than 100 characters`;
      }
    }

    
    if (field.type === "textarea") {
      if (!value) {
        errors[field.key] = `${field.label} is required`;
      } else if (value.split(" ").length > 50) {
        errors[field.key] = `${field.label} must be under 50 words`;
      }
    }


    if (field.type === "file") {
      if (!value) {
        errors[field.key] = `${field.label} is required`;
      }
    }
  });

  return errors;
};
