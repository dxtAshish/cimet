import React, { useEffect, useState } from 'react';
import { useLoaderData } from 'react-router-dom';
import Card from '../Components/Card';

const Search = () => {
  const [list, setList] = useState([]);
  const data = useLoaderData();

  useEffect(() => {
    setList(data.results);
    console.log(data.results); // Log the fetched data
  }, [data.results]); // Add data.results as a dependency

  return (
    <div className="w-100vw h-100vh bg-[#04152d] pt-[100px] px-[100px] flex flex-wrap justify-between">
      {list.map((item) => (
        <div className="w-1/5 p-2" key={item.id}>
          <Card value={item} />
        </div>
      ))}
    </div>
  );
}

export default Search;
