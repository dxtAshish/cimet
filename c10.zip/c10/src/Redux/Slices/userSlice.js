import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { BaseUrl } from '../../services/API';

// Async Thunks

export const loginUser = createAsyncThunk(
  'users/login',
  async (userData, thunkAPI) => {
    try {
      const response = await axios.post(`${BaseUrl}/users/login`, userData);
      console.log(response);

      // Destructure the response based on the received data
      const { accessToken, user } = response.data.data;
      const { role } = user;

      // Store the token in localStorage
      localStorage.setItem('token', accessToken);
      localStorage.setItem('role', role);


      // Return the relevant data to the Redux state
      return { token: accessToken, user, role };
    } catch (error) {
      // Handle the error by rejecting the thunk with the error message
      return thunkAPI.rejectWithValue(error.response.data);
    }
  }
);


export const registerUser = createAsyncThunk('users/register', async (userData, thunkAPI) => {
    try {
      const response = await axios.post(`${BaseUrl}/users/register`, userData);
      // Directly return the message from the response object
      return response.data.message;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  });
  

export const logoutUser = createAsyncThunk('users/logout', async () => {
  localStorage.removeItem('token');
  return null;  // Optional, just to clear state
});

// Auth Slice
const authSlice = createSlice({
  name: 'auth',
  initialState: {
    user: null,
    token: localStorage.getItem('token') || null,
    status: null,
    registerStatus: null,

    error: null,
    role: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      // Login
      .addCase(loginUser.fulfilled, (state, action) => {
        console.log(action.payload,"successful")
        state.token = action.payload.token;  // Token from response
        state.user = action.payload.user;    // Set user from response
        state.role = action.payload.role;    // Set role from response
        state.status = 'success';            // Update status
        state.error = null;                  // Clear any errors
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.error = action.payload;        // Capture error
        state.status = 'failed';             // Update status
      })
      // Register
      .addCase(registerUser.fulfilled, (state) => {
        state.registerStatus = 'success';            // Registration success
        state.error = null;                  // Clear any errors
      })
      .addCase(registerUser.rejected, (state, action) => {
        state.error = action.payload;        // Capture error
        state.status = 'failed';             // Update status
      })
      // Logout
      .addCase(logoutUser.fulfilled, (state) => {
        state.token = null;                  // Clear token
        state.user = null;                   // Clear user
        state.role = null;                   // Clear role
        state.status = 'logged out';  
        state.registerStatus = 'logged out';         // Update status
        state.error = null;                  // Clear any errors
      });
  }
});

export default authSlice.reducer;
