import axios from "axios";
import { API_OPTIONS } from "../utils/constants";

const API_URLS = [
//  "https://api.themoviedb.org/3/discover/movie/?page=1&sort_by=popularity.desc"
"https://api.themoviedb.org/3/discover/tv?include_adult=false&include_video=false&language=en-US&page=1&sort_by=popularity.desc"

];

export const fetchTvData = async () => {
  const arrayOfPromises = API_URLS.map((url) => axios.get(url, API_OPTIONS));
  const tvData = await Promise.allSettled(arrayOfPromises);
  console.log(tvData)
  return tvData;
};