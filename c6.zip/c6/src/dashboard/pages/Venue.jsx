import React, { useState } from "react";
import DashboardTable from "../components/DashboardTable";
// import DynamicFormModal from "../components/DynamicFormModal";
import DynamicFormModal from "../components/DynamicModal";
import { addVenue } from "../../Redux/Slices/venueSlice";
import { useDispatch } from "react-redux";


const Venue = ({ data }) => {
    const dispatch=useDispatch()
  const [showModal, setShowModal] = useState(false);

  // Define columns for the Venue table
  const columns = [
    { key: "_id", header: "ID" },
    { key: "title", header: "Title" },
    { key: "description", header: "Description" },
    { key: "location", header: "Location" },
    {
      key: "thumbnail",
      header: "Image",
      render: (thumbnail) => <img src={thumbnail} alt="thumbnail" className="h-10 w-10" />,
    },
    {
      key: "menu",
      header: "Menu",
      render: (menu) => <a href={menu} target="_blank" rel="noopener noreferrer">View Menu</a>,
    },
  ];

  // Define actions for each row (optional)
  const actions = [
    {
      label: "Edit",
      className: "bg-blue-500 hover:bg-blue-700",
      onClick: (row) => console.log("Edit", row),
    },
    {
      label: "Delete",
      className: "bg-red-500 hover:bg-red-700",
      onClick: (row) => console.log("Delete", row),
    },
  ];

  // Fields for the modal (this can be dynamic based on your requirements)
  const modalFields = [
    { key: "title", label: "Title", type: "text" },
    { key: "description", label: "Description", type: "textarea" },
    { key: "location", label: "Location", type: "text" },
    { key: "thumbnail", label: "Image", type: "file" },
    { key: "menu", label: "Menu URL", type: "text" },
  ];

  // Handle form submission for adding new venue
  const handleAddNewVenue = (formData) => {
    console.log("New Venue Data:", formData);
    dispatch(addVenue(formData))
    setShowModal(false); // Close the modal after submission
  };

  return (
    <div>
      <h2>Venue Dashboard</h2>
      <button
        className="bg-green-500 text-white px-4 py-2"
        onClick={() => setShowModal(true)}
      >
        Add+
      </button>

      {/* Display the table */}
      <DashboardTable columns={columns} data={data} actions={actions} />

      {/* DynamicFormModal for adding new venue */}
      <DynamicFormModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title="Add New Venue"
        fields={modalFields}
        onSubmit={handleAddNewVenue}
      />
    </div>
  );
};

export default Venue;
