import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom'; 
import { addToCart, deleteFromCart, selectCartProducts } from '../Redux/Slices/cartSlice';

const MenuCard = ({ data }) => {
  const { user } = useSelector((state) => state.user);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const cartProducts = useSelector(selectCartProducts);

  const isInCart = (id) => {
    return cartProducts.some((product) => product._id === id);
  };

  const handleAddToCart = (product) => {
    if (user) {
      dispatch(addToCart(product));
    } else {
      navigate('/login'); 
    }
  };

  if (data.length === 0) {
    return (
      <div className="flex justify-center items-center h-screen">
        <h2 className="text-2xl font-bold text-gray-500">No items in Menu</h2>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 p-4">
      {data.map(({ _id, title, thumbnail, description, price }) => (
        <div 
          key={_id} 
          className="bg-white rounded-lg shadow-lg overflow-hidden transform transition duration-300 hover:scale-105 hover:shadow-2xl"
        >
          <div className="md:flex">
            <div className="md:w-1/3">
              <img 
                src={thumbnail || "https://via.placeholder.com/150"} 
                className="w-full h-48 object-cover md:h-full" 
                alt={title} 
                onError={(e) => { e.target.src = "https://via.placeholder.com/150"; }} 
              />
            </div>
            <div className="md:w-2/3 p-4 flex flex-col justify-between">
              <div>
                <h2 className="font-bold text-xl text-gray-800 mb-2">{title}</h2> 
                <p className="text-gray-600 mb-4">{description}</p> 
              </div>
              <div className="flex justify-between items-center">
                <h3 className="font-bold text-lg text-gray-800">{`₹${price}`}</h3>
                {isInCart(_id) ? (
                  <button
                    onClick={() => dispatch(deleteFromCart(_id))} 
                    className="bg-red-500 text-white px-3 py-1 rounded-full hover:bg-red-600 transition duration-200"
                  >
                    Remove from Cart
                  </button>
                ) : (
                  <button
                    onClick={() => handleAddToCart({ _id, title, thumbnail, description, price })} 
                    className="bg-green-500 text-white px-3 py-1 rounded-full hover:bg-green-600 transition duration-200"
                  >
                    Add to Cart
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default MenuCard;
