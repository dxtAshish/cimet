// src/components/Table.js
import React from 'react';
import { useTable, usePagination } from 'react-table';
import { useState } from 'react';
import Edit from './Edit';
const Table = ({ data = [], columns = [], onEdit, onDelete, isLoading, isError, edit, remove }) => {


  const [isModalOpen, setModalOpen] = useState(false);
  const [itemData, setItemData] = useState(data);

  const handleOpenModal = () => setModalOpen(true);
  const handleCloseModal = () => setModalOpen(false);

  const handleSave = (data) => {
    setItemData(data);
    handleCloseModal();
  };
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    prepareRow,
    page, // Instead of using 'rows', we'll use 'page'
    canPreviousPage,
    canNextPage,
    pageOptions,
    pageCount,
    gotoPage,
    nextPage,
    previousPage,
    setPageSize,
    state: { pageIndex, pageSize },
  } = useTable(
    {
      columns,
      data,
      initialState: { pageIndex: 0, pageSize: 5 }, 
    },
    usePagination 
  );
  
  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (isError) {
    return <div>Error: {isError.message}</div>;
  }

  /////////


  return (
    <div className='container mx-auto p-4'>
      <table {...getTableProps()} className='min-w-full divide-y divide-gray-200 bg-white'>
        <thead className='bg-gray-50'>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(column => (
                <th
                  {...column.getHeaderProps()}
                  className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'
                >
                  {column.render('Header')}
                </th>
              ))}
              <th className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'>
                Actions
              </th>
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()} className='bg-white divide-y divide-gray-200'>
          {page.map(row => { // Use 'page' instead of 'rows' for paginated data
            prepareRow(row);
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => (
                  <td
                    {...cell.getCellProps()}
                    className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'
                  >
                    {cell.render('Cell')}
                  </td>
                ))}
                <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>
                {edit?    <button
        onClick={handleOpenModal}
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
      >
        Edit Item
      </button>:<></>}
      <Edit
       isOpen={isModalOpen}
       onClose={handleCloseModal}
       onSave={handleSave}
       initialData={itemData}
      />
                { remove ? <button
                    onClick={() => onDelete(row.original)}
                    className='bg-red-600 hover:bg-red-900 text-white font-bold py-2 px-4 rounded'
                  >
                    Delete
                  </button>:<></>}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>

      {/* Pagination controls */}
      <div className='flex justify-between items-center mt-4'>
        <div className='flex items-center'>
          <button
            onClick={() => gotoPage(0)}
            disabled={!canPreviousPage}
            className='px-3 py-1 border rounded-l-md'
          >
            {'<<'}
          </button>
          <button
            onClick={() => previousPage()}
            disabled={!canPreviousPage}
            className='px-3 py-1 border'
          >
            {'<'}
          </button>
          <button
            onClick={() => nextPage()}
            disabled={!canNextPage}
            className='px-3 py-1 border'
          >
            {'>'}
          </button>
          <button
            onClick={() => gotoPage(pageCount - 1)}
            disabled={!canNextPage}
            className='px-3 py-1 border rounded-r-md'
          >
            {'>>'}
          </button>
        </div>
        <span className='text-sm'>
          Page{' '}
          <strong>
            {pageIndex + 1} of {pageOptions.length}
          </strong>{' '}
        </span>
        <select
          value={pageSize}
          onChange={e => setPageSize(Number(e.target.value))}
          className='ml-2 border rounded-md p-1'
        >
          {[5, 10, 20].map(size => (
            <option key={size} value={size}>
              Show {size}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};

export default Table;
