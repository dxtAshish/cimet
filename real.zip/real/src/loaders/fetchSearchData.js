
import axios from "axios";
import { API_OPTIONS } from "../utils/constants";

export const fetchSearchData = async (event) => {
    // console.log(event);
  const query = event.params.query;

  const data = await axios.get(
    `https://api.themoviedb.org/3/search/multi?query=${query}&page=1`,
    API_OPTIONS
  );
 
  return data.data;

};