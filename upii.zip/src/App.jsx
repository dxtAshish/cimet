import React from 'react'
import AutoComplete from './component/AutoComplete'

const App = () => {
  return (
    <div>
      <AutoComplete/>
    </div>
  )
}

export default App
