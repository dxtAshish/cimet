import axios from "axios";
import { API_OPTIONS } from "../utils/constants";

export const fetchSingleMovie = async (event) => {
    console.log(event);
  const id = event.params.id;
  console.log(id);
  const data = await axios.get(
    `https://api.themoviedb.org/3/movie/${id}`,
    API_OPTIONS
  );
  
  return data.data;
};