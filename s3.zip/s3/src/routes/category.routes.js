import { Router } from "express";
import { getAllCategory } from "../controllers/category.controller.js";
const router=Router()

router.route("/register").get(getAllCategory)
export default router