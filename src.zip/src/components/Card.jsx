import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useCart } from "../Context/CartContext"; 
import CartButtons from "./CartButtons";

const Card = ({ item }) => {
  const [showButtons, setShowButtons] = useState(false);
  const limitedTitle = item.title.split(" ").slice(0, 3).join(" ");
  const { addToCart } = useCart(); 

  const handleToggle = () => {
    setShowButtons((prev) => !prev);
  };

  return (
    <div className="container mx-4 my-4 w-1/5">
      <div className="w-64 border">
        <Link to={`/products/${item.id}`}>
          <img
            src={item.image}
            className="w-[300px] h-[300px] object-cover"
            alt={item.title}
          />
        </Link>
        <div className="p-4">
          <h5 className="text-sm text-gray-500 font-bold tracking-widest mb-2 uppercase">
            {limitedTitle}.
          </h5>
          <p>${item.price.toFixed(2)}</p>

          {!showButtons ? (
            <button
              onClick={() => {
                addToCart(item);
                handleToggle();
              }}
              className="bg-green-500 hover:bg-green-400 text-white px-4 py-2 inline-block mt-4 rounded"
            >
              Add to cart
            </button>
          ) : (
            <CartButtons id={item.id} />
          )}
        </div>
      </div>
    </div>
  );
};

export default Card;
