
import "./avatarStyle.css";

const AvatarCircle = ({ name, setAvatarArr, color }) => {
  const deleteAvatar = () => {
    setAvatarArr((prev) => prev.filter((item) => item !== name));
  };

  return (
    <div className="avatar-circle" style={{ backgroundColor: color }}>
      <h2>{name[0].toUpperCase()}</h2>
      <span className="cross" onClick={deleteAvatar}>
        &times;
      </span>
    </div>
  );
};

export default AvatarCircle;
