import React from 'react'

const MovieCard = () => {
  return (
    <div className="w-[350px] rounded-[10px] bg-cover bg-center relative ">
    <img
      src="https://image.tmdb.org/t/p/original/cSMdFWmajaX4oUMLx7HEDI84GkP.jpg"
      className="w-full h-auto rounded-[10px]"
      alt="Harry Potter"
    />
    <div>
        <div>

        <p></p>
        <p></p>
        </div>
       <div>
       <button></button>
       <button></button>
       </div>

       <div>
       <div className="w-16 h-16 bg-white rounded-full  flex items-center justify-center">
          <div className="w-[60px] h-[60px] border-[6px] p-2 rounded-full border-[#008000] flex justify-center items-center">
            <p className=" font-medium">7.5</p>
          </div>
        </div>
        <div className="w-16 h-16 bg-white rounded-full  flex items-center justify-center">
          <div className="w-[60px] h-[60px] border-[6px] p-2 rounded-full border-[#008000] flex justify-center items-center">
            <p className=" font-medium">7.5</p>
          </div>
       </div>
  
        
          <h3>OverView</h3>
          <p>Details</p>
          <div>

          </div>
        </div>
    </div>

  </div>
  )
}

export default MovieCard
