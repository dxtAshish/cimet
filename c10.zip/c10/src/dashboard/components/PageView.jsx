import React from 'react';

const PageView = ({ page }) => {
  return (
    <div className="bg-yellow-200 rounded-lg shadow-md p-6">
      {page}
    </div>
  );
};

export default PageView;
