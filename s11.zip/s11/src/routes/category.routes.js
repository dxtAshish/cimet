import { Router } from "express";
import { addCategory, deleteCategory, getAllCategory } from "../controllers/category.controller.js";
import { upload } from "../middlewares/multer.middleware.js";
import { adminRole, jwtVerify } from "../middlewares/auth.middleware.js";

const router = Router();


router.route("/allcategory").get(getAllCategory); 

router.route("/addcategory").post(
  jwtVerify,  
  adminRole,  
  upload.fields([
    {
      name: "thumbnail",
      maxCount: 1,
    },
  ]),
  addCategory
);

router.route("/deletecategory/:id").post(
  jwtVerify,
  adminRole,  
  deleteCategory
);

// router.route("/editcategory").patch(
//   jwtVerify,  
//   adminRole,  
//   editCategory
// );

export default router;
