import React from 'react';
import MenuItem from './MenuItem';

const Menu = ({ pages, onMenuItemClick }) => {
  return (
    <nav className="w-full">
      {pages.map((page) => (
        <MenuItem 
          key={page.id} 
          title={page.name} 
          icon={page.icon} 
          onClick={() => onMenuItemClick(page)}
        />
      ))}
    </nav>
  );
};

export default Menu;
