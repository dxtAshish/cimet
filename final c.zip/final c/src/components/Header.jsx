import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { logoutUser } from "../Redux/Slices/userSlice";
import { setLocation } from "../Redux/Slices/headerSlice";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faLocationDot } from "@fortawesome/free-solid-svg-icons";

const Header = () => {
  const dispatch = useDispatch();
  const { user, token } = useSelector((state) => state.user);
  const { selectedLocation } = useSelector((state) => state.header);

  const isAuthenticated = Boolean(token);
  const role = localStorage.getItem("role");
  const isAdmin = isAuthenticated && role === "admin";

  const handleLogout = () => {
    dispatch(logoutUser());
  };

  const handleLocationChange = (e) => {
    dispatch(setLocation(e.target.value));
  };

  return (
    <header className="antialiased bg-gradient-to-r from-orange-500 to-yellow-400 py-4 px-6 shadow-md">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/">
          <div className="text-2xl font-bold text-white">D X T-Food</div>
        </Link>

        <div className="hidden md:flex items-center space-x-2">
          <FontAwesomeIcon icon={faLocationDot} className="text-yellow-400" />
          <select
            className="bg-gray-100 border border-yellow-300 text-gray-600 p-2 rounded-lg focus:bg-yellow-400"
            value={selectedLocation}
            onChange={handleLocationChange}
          >
            <option value="select" className="bg-yellow-100 text-gray-700">
              Select Location
            </option>
            <option value="Agra" className="bg-yellow-400 text-gray-700">
              Agra
            </option>
            <option value="Delhi" className="bg-yellow-400 text-gray-700">
              Delhi
            </option>
            <option value="Mumbai" className="bg-yellow-400 text-gray-700">
              Mumbai
            </option>
            <option value="Kolkata" className="bg-yellow-400 text-gray-700">
              Kolkata
            </option>
            <option value="Bangalore" className="bg-yellow-400 text-gray-700">
              Bangalore
            </option>
          </select>
        </div>

        <div className="flex items-center space-x-4">
          <Link to="/">
            <div className="text-2xl font-bold text-white hover:underline hover:text-orange-400">
              Home
            </div>
          </Link>
        { user&& <Link to="/cart">
            <div className="text-2xl font-bold text-white hover:underline hover:text-red-400">
              Cart
            </div>
          </Link>
}
          {!isAuthenticated ? (
            <>
              <button className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors">
                <Link to="/login">Login</Link>
              </button>
              <button className="bg-transparent text-orange-600 px-4 py-2 rounded-lg border border-orange-600 hover:bg-orange-50 transition-colors">
                <Link to="/register">SignUp</Link>
              </button>
            </>
          ) : (
            <>
              {isAdmin && (
                <Link to="/dashboard">
                  <button className="bg-transparent text-orange-600 px-4 py-2 rounded-lg border border-orange-600 hover:bg-orange-50 transition-colors">
                    Dashboard
                  </button>
                </Link>
              )}
              <button
                onClick={handleLogout}
                className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600"
              >
                Logout
              </button>
            </>
          )}
        </div>
      </div>

      <div className="md:hidden mt-4 flex items-center space-x-2">
        <FontAwesomeIcon icon={faLocationDot} className="text-yellow-400" />
        <select
          className="bg-gray-100 border border-yellow-300 text-gray-600 p-2 w-full rounded-lg"
          value={selectedLocation}
          onChange={handleLocationChange}
        >
          <option value="select">Select Location</option>
          <option value="Agra">Agra</option>
          <option value="Delhi">Delhi</option>
          <option value="Mumbai">Mumbai</option>
          <option value="Kolkata">Kolkata</option>
          <option value="Bangalore">Bangalore</option>
        </select>
      </div>
    </header>
  );
};

export default Header;
