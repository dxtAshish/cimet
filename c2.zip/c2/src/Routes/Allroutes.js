import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import HomeWrapper from '../pages/wrapper/HomeWrapper';
import Home from '../pages/Home';
import Menu from '../pages/Menu';

const router = createBrowserRouter([
  {
    path: '/',
    element: <HomeWrapper />,
    children: [
      {
        index: true,
        element: <Home />,
      },
      {
        path:"/menu",
        element: <Menu />,
      },
    ],
  },
]);

export const Allroutes = () => {
  return <RouterProvider router={router} />;
};
