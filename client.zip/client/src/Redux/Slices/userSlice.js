import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { BaseUrl } from '../../services/API';


export const loginUser = createAsyncThunk(
  'users/login',
  async (userData, thunkAPI) => {
    try {
      const response = await axios.post(`${BaseUrl}/users/login`, userData);
      console.log(response);

   
      const { accessToken, user } = response.data.data;
      const { role } = user;

      localStorage.setItem('token', accessToken);
      localStorage.setItem('role', role);


      return { token: accessToken, user, role };
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  }
);


export const registerUser = createAsyncThunk('users/register', async (userData, thunkAPI) => {
    try {
      const response = await axios.post(`${BaseUrl}/users/register`, userData);
      return response.data.message;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  });
  

export const logoutUser = createAsyncThunk('users/logout', async () => {
  localStorage.removeItem('token');
  localStorage.removeItem('productsInCart')
  return null;  
});


const authSlice = createSlice({
  name: 'auth',
  initialState: {
    user: null,
    token: localStorage.getItem('token') || null,
    status: null,
    registerStatus: null,

    error: null,
    role: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
     
      .addCase(loginUser.fulfilled, (state, action) => {
        console.log(action.payload,"successful")
        state.token = action.payload.token;  
        state.user = action.payload.user;    
        state.role = action.payload.role;    
        state.status = 'success';           
        state.error = null;                  
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.error = action.payload;        
        state.status = 'failed';             
      })
    
      .addCase(registerUser.fulfilled, (state) => {
        state.registerStatus = 'success';            
        state.error = null;                  
      })
      .addCase(registerUser.rejected, (state, action) => {
        state.error = action.payload;        
        state.status = 'failed';             
      })
  
      .addCase(logoutUser.fulfilled, (state) => {
        state.token = null;                  
        state.user = null;                  
        state.role = null;                   
        state.status = 'logged out';  
        state.registerStatus = 'logged out';         
        state.error = null;                  
      });
  }
});

export default authSlice.reducer;
