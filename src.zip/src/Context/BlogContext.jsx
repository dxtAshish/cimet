import { createContext, useContext, useState } from "react";

export const BlogContext=createContext()
export const blogContextProvider=({children})=>{
const [page,setPage]=useState(1)
    return (
        <BlogContext.Provider value={{page,setPage}}>
            {children}
        </BlogContext.Provider>
    );
}