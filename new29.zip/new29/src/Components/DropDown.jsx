import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useDispatch } from 'react-redux'; // Import useDispatch
import { setGenre } from '../store/slices/movieFilterSlice'; // Import setGenre from your slice

const DropDown = ({ dropDownName, arr }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dispatch = useDispatch(); // Initialize dispatch

  const toggleDropdown = () => {
    setIsOpen((prev) => !prev);
  };

  const closeDropdown = () => {
    setIsOpen(false);
  };

  const handleItemClick = (id) => {
    dispatch(setGenre(id)); // Dispatch setGenre with item.id
    closeDropdown(); // Close dropdown after dispatch
  };

  return (
    <div className="p-2">
      <div className="inline-block relative">
        <button
          onClick={toggleDropdown}
          className="bg-[#173d77] text-white rounded-[50px] font-semibold py-1 px-3 inline-flex items-center justify-between w-[250px]"
        >
          <span className="mr-1 text-[16px] font-light">{dropDownName}</span>
          <div className='flex justify-center items-center'>
            <span className='text-white text-2xl font-light '>|</span>
            <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
              <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
            </svg>
          </div>
        </button>
        {isOpen && (
          <ul className="absolute text-gray-700 pt-1 z-10">
            {arr?.map((item, index) => (
              <li key={index}
                  onClick={() => handleItemClick(item.id)} // Handle item click
                  className="rounded-t bg-gray-200 hover:bg-gray-400 py-2 px-4 block whitespace-no-wrap"
                >
                  {item.name}
                
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default DropDown;
