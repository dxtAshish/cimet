import React, { useState } from 'react';

const upiDomain = ["ybl", "yybl", "oksbi", "okaxis", "paytm", "upi"];

const AutoComplete = () => {
  const [show, setShow] = useState(false);
  const [textInput, setTextInput] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(-1); 

  const handleChange = (e) => {
    const value = e.target.value;
    setTextInput(value);

    const [name, domain] = value.split('@');

    if (value.includes('@')) {
      setShow(true);
    } else {
      setShow(false);
    }
  };

  const handleAddName = (item) => {
    const [name] = textInput.split('@'); 
    setTextInput(`${name}@${item}`); 
    setShow(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("working");
  };

  const handleKeyDown = (e) => {
    const [, domain] = textInput.split('@');

    if (show) {
      const filteredDomains = domain
        ? upiDomain.filter(item =>
            item.toLowerCase().startsWith(domain.toLowerCase())
          )
        : upiDomain;

      if (e.key === 'ArrowDown') {
        setSelectedIndex((prevIndex) => (prevIndex + 1) % filteredDomains.length);
      } else if (e.key === 'ArrowUp') {
        setSelectedIndex((prevIndex) => (prevIndex - 1 + filteredDomains.length) % filteredDomains.length);
      } else if (e.key === 'ArrowRight' && selectedIndex >= 0) {
        handleAddName(filteredDomains[selectedIndex]);
      }
    }
  };

  const [name, domain] = textInput.split('@');

  const filteredDomains = domain
    ? upiDomain.filter(item => item.toLowerCase().startsWith(domain.toLowerCase()))
    : upiDomain;

  return (
    <div style={{ position: 'relative', display: 'inline-block' }}>
      <form action="" onSubmit={handleSubmit}>
        
        <div style={{ position: 'relative' }}>
       
          <span 
            style={{
              position: 'absolute',
              top: -1,
              left: -1,
              
              color: '#aaa', 
              zIndex: 0, 
              pointerEvents: 'none', 
            }}
          >
            {textInput.includes('@') && filteredDomains[0] ? `${name}@${filteredDomains[0]}` : ''}
          </span>
          
          {/* Input field */}
          <input
            type="text"
            className=""
            onChange={handleChange}
            onKeyDown={handleKeyDown}
            value={textInput}
            style={{
              position: 'relative',
              backgroundColor: 'transparent', // Transparent to show span below
              zIndex: 1, 
            }}
          />
        </div>

        <button type="submit">Pay</button>
      </form>

      {show && (
        <ul>
          {filteredDomains.map((item, index) => (
            <li
              key={index}
              onClick={() => handleAddName(item)}
              style={{
                cursor: 'pointer',
                backgroundColor: selectedIndex === index ? '#e0e0e0' : 'transparent',
              }}
            >
              {item}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default AutoComplete;
