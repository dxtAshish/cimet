import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import userRouter from "./routes/user.routes.js";
import venueRouter from "./routes/venue.routes.js";
import categoryRouter from "./routes/category.routes.js";
import cuisineRouter from "./routes/cuisine.routes.js";

const app = express();
app.use(
  cors({
    // origin: "*",
    credential: true,
  })
);
app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static("public"));

app.use("/api/v1/users", userRouter);
app.use("/api/v1/cuisine", cuisineRouter);
app.use("/api/v1/venues", venueRouter);
app.use("/api/v1/category", categoryRouter);
export { app };
