import mongoose, { isValidObjectId } from "mongoose";
import { Venue } from "../models/venue.model.js";
import { ApiError } from "../utils/APIErrors.js";
import { ApiResponse } from "../utils/ApiResponse.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { uploadOnCloudinary, destroyOnCloudinary } from "../utils/Cloudinary.js";
import { Category } from "../models/category.models.js";

// Fetch all venues with pagination, search query, sorting
const getAllVenues = asyncHandler(async (req, res) => {
  let { page = 1, limit = 10, query, sortBy = "createdAt", sortType = "desc" } = req.query;

  page = isNaN(page) || page <= 0 ? 1 : Number(page);
  limit = isNaN(limit) || limit <= 0 ? 10 : Number(limit);

  const pipeline = [];

  // if (isValidObjectId(userId)) {
  //   pipeline.push({
  //     $match: {
  //       owner: new mongoose.Types.ObjectId(userId),
  //     },
  //   });
  // }

  if (query) {
    pipeline.push({
      $match: {
        $or: [
          { title: { $regex: query, $options: "i" } },
          { description: { $regex: query, $options: "i" } },
        ],
      },
    });
  }

  pipeline.push(
    {
      $project: {
        title: 1,
        thumbnail: 1,
        description: 1,
        location: 1,
        menu: 1,
      },
    },
    {
      $sort: {
        [sortBy]: sortType === "asc" ? 1 : -1,
      },
    },
    { $skip: (page - 1) * limit },
    { $limit: limit }
  );

  const venues = await Venue.aggregate(pipeline);
  res.status(200).json(new ApiResponse(200, venues, "Venues fetched successfully"));
});

// Add a new venue
const addVenue = asyncHandler(async (req, res) => {
  const { title, description, location, menu } = req.body;
  const thumbnailLocalPath = req.files?.thumbnail?.[0]?.path;
  console.log(title,description,location,thumbnailLocalPath)
  if (!title || !description || !location || !thumbnailLocalPath) {
    throw new ApiError(400, "Title, description, location, and thumbnail are required");
  }

  const thumbnail = await uploadOnCloudinary(thumbnailLocalPath);
  if (!thumbnail) {
    throw new ApiError(500, "Failed to upload thumbnail");
  }

  const newVenue = await Venue.create({
    thumbnail: thumbnail.url,
    title,
    description,
    location,
    menu,
  });

  res.status(201).json(new ApiResponse(201, newVenue, "Venue add successfully"));
});

// Get a venue by ID
const getVenueById = asyncHandler(async (req, res) => {
  const { venueId } = req.params;

  if (!isValidObjectId(venueId)) {
    throw new ApiError(400, "Invalid venue ID");
  }

  const venue = await Venue.findById(venueId).populate('menu');
  if (!venue) {
    throw new ApiError(404, "Venue not found");
  }

  res.status(200).json(new ApiResponse(200, venue, "Venue fetched successfully"));
});

// Update a venue by ID
const updateVenue = asyncHandler(async (req, res) => {
  const { venueId } = req.params;
  const { title, description, location, menu } = req.body;
  const thumbnailLocalPath = req.files?.thumbnail?.[0]?.path;

  if (!isValidObjectId(venueId)) {
    throw new ApiError(400, "Invalid venue ID");
  }

  const venue = await Venue.findById(venueId);
  if (!venue) {
    throw new ApiError(404, "Venue not found");
  }

  if (!title && !description && !location && !thumbnailLocalPath && !menu) {
    throw new ApiError(400, "Nothing to update");
  }

  const updates = { title, description, location, menu };

  if (thumbnailLocalPath) {
    const thumbnail = await uploadOnCloudinary(thumbnailLocalPath);
    if (!thumbnail) {
      throw new ApiError(500, "Failed to upload thumbnail");
    }
    updates.image = thumbnail.url;
    await destroyOnCloudinary(venue.image); // Clean up old image from Cloudinary
  }

  const updatedVenue = await Venue.findByIdAndUpdate(venueId, updates, { new: true });
  res.status(200).json(new ApiResponse(200, updatedVenue, "Venue updated successfully"));
});

// Delete a venue by ID
const deleteVenue = asyncHandler(async (req, res) => {
  const { venueId } = req.params;

  if (!isValidObjectId(venueId)) {
    throw new ApiError(400, "Invalid venue ID");
  }

  const venue = await Venue.findById(venueId);
  if (!venue) {
    throw new ApiError(404, "Venue not found");
  }

  if (req.user?._id?.toString() !== venue.owner?.toString()) {
    throw new ApiError(403, "Unauthorized access");
  }

  await Venue.findByIdAndDelete(venueId);
  await destroyOnCloudinary(venue.image); // Clean up thumbnail from Cloudinary

  res.status(200).json(new ApiResponse(200, {}, "Venue deleted successfully"));
});

export {
  getAllVenues,
  addVenue,
  getVenueById,
  updateVenue,
  deleteVenue,
};
