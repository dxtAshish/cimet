import request from "supertest";
import mongoose from "mongoose";

import { MongoMemoryServer } from "mongodb-memory-server";
import { app } from "../app.js";
import { Category } from "../models/category.models.js";
import cloudinary from "cloudinary";

let mongoServer;
let adminToken;

beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  const uri = mongoServer.getUri();
  await mongoose.connect(uri);

  await request(app).post("/api/v1/users/register").send({
    fullName: "admin",
    email: "admin@example.com",
    password: "password123",
    role: "admin",
  });

  const response = await request(app).post("/api/v1/users/login").send({
    email: "admin@example.com",
    password: "password123",
  });

  adminToken = response.body.data.accessToken;
});

afterAll(async () => {
  await mongoose.disconnect();
  await mongoServer.stop();
});

describe("Category Controller", () => {
  describe("GET /allcategory", () => {
    beforeEach(async () => {
      await Category.deleteMany({});
      await Category.create({
        dishName: "testingDish",
        thumbnail: "http://banner.jpg",
      });
    });

    it("should return all categories", async () => {
      const response = await request(app).get("/api/v1/category/allcategory");
      expect(response.status).toBe(200);
      expect(response.body.message).toBe("Categories fetched successfully");
      expect(response.body.data.docs.length).toBeGreaterThan(0);
    });

    it("should return 404 if no categories are found", async () => {
      await Category.deleteMany({});
      try {
        const response = await request(app).get("/api/v1/category/allcategory");
      } catch (error) {
        expect(error.statusCode).toBe(404);
        expect(error.message).toBe("No categories found");
      }
    });
  });

  describe("POST /addcategory", () => {
    beforeEach(() => {
      jest.spyOn(cloudinary.uploader, "upload").mockResolvedValue({
        secure_url: "http://example.com/banner.jpg",
      });
    });

    it("should add a new category successfully with an image", async () => {
      const response = await Category.create({
        dishName: "Pasta",
        thumbnail: "https://example.com/pasta.jpg",
      });

      expect(response.thumbnail).toBe("https://example.com/pasta.jpg");
      expect(response.dishName).toBe("Pasta");
    });
  });
  let categoryId;

  describe("DELETE /categories/:id", () => {
    beforeAll(async () => {
      const category = await Category.create({
        dishName: "Pasta",
        thumbnail: "https://example.com/pasta.jpg",
      });
      categoryId = category._id;
    });

    it("should delete a category successfully", async () => {
      const response = await request(app)
        .post(`/api/v1/category/deletecategory/${categoryId}`)
        .set("Authorization", `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.message).toBe("success");
    });

    it("should return 404 if category is not found", async () => {
      const nonExistentId = new mongoose.Types.ObjectId();
      try {
        const response = await request(app)
          .post(`/api/v1/category/deletecategory/${nonExistentId}`)
          .set("Authorization", `Bearer ${adminToken}`);
      } catch (error) {
        expect(error.statusCode).toBe(404);
        expect(error.message).toBe("Category not found");
      }
    });
  });
});

////
