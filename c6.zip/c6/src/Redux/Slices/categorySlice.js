import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

// Base API URL
const BaseUrl = "http://localhost:5000/api/v1";

// Fetch all categories with pagination
// Fetch all categories with pagination
export const fetchAllCategories = createAsyncThunk(
    "categories/fetchAll",
    async ({ page = 1, limit = 10 }, { rejectWithValue }) => {
      try {
        const response = await axios.get(`${BaseUrl}/category/allcategory`, {
          params: { page, limit },
        });
        return response.data.message;  // Accessing `message` which contains the `docs` array
      } catch (error) {
        return rejectWithValue(error.response.data);
      }
    }
  );
  

// Add a new category
export const addCategory = createAsyncThunk(
  "categories/add",
  async (formData, { rejectWithValue }) => {
    try {
    //   const formData = new FormData();
    //   formData.append("dishName", dishName);
    //   formData.append("thumbnail", thumbnail);

      const response = await axios.post(`${BaseUrl}/category/addcategory`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Edit a category by ID
export const editCategory = createAsyncThunk(
  "categories/edit",
  async ({ id, title, image }, { rejectWithValue }) => {
    try {
      const formData = new FormData();
      if (title) formData.append("title", title);
      if (image) formData.append("image", image);

      const response = await axios.put(`${BaseUrl}/categories/edit/${id}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Delete a category by ID
export const deleteCategory = createAsyncThunk(
  "categories/delete",
  async (id, { rejectWithValue }) => {
    try {
      const response = await axios.delete(`${BaseUrl}/categories/delete/${id}`);
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

const categorySlice = createSlice({
  name: "categories",
  initialState: {
    categories: [],
    loading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    // Handle fetchAllCategories
    builder
    .addCase(fetchAllCategories.pending, (state) => {
      state.loading = true;
      state.error = null;
    })
    .addCase(fetchAllCategories.fulfilled, (state, action) => {
      state.loading = false;
      state.categories = action.payload.docs;  // Now referencing `docs` from `message`
    })
    .addCase(fetchAllCategories.rejected, (state, action) => {
      state.loading = false;
      state.error = action.payload;
    });

  // Other actions remain unchanged (addCategory, editCategory, deleteCategory)


    // Handle addCategory
    builder
      .addCase(addCategory.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addCategory.fulfilled, (state, action) => {
        state.loading = false;
        state.categories.push(action.payload);
      })
      .addCase(addCategory.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });

    // Handle editCategory
    builder
      .addCase(editCategory.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(editCategory.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.categories.findIndex((cat) => cat._id === action.payload._id);
        if (index !== -1) {
          state.categories[index] = action.payload;
        }
      })
      .addCase(editCategory.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });

    // Handle deleteCategory
    builder
      .addCase(deleteCategory.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteCategory.fulfilled, (state, action) => {
        state.loading = false;
        state.categories = state.categories.filter((cat) => cat._id !== action.payload._id);
      })
      .addCase(deleteCategory.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export default categorySlice.reducer;
