import { API } from "."

export const fetchAllGames = async () => {
    return await API.get('/gameType');
}
export const editGame = async (data) => {
    return await API.put('/gameType',data);
}
export const deleteGme = async () => {
    return await API.delete('/gameType/:id');
}