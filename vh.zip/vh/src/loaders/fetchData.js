import axios from "axios";
import { API_OPTIONS } from "../utils/constants";


export const fetchPopularData= async()=>{
    const popularData=await axios.get("https://api.themoviedb.org/3/movie/popular",API_OPTIONS)
    console.log(popularData);
    return popularData.data.results
}
export const fetchTrandingData= async()=>{
    const trandingData=await axios.get("https://api.themoviedb.org/3/movie/popular",API_OPTIONS)
    console.log(trandingData);
    return trandingData.data.results
}
export const fetchTopRatedData= async()=>{
    const topRatedData=await axios.get("https://api.themoviedb.org/3/movie/popular",API_OPTIONS)
    console.log(topRatedData);
    return topRatedData.data.results
}
