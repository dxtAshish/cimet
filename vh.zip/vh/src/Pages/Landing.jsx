import React from "react";
import Banner from "../Components/Banner";
import Cards from "../Components/Card";
import Toggle from "../Components/Toggle";
import MovieCard from "../Components/MovieCard";
import Carousel from "../Components/Carousel";
import CircularRange from "../Components/CirculerRange";


const Landing = () => {
  return (
    <div className="bg-blue-950">
      <Banner />

      <Toggle name1={"movie"} name2={"tvshow"} />

      <Carousel />

   <CircularRange value={9}/>


      <MovieCard />
    </div>
  );
};

export default Landing;
