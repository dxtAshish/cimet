import React, { useState } from 'react';
import { Link, useLoaderData } from 'react-router-dom';

const Blog = () => {
    const data = useLoaderData(); 
    const itemsPerPage = 10; 
    const [currentPage, setCurrentPage] = useState(1);

    
    const totalPages = Math.ceil(data.length / itemsPerPage);

    
    const startIndex = (currentPage - 1) * itemsPerPage;
    const currentItems = data.slice(startIndex, startIndex + itemsPerPage);

    const handlePageChange = (page) => {
        setCurrentPage(page);
    };

    return (
        <div>
            {currentItems.map((item) => (
                <Link to={`/blog/${item.id}`}>
                <div key={item.id} className="mb-4 p-4 border border-gray-200 rounded">
                    <h2 className="text-xl font-bold">{item.title.split(" ").slice(0, 10).join(" ")}</h2>
                    <p>{item.content}</p>
                </div>
                </Link>
            ))}
            
            <div className="flex justify-center mt-4">
                {Array.from({ length: totalPages }, (_, index) => (
                    <button
                        key={index + 1}
                        onClick={() => handlePageChange(index + 1)}
                        className={`mx-1 px-3 py-1 border rounded ${currentPage === index + 1 ? 'bg-blue-500 text-white' : 'bg-white text-black'}`}
                    >
                        {index + 1}
                    </button>
                ))}
            </div>
        </div>
    );
}

export default Blog;
