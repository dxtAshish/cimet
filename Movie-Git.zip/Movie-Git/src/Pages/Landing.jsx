import React from 'react'
import Banner from '../Components/Banner'
import Cards from '../Components/Card'
import Toggle from '../Components/Toggle'
import MovieCard from '../Components/MovieCard'
// import Carousel from '../Components/Carousle';
// import vid from "/smiling.mp4"
// import banner1 from "../assets/banner1.jpg";
// import banner2 from "../assets/banner2.jpg";
// import banner3 from "../assets/banner3.jpg";
// import banner4 from "../assets/banner4.jpg";
// import banner5 from "../assets/banner5.jpg";

// const slides =[banner1, banner2, banner3, banner4, banner5];


const Landing = () => {
  return (
    <div>
      <Banner/>
      <div className='flex flex-col'>
      <div className='w-full h-full bg-blue-950 flex justify-center gap-10'>
      <Cards/>
      <Cards/>
      <Cards/>
      <Toggle name1={"movie"} name2={"tvshow"}/>
      </div>
      <div className='w-full h-full bg-blue-950 flex justify-center gap-10'>
      <Cards/>
      <Cards/>
      <Cards/>
      <Toggle name1={"movie"} name2={"tvshow"}/>
      </div>

      <MovieCard/>
      </div>
      
      
     
      
    </div>
  )
}

export default Landing
