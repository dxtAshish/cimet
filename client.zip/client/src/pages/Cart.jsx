import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { increaseQuantity, decreaseQuantity, deleteFromCart, selectCartProducts, selectTotal } from '../Redux/Slices/cartSlice';
import { faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
const CartPage = () => {
  const { user } = useSelector((state) => state.user);

  const cartProducts =  useSelector(selectCartProducts);
  const filterProduct=user?cartProducts:[]
  const total = useSelector(selectTotal); 
  const dispatch = useDispatch();


  if (cartProducts.length === 0) {
    return (
      <div className="flex justify-center items-center h-screen">
        <h2 className="text-2xl font-bold text-gray-500">Your Cart is Empty</h2>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4">
      <h2 className="text-3xl font-bold mb-6 text-center">Food Cart</h2>

      <div className="bg-white shadow-md rounded-lg p-6 gap-10">
        {filterProduct.map((product) => (
          <div key={product._id} className="flex flex-col md:flex-row relative justify-between items-center p-4 border-b-2 rounded-lg  last:border-b-0 border-gray-600 bg-yellow-100 hover:bg-white">
            <div className="flex items-center mb-4 md:mb-0">
              <img src={product.thumbnail} alt={product.title} className="w-20 h-20 object-cover rounded-lg" />
              <div className="ml-4">
                <h3 className="font-bold text-lg">{product.title}</h3>
                <p className="text-gray-600">₹{product.price}</p>
              </div>
            </div>

            <div className="flex items-center absolute right-[150px] mb-4 md:mb-0">
              <button
                onClick={() => dispatch(decreaseQuantity(product._id))}
                className="bg-yellow-300 px-3 py-1 text-gray-800 font-semibold rounded-lg mr-2 transition duration-200 hover:bg-yellow-400"
                disabled={product.quantity <= 1}
              >
                -
              </button>
              <span className="text-lg font-semibold">{product.quantity}</span>
              <button
                onClick={() => dispatch(increaseQuantity(product._id))}
                className="bg-yellow-300 px-3 py-1 text-gray-800 font-semibold rounded-lg ml-2 transition duration-200 hover:bg-yellow-400"
              >
                +
              </button>
            </div>

            <div>
              <button
                onClick={() => dispatch(deleteFromCart(product._id))}
                className="bg-red-200 text-white w-10 h-10  transition rounded-[50%] duration-200 hover:bg-red-300"
              >
               <FontAwesomeIcon icon={faTrash} className="text-red-600 size-4"/>
              </button>
            </div>
          </div>
        ))}

        <div className="flex justify-end mt-6">
          <h3 className="text-xl font-bold">Total: ₹{total}</h3>
        </div>
      </div>
    </div>
  );
};

export default CartPage;
