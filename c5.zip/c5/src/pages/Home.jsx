import React from 'react';
import Category from '../components/Category';
import Card from '../components/Card';

const category = [
  {
    id: 1,
    name: 'Rasgulla',
    image:
      'https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_288,h_360/MERCHANDISING_BANNERS/IMAGES/MERCH/2024/7/2/8f508de7-e0ac-4ba8-b54d-def9db98959e_Rasgulla.png',
  },
  {
    id: 2,
    name: 'Rasgulla',
    image:
      'https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_288,h_360/MERCHANDISING_BANNERS/IMAGES/MERCH/2024/7/2/8f508de7-e0ac-4ba8-b54d-def9db98959e_Rasgulla.png',
  },
  {
    id: 3,
    name: 'Rasgulla',
    image:
      'https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_288,h_360/MERCHANDISING_BANNERS/IMAGES/MERCH/2024/7/2/8f508de7-e0ac-4ba8-b54d-def9db98959e_Rasgulla.png',
  },
  {
    id: 4,
    name: 'Rasgulla',
    image:
      'https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_288,h_360/MERCHANDISING_BANNERS/IMAGES/MERCH/2024/7/2/8f508de7-e0ac-4ba8-b54d-def9db98959e_Rasgulla.png',
  },
  {
    id: 5,
    name: 'Rasgulla',
    image:
      'https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_288,h_360/MERCHANDISING_BANNERS/IMAGES/MERCH/2024/7/2/8f508de7-e0ac-4ba8-b54d-def9db98959e_Rasgulla.png',
  },
];
const venue=[{
  id:1,
  name:"Padmavati Hotel",
  location:"shyam Nagar Jaipur",
  menu:[
    {
      id:1,
      name:"rasgulla",
      description:"this is a sweet desert from our famous shop",
    }
  ],
  image:'https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_288,h_360/MERCHANDISING_BANNERS/IMAGES/MERCH/2024/7/2/8f508de7-e0ac-4ba8-b54d-def9db98959e_Rasgulla.png',
}]

const Home = () => {
  return (
    <div>
    <div className='flex flex-col justify-center items-center'>
      <h1>Category</h1>
      <div className='flex justify-center items-center'>
        {category.map((item) => (
          <Category data={item} key={item.id} />
        ))}
      </div>
    </div>
    <div className='flex flex-col justify-center items-center'>
      <h1>You Like these venues</h1>
      <div className='flex justify-center items-center'>
        {venue.map((item) => (
          <Card data={item} key={item.id} />
        ))}
      </div>
    </div>

    </div>
  );
};

export default Home;
