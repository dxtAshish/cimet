import React from 'react';
import Title from './Title';

const PageView = ({ page }) => {
  return (
    <div className="ml-[230px] p-4">
      <Title text={page.name} />
      <p>This is the content for {page.name} page.</p> {/* Dynamic content */}
    </div>
  );
};

export default PageView;
