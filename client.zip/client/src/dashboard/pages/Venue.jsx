import React, { useState } from "react";
import DashboardTable from "../components/DashboardTable";
import DynamicFormModal from "../components/DynamicModal";
import { addVenue } from "../../Redux/Slices/venueSlice";
import { deleteVenue } from "../../Redux/Slices/venueSlice";
import { useDispatch } from "react-redux";
import MenuListModal from "../components/MenuListModal";
import { faTrash } from "@fortawesome/free-solid-svg-icons";


const Venue = ({ data }) => {
  const dispatch = useDispatch();
  const [showModal, setShowModal] = useState(false);
  const [showMenuModal, setShowMenuModal] = useState(false);
  const [selectedMenu, setSelectedMenu] = useState([]);
  const [selectedVenueId, setSelectedVenueId] = useState(null);

  const columns = [
    { key: "_id", header: "ID" },
    { key: "title", header: "Title" },
    { key: "description", header: "Description" },
    { key: "location", header: "Location" },
    {
      key: "thumbnail",
      header: "Image",
      render: (thumbnail) => (
        <img src={thumbnail} alt="thumbnail" className="h-20 w-20 rounded-lg hover:scale-[2.0]" />
      ),
    },
    {
      key: "menu",
      header: "Menu",
      render: (menu, row) => (
        <button
          className="text-blue-500"
          onClick={() => handleViewMenu(row._id)}
        >
          View Menu
        </button>
      ),
    },
  ];

  const actions = [
    // {
    //     label: "Edit",
    //     className: "bg-blue-500 hover:bg-blue-700",
    //     onClick: (row) => console.log("Edit", row),
    // },
    {
      label: "Delete",
      // className: "bg-red-500 hover:bg-red-700",
      icon:faTrash,
      onClick: (row) => handleDeleteVenue(row._id),
    },
  ];

  const modalFields = [
    { key: "title", label: "Title", type: "text" },
    { key: "description", label: "Description", type: "textarea" },
    { key: "location", label: "Location", type: "text" },
    { key: "thumbnail", label: "Image", type: "file" },
 
  ];

  const handleAddNewVenue = (formData) => {
    console.log("New Venue Data:", formData);
    dispatch(addVenue(formData));
    setShowModal(false);
  };

  const handleDeleteVenue = (id) => {
    console.log(id);
    dispatch(deleteVenue(id));
  };

  const handleViewMenu = (venueId) => {
    const venue = data.find((v) => v._id === venueId);
    setSelectedMenu(venue.menu);
    setSelectedVenueId(venueId);
    setShowMenuModal(true);
  };

  return (
    <div>
      <h2 className="text-gray-800 font-bold text-2xl">Venue Dashboard</h2>
      <button
        className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:shadow-lg hover:from-yellow-500 hover:to-orange-600 transition-all duration-300 ease-in-out mb-2"
        onClick={() => setShowModal(true)}
      >
        Add+
      </button>

      <DashboardTable columns={columns} data={data} actions={actions} />

      <DynamicFormModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title="Add New Venue"
        fields={modalFields}
        onSubmit={handleAddNewVenue}
      />

      <MenuListModal
        isOpen={showMenuModal}
        onClose={() => setShowMenuModal(false)}
        venueId={selectedVenueId}
        menu={selectedMenu}
      />
    </div>
  );
};

export default Venue;
