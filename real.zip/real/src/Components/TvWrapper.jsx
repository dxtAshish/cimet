import React from 'react'
import { Outlet } from 'react-router-dom'

const TvWrapper = () => {
  return (
    <div>
      <Outlet/>
    </div>
  )
}

export default TvWrapper
