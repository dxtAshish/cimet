import { useState } from "react";
import "./modalStyle.css";

const Modal = ({ setToggleModal, setAvatarName, submitAvatarName, avatarName }) => {
  const [text,setText]=useState("")
  const handleChange = (e) => {
    setText(e.target.value);
  };


  const handleSubmit = () => {
    if (text) {
setAvatarName(text);
setAvatarName("");
setToggleModal(false);
    }
  };
  return (
    <div className="modal">
      <span
        className="cross"
        onClick={() => {
          setToggleModal(false);
        }}
      >
        &times;
      </span>
      <div className="heading">Add new Avatar</div>
      <div className="avatarInput">
        <h3 className="">Enter your avatar</h3>
        <input type="text" onChange={handleChange} />
      </div>
      <div className="modal-btn">
        <button
          className="cancel btn"
          onClick={() => {
            setToggleModal(false);
          }}
        >
          cancel
        </button>
        <button className="add btn" onClick={sub}>
          add
        </button>
      </div>
    </div>
  );
};

export default Modal;
