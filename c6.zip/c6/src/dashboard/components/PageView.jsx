import React from 'react';

const PageView = ({ page }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      {page}
    </div>
  );
};

export default PageView;
