import React from 'react'
import Card from '../components/Card'
import { useLoaderData } from 'react-router-dom'

const SingleProduct = () => {
    const data=useLoaderData()
    console.log(data)
  return (
    <div>
     <Card item={data}/>
    </div>
  )
}

export default SingleProduct
