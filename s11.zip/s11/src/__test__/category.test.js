import request from 'supertest';
import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';
import { app } from '../app.js';  // Assuming app is exported from your Express setup
import { Category } from '../models/category.models.js';  // Assuming the Category model is here
import cloudinary from "cloudinary";
import jwt from "jsonwebtoken";
import path from 'path';
import fs from 'fs';

let mongoServer;
let adminToken;

beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  const uri = mongoServer.getUri();
  await mongoose.connect(uri);

  // Register admin user
  await request(app)
    .post('/api/v1/users/register')
    .send({
      fullName: 'admin',
      email: 'admin@example.com',
      password: 'password123',
      role: 'admin'  // Set role to admin
    });

  // Login the admin user
  const response = await request(app)
    .post('/api/v1/users/login')
    .send({
      email: 'admin@example.com',
      password: 'password123',
    });

  // Extract the access token
  adminToken = response.body.data.accessToken;
});

afterAll(async () => {
  await mongoose.disconnect();
  await mongoServer.stop();
});

describe('Category Controller', () => {
  
  describe('GET /allcategory', () => {
    beforeEach(async () => {
      // Clear the collection and insert a sample category
      await Category.deleteMany({});
      await Category.create({
        dishName: "testingDish",
        thumbnail: "http://banner.jpg"
      });
    });

    it('should return all categories', async () => {
      const response = await request(app).get('/api/v1/category/allcategory');
      expect(response.status).toBe(200);
      expect(response.body.message).toBe('Categories fetched successfully');
      expect(response.body.data.docs.length).toBeGreaterThan(0);  // Ensure categories are returned
    });

    it('should return 404 if no categories are found', async () => {
      await Category.deleteMany({});
      const response = await request(app).get('/api/v1/category/allcategory');
      expect(response.status).toBe(404);
      expect(response.body.message).toBe('No categories found');
    });
  });

  // Test for adding a new category
  describe('POST /addcategory', () => {
    beforeEach(() => {
      jest.spyOn(cloudinary.uploader, 'upload').mockResolvedValue({
        secure_url: 'http://example.com/banner.jpg',
      });
    });
  
    it('should add a new category successfully', async () => {
      // Assuming you've moved banner.jpg to __test__/assets/banner.jpg
      const imagePath = path.resolve(__dirname, './assets/banner.jpg');  // Update the path to match your test folder structure
      const imageBuffer = fs.readFileSync(imagePath);  // Read the image
  
      const response = await request(app)
        .post('/api/v1/category/addcategory')
        .set('Authorization', `Bearer ${adminToken}`)
        .field('dishName', 'Pizza')
        .attach('thumbnail', imageBuffer, 'banner.jpg');  // Attach the image buffer
  
      expect(response.status).toBe(201);
      expect(response.body.message).toBe('Category created successfully');
      expect(response.body.data.dishName).toBe('Pizza');
      expect(response.body.data.thumbnail).toBe('http://example.com/banner.jpg');
    });
  
  

    it('should return a 400 error if dishName is missing', async () => {
      const imagePath = path.join(__dirname, 'test-image.jpg');
      const imageBuffer = fs.readFileSync(imagePath);

      const response = await request(app)
        .post('/api/v1/category/addcategory')
        .set('Authorization', `Bearer ${adminToken}`)
        .attach('thumbnail', imageBuffer, "banner.jpg");

      expect(response.status).toBe(400);
      expect(response.body.message).toBe('Category dishName is required');
    });

    it('should return a 400 error if image is missing', async () => {
      const response = await request(app)
        .post('/api/v1/category/addcategory')
        .set('Authorization', `Bearer ${adminToken}`)
        .field('dishName', 'Burger');

      expect(response.status).toBe(400);
      expect(response.body.message).toBe('Category image is required');
    });
  });

  // Test for deleting a category
  describe('DELETE /categories/:id', () => {
    let categoryId;

    beforeEach(async () => {
      const category = await Category.create({
        dishName: 'Pasta',
        thumbnail: 'https://example.com/pasta.jpg',
      });
      categoryId = category._id;
    });

    it('should delete a category successfully', async () => {
      const response = await request(app)
        .delete(`/api/v1/category/deletecategory/${categoryId}`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.message).toBe('Category deleted successfully');
    });

    it('should return 404 if category is not found', async () => {
      const nonExistentId = mongoose.Types.ObjectId();

      const response = await request(app)
        .delete(`/api/v1/category/deletecategory/${nonExistentId}`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(404);
      expect(response.body.message).toBe('Category not found');
    });

    it('should return 400 for invalid category ID', async () => {
      const response = await request(app)
        .delete(`/api/v1/category/deletecategory/invalid-id`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(400);
      expect(response.body.message).toBe('Invalid category ID');
    });
  });
});
