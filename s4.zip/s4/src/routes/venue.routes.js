import { Router } from 'express';
import {
    deleteVenue,
    getVenueById,
    publishAVenue,
    getAllVenues,  
    updateVenue,
} from "../controllers/venue.controller.js"
import { jwtVerify } from "../middlewares/auth.middleware.js";
import {upload} from "../middlewares/multer.middleware.js"


const router = Router();
router.use(jwtVerify); 

router.route("/get-venues").get(jwtVerify, getAllVenues)
router.route("/upload-venue").post(
    jwtVerify,

    upload.fields([

        {
            name: "thumbnail",
            maxCount: 1,
        }
    ]),
    
    publishAVenue
);
    
router
    .route("/c/:venueId")
    .get(getVenueById)
    .delete(jwtVerify, deleteVenue)
    .patch(jwtVerify, upload.single("thumbnail"), updateVenue);

// router.route("/toggle/publish/:videoId").patch(togglePublishStatus);

export default router