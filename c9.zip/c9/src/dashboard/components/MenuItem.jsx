import React from 'react';

const MenuItem = ({ title, icon, onClick }) => {
  return (
    <a
      href="#"
      onClick={onClick}
      className="p-2.5 text-white m-0 -mx-4 border-b border-[#233242] flex items-center hover:bg-[#1a2d3a] transition duration-200 ease-in-out"
    >
      <i className={`fa fa-fw fa-${icon} mr-2`}></i>
      {title}
    </a>
  );
};

export default MenuItem;
