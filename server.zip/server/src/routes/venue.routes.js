import { Router } from "express";
import {
  addVenue,
  getAllVenues,
  deleteVenue,
  getVenueById,
 // updateVenue,
} from "../controllers/venue.controllere.js";
import { upload } from "../middlewares/multer.middleware.js";
import { adminRole, jwtVerify } from "../middlewares/auth.middleware.js";


const router = Router();

router.route("/get-venues").get(getAllVenues);

router.route("/upload-venue").post(
  jwtVerify,  
  adminRole,  
  upload.fields([
    {
      name: "thumbnail",
      maxCount: 1,
    },
  ]),

  addVenue
);

router
  .route("/c/:venueId")
  .get(getVenueById) 
  .delete( jwtVerify,  
    adminRole,   
     deleteVenue) // Only authenticated users can delete a venue
  //.patch(jwtVerify, upload.single("thumbnail"), updateVenue); // Only authenticated users can update a venue

export default router;
