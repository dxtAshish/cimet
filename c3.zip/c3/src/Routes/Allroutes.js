import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import HomeWrapper from '../pages/wrapper/HomeWrapper';
import Home from '../pages/Home';
import Menu from '../pages/Menu';
import Login from "../components/Login.jsx"
import Register from "../components/Register.jsx"

import Dashboard from '../dashboard/Dashboard';

const router = createBrowserRouter([
  {
    path: '/',
    element: <HomeWrapper />,
    children: [
      {
        index: true,
        element: <Home />,
      },
      {
        path:"/menu",
        element: <Menu />,
      },
      {
        path:"/dashboard",
        element: <Dashboard />,
      },
      {
        path:"/login",
        element:<Login/>
      },
      {
        path:"/register",
        element:<Register/>
      }
    ],
  },
]);

export const Allroutes = () => {
  return <RouterProvider router={router} />;
};
