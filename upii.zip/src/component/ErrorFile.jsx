import React from 'react'

const ErrorFile = () => {
  return (
    <div>
      
    </div>
  )
}

export default ErrorFile
