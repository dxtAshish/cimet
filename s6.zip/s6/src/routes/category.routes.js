import { Router } from "express";
import { addCategory, deleteCategory, editCategory, getAllCategory } from "../controllers/category.controller.js";
import { upload } from "../middlewares/multer.middleware.js";
const router=Router()

router.route("/allcategory").get(getAllCategory)
router.route("/addcategory").post(
    upload.fields([
        {
          name: "thumbnail",
          maxCount: 1,
        },]),
    addCategory)
router.route("/deletecategory").post(deleteCategory)
router.route("/editcategory").patch(editCategory)

export default router