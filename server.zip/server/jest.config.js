export default {
    transform: {
      '^.+\\.js$': ['babel-jest', { presets: ['@babel/preset-env'] }],
    },
    extensionsToTreatAsEsm: [],  // Remove '.ts' and '.js'
    testEnvironment: 'node',
    moduleFileExtensions: ['js'],
  };
  