import React from 'react';
import { Link } from "react-router-dom";

const Card = ({ data }) => {
  return (
    <div className="flex flex-wrap">
      {data.map((item) => (
        <Link key={item._id} to="/menu">
          <div className="container mx-4 my-4">
            <div className="w-64 border">
              <img src={item.thumbnail} className="w-full" alt={item.title} />
              <div className="p-4 bg-slate-800">
                <h5 className="text-sm text-gray-500 font-bold tracking-widest mb-2 uppercase">
                  {item.title}
                </h5>
                <p>{item.description}</p>
                <p>{item.location}</p>
              </div>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
};

export default Card;
