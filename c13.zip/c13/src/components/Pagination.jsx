// src/components/Pagination.js

import React from "react";

const Pagination = ({ page, setPage, hasNextPage }) => {
  const handleNextPage = () => setPage((prevPage) => prevPage + 1);
  const handlePrevPage = () => setPage((prevPage) => Math.max(prevPage - 1, 1));

  return (
    <div className="flex justify-between items-center mt-4">
      <button
        onClick={handlePrevPage}
        disabled={page === 1}
        className={`px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:bg-gray-300`}
      >
        Previous
      </button>
      <span className="text-gray-700 font-semibold">Page {page}</span>
      <button
        onClick={handleNextPage}
        disabled={!hasNextPage}
        className={`px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:bg-gray-300`}
      >
        Next
      </button>
    </div>
  );
};

export default Pagination;
