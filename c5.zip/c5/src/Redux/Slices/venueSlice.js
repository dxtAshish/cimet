import { createSlice } from "@reduxjs/toolkit";
const initialState={
    venue:[]
}
 const venueSlice=createSlice({
name:"venue",
initialState,
reducers:{}

 })