import React from 'react'
import Card from '../../component/Card'
const Dashboard = () => {
  return (
    <div className="flex justify-center mt-10">
    <Card 
      title="Card Title" 
      description="This is a description for the card. It provides some details about the content of the card."
     
    />
  </div>
  )
}

export default Dashboard
