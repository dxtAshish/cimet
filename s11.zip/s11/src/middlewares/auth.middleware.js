import { User } from "../models/user.model.js";
import { ApiError } from "../utils/APIErrors.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import jwt from "jsonwebtoken";
export const jwtVerify = asyncHandler(async (req, _, next) => {
  try {
    const token =
      // req.cookies?.accessToken ||
      req.header("Authorization")?.replace("Bearer ", "");
      // console.log(token)
    if (!token) {
      throw new ApiError(401, "unauthorized request");
    }
    const decodeToken = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);
    const user = await User.findById(decodeToken?._id).select(
      "-password -refreshToken"
    );

    if (!user) {
      throw new ApiError(401, "invalid Access token");
    }
    req.user = user;
    next();
  } catch (error) {
    throw new ApiError(401, error?.message || "invalid access token");
  }
});


export const adminRole = (req, _, next) => {
  console.log("User role:", req.user ? req.user.role : "No user found");  // Debugging log

  if (req.user && req.user.role === "admin") {
    return next();
  }
  throw new ApiError(403, "Access denied. Admins only.");
};

