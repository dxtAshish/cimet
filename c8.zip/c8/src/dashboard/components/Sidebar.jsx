import React from 'react';

const Sidebar = ({ children }) => {
  return (
    <div className="w-[230px] h-full bg-[#2A3F54] z-50 flex flex-col">
      {children}
    </div>
  );
};

export default Sidebar;
