
import React from "react";

const CustomButton = ({
    backgroundColor,
    color,
    buttonText,
    welcomeBtn,
    guideBtn,
    getStartedBtn,
}) => {
 
    const baseClasses = `font-bold text-sm cursor-pointer px-5 py-2.5 rounded-md block border-2 border-transparent transition-all duration-300`;
    
   
    const buttonStyles = `
        ${baseClasses} 
        ${backgroundColor ? backgroundColor : "bg-transparent"} 
        ${color ? color : "text-black"} 
        ${welcomeBtn || getStartedBtn ? "mx-auto w-[90%]" : ""}
        ${guideBtn ? "mt-3 w-[90%]" : ""}
        hover:${color ? color : "bg-black"} 
        hover:${backgroundColor ? backgroundColor : "text-white"} 
        hover:border-${backgroundColor ? backgroundColor : "transparent"}
    `;

    return (
        <button className={buttonStyles}>
            {buttonText}
        </button>
    );
};

export default CustomButton;
