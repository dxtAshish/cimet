import React from 'react';

const MenuCard = () => {
  return (

      <div className="bg-white p-2 rounded-lg shadow-xl flex flex-col md:flex-row items-center md:items-start justify-between">
        <div className="mb-4 md:mb-0 md:mr-6">
          <h2 className="font-bold text-2xl text-gray-600">Card w no image</h2>
          <p className="text-gray-500">This is my cool text</p>
        </div>
        <div className="flex-shrink-0">
          <img 
            src="https://via.placeholder.com/150" 
            className="w-full md:w-32 rounded-lg" 
            alt="placeholder"
          />
        </div>
      </div>

  );
};

export default MenuCard;
