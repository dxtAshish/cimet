import mongoose, { Schema } from "mongoose";
import mongooseAggregatePaginate from "mongoose-aggregate-paginate-v2";
const categorySchema = new Schema(
  {
    dishName: {
      type: String,
      required: true,
    },
    thumbnail: {
        type: String,
        required: true,
      },
  },
  {
    timestamps: true,
  }
);
categorySchema.plugin(mongooseAggregatePaginate);
export const Category = mongoose.model("Category", categorySchema);