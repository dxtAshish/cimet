import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App'; // Assuming App component is the root
import reportWebVitals from './reportWebVitals';
import { Allroutes } from './Routes/Allroutes'; // Assuming Allroutes contains your routes
import { store } from './Redux/store'; // Redux store
import { Provider } from 'react-redux'; // Redux Provider

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Provider store={store}>
        <Allroutes />
    </Provider>
  </React.StrictMode>
);

// Measure performance if needed
reportWebVitals();
