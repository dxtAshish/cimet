import dotenv from "dotenv"
import { app } from "./app.js";

import connectDB from "./db/index.js";
// dotenv.config({
//     path:'./.env'
// })
dotenv.config();
connectDB()

const PORT = process.env.PORT || 8080;

console.log(PORT)

app.listen(PORT,()=>{
    console.log(`server is running on port ${PORT}`)
})
// .then(()=>{
//     app.listen(process.env.PORT || 8000,()=>{
//        console.log("server is running") 
//     })
// })
// .catch((err)=>{
//     console.log("mongo db connection failed",err)
//     process.exit(1)
// })

