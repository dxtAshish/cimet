import React, { useEffect } from 'react'
import Table from '../../component/Table'
// import { api } from '../../API'
// import {useSelector, useDispatch } from "react-redux";
// import { getAllGame } from '../../Redux/Slices/GameSlice';
import { useQuery } from 'react-query';
import { fetchAllGames } from '../../API/games';

const dataa = [
  {
    id: 1,
    totalplayer: 4,
    winner: 2,
    poolmoney: 10,
    prize: 5,
  },
  {
    id: 2,
    totalplayer: 3,
    winner: 1,
    poolmoney: 15,
    prize: 7,
  },
  {
    id: 1,
    totalplayer: 4,
    winner: 2,
    poolmoney: 10,
    prize: 5,
  },
  {
    id: 2,
    totalplayer: 3,
    winner: 1,
    poolmoney: 15,
    prize: 7,
  },
  {
    id: 1,
    totalplayer: 4,
    winner: 2,
    poolmoney: 10,
    prize: 5,
  },
  {
    id: 2,
    totalplayer: 3,
    winner: 1,
    poolmoney: 15,
    prize: 7,
  },
  {
    id: 1,
    totalplayer: 4,
    winner: 2,
    poolmoney: 10,
    prize: 5,
  },
  {
    id: 2,
    totalplayer: 3,
    winner: 1,
    poolmoney: 15,
    prize: 7,
  },
  {
    id: 1,
    totalplayer: 4,
    winner: 2,
    poolmoney: 10,
    prize: 5,
  },
  {
    id: 2,
    totalplayer: 3,
    winner: 1,
    poolmoney: 15,
    prize: 7,
  },
  {
    id: 1,
    totalplayer: 4,
    winner: 2,
    poolmoney: 10,
    prize: 5,
  },
  {
    id: 2,
    totalplayer: 3,
    winner: 1,
    poolmoney: 15,
    prize: 7,
  },
  {
    id: 1,
    totalplayer: 4,
    winner: 2,
    poolmoney: 10,
    prize: 5,
  },
  {
    id: 2,
    totalplayer: 3,
    winner: 1,
    poolmoney: 15,
    prize: 7,
  },
  {
    id: 1,
    totalplayer: 4,
    winner: 2,
    poolmoney: 10,
    prize: 5,
  },
  {
    id: 2,
    totalplayer: 3,
    winner: 1,
    poolmoney: 15,
    prize: 7,
  },
  // Add more data as needed
]

const columns = [
  {
    Header: 'ID',
    accessor: 'id',
  },
  {
    Header: 'Entry Fee',
    accessor: 'entry_fee',
  },
  {
    Header: 'name',
    accessor: 'name',
  },
  {
    Header: 'No of players',
    accessor: 'no_of_players',
  },
  {
    Header: 'No of Winners',
    accessor: 'no_of_winners',
  },
  {
    Header: 'Price Pool',
    accessor: 'price_pool',
  },
  {
    Header: 'Winning Amount',
    accessor: 'winning_amount'
  },
  {
    Header: 'Time',
    accessor: 'time'
  }
]

const GameScreen = () => {
  const { data, isLoading, isError, error } = useQuery('gameType', fetchAllGames);
 console.log(data);
  return (
    <div>
      <Table data={data?.data.gameTypes || []}
        columns={columns}
        isLoading={!isLoading}
        isError={isError ? error : null}
        edit={true}
        remove={true}
      />
    </div>
  )
}

export default GameScreen
