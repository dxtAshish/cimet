import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, Link } from 'react-router-dom';
import { registerUser } from '../Redux/Slices/userSlice';
import { validateRegister } from '../utils/validation';

const Register = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState({});

  const dispatch = useDispatch();
  const navigate = useNavigate(); 

  const { registerStatus, error } = useSelector((state) => state.user);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validateRegister(formData);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }


    const { confirmPassword, ...backendData } = formData;
    dispatch(registerUser(backendData));
  };

  useEffect(() => {
    if (registerStatus === 'success') {
      navigate('/login');
    }
  }, [registerStatus, navigate]);

  return (
    <div className="antialiased bg-yellow-200 text-gray-900 font-sans min-h-screen flex items-center justify-center">
      <div className="w-full bg-yellow-400 rounded-xl shadow-lg p-8 m-4 md:max-w-sm md:mx-auto">
        <span className="block w-full text-xl uppercase font-bold mb-4">Register</span>
        
        {registerStatus === 'failed' && <p className="text-red-600 mb-4">{error}</p>}
        
        <form className="mb-4" onSubmit={handleSubmit}>
          <div className="mb-4 md:w-full">
            <label htmlFor="fullName" className="block text-lg mb-1">Name</label>
            <input 
              className="w-full border rounded-lg p-2 outline-none focus:shadow-outline" 
              type="text" 
              name="fullName" 
              id="fullName" 
              value={formData.fullName}
              onChange={handleChange}
              placeholder="Your Name" 
            />
            {errors.fullName && <p className="text-red-600">{errors.fullName}</p>}
          </div>

          <div className="mb-4 md:w-full">
            <label htmlFor="email" className="block text-lg mb-1">Email</label>
            <input 
              className="w-full border rounded-lg p-2 outline-none focus:shadow-outline" 
              type="email" 
              name="email" 
              id="email" 
              value={formData.email}
              onChange={handleChange}
              placeholder="Email" 
            />
            {errors.email && <p className="text-red-600">{errors.email}</p>}
          </div>

          <div className="mb-4 md:w-full">
            <label htmlFor="password" className="block text-lg mb-1">Password</label>
            <input 
              className="w-full border rounded-lg p-2 outline-none focus:shadow-outline" 
              type="password" 
              name="password" 
              id="password" 
              value={formData.password}
              onChange={handleChange}
              placeholder="Password" 
            />
            {errors.password && <p className="text-red-600">{errors.password}</p>}
          </div>

          <div className="mb-4 md:w-full">
            <label htmlFor="confirmPassword" className="block text-lg mb-1">Confirm Password</label>
            <input 
              className="w-full border rounded-lg p-2 outline-none focus:shadow-outline" 
              type="password" 
              name="confirmPassword" 
              id="confirmPassword" 
              value={formData.confirmPassword}
              onChange={handleChange}
              placeholder="Confirm Password" 
            />
            {errors.confirmPassword && <p className="text-red-600">{errors.confirmPassword}</p>}
          </div>

          <button className="bg-green-500 hover:bg-green-700 text-white uppercase text-sm font-semibold px-4 py-2 rounded-lg">
            Register
          </button>
          <p className='text-gray-700 p-2'>already have an account? <Link to="/login" className='text-blue-400 hover:underline'>login</Link></p>
        </form>
      </div>
    </div>
  );
};

export default Register;
