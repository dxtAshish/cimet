import { createBrowserRouter, RouterProvider } from "react-router-dom";
import HomeWrapeer from "./Wrapper/HomeWrapeer";
import Home from "./Pages/Home";
import ProductWrapper from "./Wrapper/ProductWrapper";
import SingleProduct from "./Pages/SingleProduct";
import Products from "./Pages/Products";
import BlogWrapper from "./Wrapper/BlogWrapper";
import SingleBlog from "./Pages/SingleBlog";
import Cart from "./Pages/Cart";
import Contact from "./Pages/Contact";
import Blog from "./Pages/Blog";
import axios from "axios";
const fetchData=async()=>{
  const response=await axios.get("https://fakestoreapi.com/products?limit=4")
  console.log(response.data);
  return response.data
}
const fetchSingleProdcut=async(event)=>{
  const id = event.params.id
  const response=await axios.get(`https://fakestoreapi.com/products/${id}`)


  return response.data
}
const fetchProduct=async()=>{
  const response=await axios.get('https://fakestoreapi.com/products')


  return response.data
}
const fetchBlog=async()=>{
  const response=await axios.get("https://jsonplaceholder.typicode.com/posts")
  // console.log(response)
  return response.data
}
const fetchSingleBlog=async(event)=>{
  const id = event.params.id
  const response=await axios.get(`https://jsonplaceholder.typicode.com/posts/${id}`)
  // console.log(response)
  return response.data

}



const router = createBrowserRouter([
  {
    path: "/",
    element: <HomeWrapeer />,
    children: [
      {
        index: true,
        element: <Home />,
        loader: fetchData,
      },
      {
        path: "/products",
        element: <ProductWrapper />,

        children: [
          {
            path: ":id",
            element: <SingleProduct/>,
            loader:(event)=>fetchSingleProdcut(event)
          },
          {
            index: true,
            element: <Products />,
            loader:fetchProduct,
           
          },
        ],
      },
      {
        path: "/blog",
        element: <BlogWrapper />,
        children: [
     
          {
            index: true,
            element: <Blog />,
            loader: fetchBlog
          },
          {
            path:":id",
            element: <SingleBlog />,
            loader: fetchSingleBlog,
          },
        ],
      },
      {
          path:"/cart",
          element:<Cart/>
      },
      {
         path:"/contact",
         element:<Contact/>
      }

    ],
  },
]);
function App() {
  return <RouterProvider router={router} />;
}

export default App;
