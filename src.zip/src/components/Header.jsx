import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../Context/CartContext';

const Header = () => {
    const {cart}=useCart()
    return (
        <header className="bg-gray-800">
            <nav className="container mx-auto flex justify-between items-center p-4">
                <div className="text-white text-lg font-bold">D X T ecommerce</div>
                <div className="flex space-x-4">
                    <Link to="/cart" className="text-white hover:bg-gray-700 px-3 py-2 rounded"> {`Cart (${cart.length})`}</Link>
                    <Link to="/blog" className="text-white hover:bg-gray-700 px-3 py-2 rounded">Blog</Link>
                    <Link to="/contact" className="text-white hover:bg-gray-700 px-3 py-2 rounded">Contact Us</Link>
                    <Link to="/products" className="text-white hover:bg-gray-700 px-3 py-2 rounded">Product</Link>
                </div>
            </nav>
        </header>
    );
};

export default Header;
