import React from 'react'
import Table from '../../component/Table'
import { useQuery } from 'react-query'
import { fetchAllUsers } from '../../API/users'



const columnss = [
  {
    Header: 'ID',
    accessor: '_id',
  },
  {
    Header: 'NAME',
    accessor: 'name',
  },
  {
    Header: 'PHONE',
    accessor: 'phone',
  },
  {
    Header: 'KYC',
    accessor: "kyc",
  },
  {
    Header: 'Wallet',
    accessor: 'wallet',
  },
]

const Admin = () => {
  const { data, error, isLoading } = useQuery('users', fetchAllUsers);

  return (
      <Table 
        data={data?.data?.data || []} 
        columns={columnss || []} 
        isLoading={isLoading} 
        isError={error ? error : null}
        edit={true}
        remove={true}
      />
      // <Edit/>
  )
}

export default Admin
