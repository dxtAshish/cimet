import React from 'react';

const MenuItem = ({ title, icon, onClick }) => {
  return (
    <div
      
      onClick={onClick}
      className="p-2.5 text-white text-xl font-semibold m-0 -mx-4 border-b border-[#423523] flex items-center hover:bg-[#3f2e18ec] transition duration-200 ease-in-out"
    >
      <i className={`fa fa-fw fa-${icon} mr-2`}></i>
      {title}
    </div>
  );
};

export default MenuItem;
