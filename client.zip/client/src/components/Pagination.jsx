// src/components/Pagination.js

import React from "react";

const Pagination = ({ page, setPage, hasNextPage }) => {
  const handleNextPage = () => setPage((prevPage) => prevPage + 1);
  const handlePrevPage = () => setPage((prevPage) => Math.max(prevPage - 1, 1));

  return (
    <div className="flex justify-center gap-10 items-center mt-4">
      <button
        onClick={handlePrevPage}
        disabled={page === 1}
        className={`px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600 disabled:bg-yellow-900`}
      >
        Previous
      </button>
      <span className="text-gray-700 font-semibold bg-yellow-100 px-4 py-2 rounded-lg"> {page}</span>
      <button
        onClick={handleNextPage}
        disabled={!hasNextPage}
        className={`px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600 disabled:bg-yellow-900`}
      >
        Next
      </button>
    </div>
  );
};

export default Pagination;
