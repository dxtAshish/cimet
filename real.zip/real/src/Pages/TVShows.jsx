import React from "react";
import DropDown from "../Components/DropDown";
import Card from "../Components/Card";
import { useLoaderData } from "react-router-dom";


const TVShows = () => {
 
  const tvData=useLoaderData()
  const tvList=tvData[0].value.data.results
  console.log(tvList)
// console.log(movieData)
  return (
    <div className="w-100vw h-100vh bg-[#04152d] pt-[100px] px-[100px]">
      <div className="flex justify-between items-center h-[100px]">
        <div>
          <p className="text-white text-2xl font-light">Explore TV Shows</p>
        </div>
        <div className="flex justify-center items-center">
          <DropDown dropDownName="Select genres" />
          <DropDown dropDownName="Sort by" />
        </div>
      </div>
      <div className="flex flex-wrap w-full gap-16">
       
      {tvList.map((value) => (
          <Card value={value} key={value.id}/>
        ))}

      </div>
    </div>
  );
};

export default TVShows;

















//////////////////



// import React, { useEffect, useState, useRef } from "react";
// import DropDown from "../Components/DropDown";
// import Card from "../Components/Card";
// import { useLoaderData } from "react-router-dom";

// const Movies = () => {
//   const movieData = useLoaderData();
//   const initialMovieList = movieData[0].value.data.results;
//   const [movieList, setMovieList] = useState(initialMovieList);
//   const [loading, setLoading] = useState(false);
//   const [page, setPage] = useState(1);
//   const observer = useRef();

//   const fetchMoreMovies = async () => {
//     setLoading(true);
//     // Replace with your actual API endpoint
//     const response = await fetch(`YOUR_API_ENDPOINT?page=${page + 1}`);
//     const newMovies = await response.json();
//     setMovieList((prev) => [...prev, ...newMovies.results]);
//     setLoading(false);
//     setPage((prev) => prev + 1);
//   };

//   const lastMovieElementRef = useRef();

//   useEffect(() => {
//     const observerCallback = (entries) => {
//       if (entries[0].isIntersecting && !loading) {
//         fetchMoreMovies();
//       }
//     };

//     if (lastMovieElementRef.current) {
//       observer.current = new IntersectionObserver(observerCallback);
//       observer.current.observe(lastMovieElementRef.current);
//     }

//     return () => {
//       if (observer.current && lastMovieElementRef.current) {
//         observer.current.unobserve(lastMovieElementRef.current);
//       }
//     };
//   }, [loading]);

//   return (
//     <div className="w-100vw h-100vh bg-[#04152d] pt-[100px] px-[100px]">
//       <div className="flex justify-between items-center h-[100px]">
//         <div>
//           <p className="text-white text-2xl font-light">Explore Movies</p>
//         </div>
//         <div className="flex justify-center items-center">
//           <DropDown dropDownName="Select genres" />
//           <DropDown dropDownName="Sort by" />
//         </div>
//       </div>
//       <div className="flex flex-wrap w-full gap-16">
//         {movieList.map((value, index) => {
//           if (movieList.length === index + 1) {
//             return (
//               <div ref={lastMovieElementRef} key={value.id}>
//                 <Card value={value} />
//               </div>
//             );
//           } else {
//             return <Card value={value} key={value.id} />;
//           }
//         })}
//       </div>
//       {loading && <p className="text-white">Loading more movies...</p>}
//     </div>
//   );
// };

// export default Movies;
