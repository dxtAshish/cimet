import React from 'react';
import welcome from "../assets/welcome.png";

const Hero = () => {
    return (
        <div className="relative min-h-[50vh] flex items-center overflow-hidden">
            <div className="container mx-auto px-4">
                <div className="flex justify-center items-center gap-20 md:text-center md:gap-10">
                    {/* Left Section */}
                    <div className="flex-1 text-left">
                        <p className="text-5xl text-yellow-600 font-medium mt-5 mb-4">
                            Welcome to Hungry Web
                        </p>
                        <h1 className="text-[50px] text-gray-900 font-bold mb-6 md:text-4xl">
                            Discover a place where you'll love to Eat.
                        </h1>
                        <p className="text-lg text-gray-700 mb-6 md:text-base">
                            Immerse yourself in the elegant ambiance as you savor each bite, 
                            accompanied by our extensive selection of hand-picked wines and carefully curated cocktails.
                        </p>
                    </div>

                    {/* Right Section with Blob */}
                    <div className="relative flex-[1.25] drop-shadow-custom-red rounded-[50%]">
                        {/* Blob SVG */}
                        <svg
                            className="absolute w-[900px] h-[900px] top-[-40px] right-[-1px] z-0"
                            viewBox="0 0 200 200"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                fill="#FFD700"
                                d="M54.3,-55.2C68.7,-47.4,74.8,-24.6,73.8,-4.2C72.7,16.1,64.5,32.3,50.1,41.7C35.7,51.1,15.1,53.7,-3,56.1C-21.2,58.5,-42.4,60.7,-51.3,51.1C-60.1,41.4,-56.5,19.9,-53.2,1.8C-49.9,-16.4,-46.8,-32.8,-37.9,-40.4C-28.9,-48,-14.4,-46.7,3.3,-50.2C21,-53.7,42,-62.9,54.3,-55.2Z"
                                transform="translate(100 100)"
                            />
                        </svg>

                        {/* Image */}
                        <img
                            src={welcome}
                            alt="welcome"
                            className="relative max-w-full h-auto mb-8 md:max-w-[80%] z-10 shadow-black"
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Hero;
