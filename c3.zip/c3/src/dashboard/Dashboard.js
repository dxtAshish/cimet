import React, { useEffect, useState } from 'react';
import axios from 'axios';
import VenueForm from './VenueForm';
import MenuForm from './MenuForm';

const Dashboard = () => {
  const [venues, setVenues] = useState([]);

  useEffect(() => {
    fetchVenues();
  }, []);

  const fetchVenues = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/venues', {
        headers: { 'x-auth-token': token }
      });
      setVenues(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const deleteVenue = async (id) => {
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:5000/api/venues/${id}`, {
        headers: { 'x-auth-token': token }
      });
      setVenues(venues.filter((venue) => venue._id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="container mx-auto px-4">
      <h1 className="text-4xl font-bold text-center py-8">Admin Dashboard</h1>
      
      <div className="mb-8">
        <VenueForm fetchVenues={fetchVenues} />
      </div>

      <ul className="space-y-6">
        {venues.map((venue) => (
          <li key={venue._id} className="bg-white shadow-md rounded-lg p-6">
            <h2 className="text-2xl font-semibold mb-2">{venue.name}</h2>
            <p className="text-gray-600 mb-2"><strong>Location:</strong> {venue.location}</p>
            <p className="text-gray-600 mb-4"><strong>Description:</strong> {venue.description}</p>

            <div className="mb-4">
              <MenuForm venue={venue} fetchVenues={fetchVenues} />
            </div>

            <button 
              onClick={() => deleteVenue(venue._id)}
              className="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded"
            >
              Delete Venue
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Dashboard;
