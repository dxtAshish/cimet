import React from 'react'

const GenareButton = ({title}) => {
  return (
    <div className='w-auto h-[20px] bg-pink-800 flex items-center text-white font-light text-sm rounded-[5px] px-1 ' >
      {title}
    </div>
  )
}

export default GenareButton
