import React from 'react'
import MovieCard from '../Components/MovieCard'

const Movie = () => {
  return (
    <div>
        <MovieCard/>
    </div>
  )
}

export default Movie
