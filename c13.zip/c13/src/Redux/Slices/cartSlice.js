import { createSlice } from "@reduxjs/toolkit";


const updateCartInLocalStorage = (products) => {
    localStorage.setItem('productsInCart', JSON.stringify(products));
};

const getCartInLocalStorage = () => {
    const products = localStorage.getItem('productsInCart');
    return products ? JSON.parse(products) : [];
};

const calculateTotal = (products) => {
    return products.reduce((acc, product) => acc + (product.quantity * product.price), 0);
};

const cartSlice = createSlice({
    name: 'cart',
    initialState: {
        products: getCartInLocalStorage(),
        total: calculateTotal(getCartInLocalStorage()),
    },
    reducers: {
        addToCart: (state, action) => {
            const productIndex = state.products.findIndex(product => product._id === action.payload._id);

     
            if (productIndex === -1) {
                state.products.push({ ...action.payload, quantity: 1 });
            } else {
             
                state.products[productIndex].quantity += 1;
            }

        
            state.total = calculateTotal(state.products);
            updateCartInLocalStorage(state.products);
        },

        deleteFromCart: (state, action) => {
            // Remove the product from the cart
            state.products = state.products.filter(product => product._id !== action.payload);

            // Recalculate the total and update localStorage
            state.total = calculateTotal(state.products);
            updateCartInLocalStorage(state.products);
        },

        increaseQuantity: (state, action) => {
            const product = state.products.find(product => product._id === action.payload);

            // Increase the product's quantity if it exists
            if (product) {
                product.quantity += 1;
            }

            // Recalculate the total and update localStorage
            state.total = calculateTotal(state.products);
            updateCartInLocalStorage(state.products);
        },

        decreaseQuantity: (state, action) => {
            const product = state.products.find(product => product._id === action.payload);

            // Decrease the quantity only if it's greater than 1
            if (product && product.quantity > 1) {
                product.quantity -= 1;
            }

            // Recalculate the total and update localStorage
            state.total = calculateTotal(state.products);
            updateCartInLocalStorage(state.products);
        }
    }
});

// Exporting actions
export const { addToCart, deleteFromCart, increaseQuantity, decreaseQuantity } = cartSlice.actions;

// Selectors to get the cart data and total price
export const selectCartProducts = (state) => state.cart.products;
export const selectTotal = (state) => state.cart.total;

export default cartSlice.reducer;
