import axios from "axios";
import { API_OPTIONS } from "../utils/constants";

const API_URLS = [
//  "https://api.themoviedb.org/3/discover/movie/?page=1&sort_by=popularity.desc"
"https://api.themoviedb.org/3/discover/movie?include_adult=false&include_video=false&language=en-US&page=1&sort_by=popularity.desc"

];

export const fetchMovieData = async () => {
  const arrayOfPromises = API_URLS.map((url) => axios.get(url, API_OPTIONS));
  const movieData = await Promise.allSettled(arrayOfPromises);
  console.log(movieData)
  return movieData;
};