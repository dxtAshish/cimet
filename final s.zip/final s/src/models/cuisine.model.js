import mongoose, { Schema } from "mongoose";
import mongooseAggregatePaginate from "mongoose-aggregate-paginate-v2";
const cuisineSchema = new Schema(
  {

    title: {
      type: String,
      required: true,
    },
    thumbnail: {
        type: String,
        required: true,
      },
     
    description: {
      type: String,
      required: true,
    },
      price: {
      type: Number,
      required: true,
    },
    venue:{
        type:Schema.Types.ObjectId,
        ref:"Venue"
    },
    category:{
      type: String,
      required: true,
    }
  },
  {
    timestamps: true,
  }
);
cuisineSchema.plugin(mongooseAggregatePaginate);
export const Cuisine = mongoose.model("Cuisine", cuisineSchema);