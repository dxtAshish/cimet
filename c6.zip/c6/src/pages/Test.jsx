import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchAllVenues } from "../Redux/Slices/venueSlice";

const VenueList = ({ Component }) => {
  const dispatch = useDispatch();
  const { venues, loading, error } = useSelector((state) => state.venues);

  // Fetch venues on component mount
  useEffect(() => {
    dispatch(fetchAllVenues({ page: 1, limit: 10 }));
  }, [dispatch]);

  // Handle loading and error states
  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  // Pass the fetched venues data to the dynamic component
  return <Component data={venues} />;
};

export default VenueList;
