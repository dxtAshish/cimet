import { Router } from "express";
import {  addCuisine, deleteCuisine, getAllCuisine, getCuisineByCategory, updateCuisine } from "../controllers/cuisine.contorller.js";
import { upload } from "../middlewares/multer.middleware.js";
const router=Router()

router.route("/allcuisine/:venueId").get(getAllCuisine)
router.route("/categorycuisine/:category").get(getCuisineByCategory)

router.route("/addcuisne/:venueId").post(
    upload.fields([
        {
          name: "thumbnail",
          maxCount: 1,
        },]),
    addCuisine)
router.route("/deletecuisine/:cuisineId").delete(deleteCuisine)
router.route("/editcuisine").patch(updateCuisine)

export default router