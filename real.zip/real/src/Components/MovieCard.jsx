import React from "react";
import CircularRange from "./CircularRange"; // Corrected spelling
import GenareButton from "./GenareButton"; // Ensure this component is spelled correctly
import { useLoaderData } from "react-router-dom";

const MovieCard = () => {
  const data=useLoaderData()
  // console.log(data,"eeeeeeeeeeexxxxxxxxxx")s
  return (
    <div className="flex flex-row justify-center items-center w-[100vw] h-[100vh] px-10 gap-10 rounded-[10px] bg-cover bg-center overflow-hidden">
      <img
         src={`https://image.tmdb.org/t/p/original/${data.poster_path}`}
        className="w-[400px] h-[500px] rounded-t-[10px]"
      
      />
      <div className="flex flex-col gap-10 p-4 bg-[#04152d] opacity-1 rounded-[20px] h-[520px]">
        <div className="flex flex-col gap-4">
          <p className="text-3xl text-white font-semibold">
            {data.original_title}
          </p>
          <div className="flex space-x-2">
         {data.genres.map((item,index)=>{
          return <GenareButton title={item.name}/>
         })}
          </div>
        </div>

        <div className="flex flex-col">
          <div className="flex items-center  space-x-4">
            <CircularRange value={data.vote_average} />
            {/* <CircularRange value={7.4} /> */}
            <p className="text-blue-500 cursor-pointer mt-2">Watch trailer</p>
          </div>
        </div>

        <div className="mt-4">
          <h3 className="text-white text-lg">Overview</h3>
          <p className="text-[#757a83]">
            {data.overview}
          </p>
        </div>
        <div className="flex flex-col gap-5 text-[#757a83]">
          <div className="flex border-[#757a83] border-b-[0.5px] h-[30px] gap-5">
            <p className="text-white text-xl">
              status: <span className="text-[#757a83] text-sm">{data.status}</span>
            </p>
            <p className="text-white text-xl">
              Release Date: <span className="text-[#757a83] text-sm">{data.release_date}</span>
            </p>
            <p className="text-white text-xl">
              Runtime: <span className="text-[#757a83] text-sm">{data.runtime}</span>
            </p>
          </div>
          <div className="text-[#757a83] h-[30px] border-b-[0.5px] border-[#757a83]">
            <p className="text-white text-xl">
              Director: <span className="text-[#757a83] text-sm">Eli Roth</span>
            </p>
          </div>
          <div className=" text-[#757a83]  h-[30px] border-b-[0.5px] border-[#757a83]">
            <p className="text-white text-xl">
              writer: 
              <span className="text-[#757a83] text-sm"> oe Crombie, Eli Roth</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieCard;
