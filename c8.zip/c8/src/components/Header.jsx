import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { logoutUser } from '../Redux/Slices/userSlice';

const Header = () => {
  const dispatch = useDispatch();

  // Access the auth state from Redux
  const { user, token, role, status } = useSelector((state) => state.user);

  const isAuthenticated = Boolean(token); // Check if the user is authenticated
  const isAdmin = isAuthenticated && role === 'admin'; // Check if the user is an admin

  const handleLogout = () => {
    dispatch(logoutUser()); // Dispatch the logout action
  };

  return (
    <header className="bg-gradient-to-r from-orange-500 to-yellow-400 py-4 px-6 shadow-md">
      <div className="container mx-auto flex justify-between items-center">
        {/* Left Section: Logo/Brand */}
        <div className="text-2xl font-bold text-gray-800">
          D X T-Food
        </div>

        {/* Center Section: Location Select (hidden on mobile, visible on larger screens) */}
        <div className="hidden md:block">
  <select className="bg-gray-100 border border-gray-300 text-gray-600 p-2 rounded-lg">
    <option value="select" className="bg-yellow-100 text-gray-700">Select Location</option>
    <option value="location1" className="bg-yellow-400 text-gray-700">Agra</option>
    <option value="location2" className="bg-yellow-400 text-gray-700">Delhi</option>
    <option value="location3" className="bg-yellow-400 text-gray-700">Mumbai</option>
    <option value="location4" className="bg-yellow-400 text-gray-700">Kolkata</option>
    <option value="location5" className="bg-yellow-400 text-gray-700">Bangalore</option>
  </select>
</div>



        {/* Right Section: Login/Sign-in and User Profile */}
        <div className="flex items-center space-x-4">
          {!isAuthenticated ? (
            <>
              {/* Login / Sign-in buttons */}
              <button className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors">
  <Link to="/login">Login</Link>
</button>
<button className="bg-transparent text-orange-600 px-4 py-2 rounded-lg border border-orange-600 hover:bg-orange-50 transition-colors">
  <Link to="/register">SignUp</Link>
</button>
            </>
          ) : (
            <>
              {/* Show Dashboard only if the user is an admin */}
              {isAdmin && (
                <button className="bg-transparent text-blue-500 px-4 py-2 rounded-lg border border-blue-500 hover:bg-blue-50">
                  <Link to="/dashboard">Dashboard</Link>
                </button>
              )}
              {/* Logout button */}
              <button 
                onClick={handleLogout}
                className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600"
              >
                Logout
              </button>
            </>
          )}
        </div>
      </div>

      {/* Mobile Location Select */}
      <div className="md:hidden mt-4">
        <select className="bg-gray-100 border border-gray-300 text-gray-600 p-2 w-full rounded-lg">
          <option value="select">Select Location</option>
          <option value="location1">Agra</option>
          <option value="location2">Delhi</option>
          <option value="location3">Mumbai</option>
          <option value="location4">Kolkata</option>
          <option value="location5">Bangalore</option>
        </select>
      </div>
    </header>
  );
};

export default Header;
