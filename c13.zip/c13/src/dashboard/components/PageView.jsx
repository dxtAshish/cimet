import React from 'react';

const PageView = ({ page }) => {
  return (
    <div className="bg-yellow-200 rounded-lg h-screen relative shadow-md p-6 ">
      {page}
    </div>
  );
};

export default PageView;
