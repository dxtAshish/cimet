import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchAllCuisines } from "../../Redux/Slices/cuisineSlice";

const CuisineList = ({ venueId, Component }) => {
  const dispatch = useDispatch();

  const { cuisines, loading, error } = useSelector((state) => state.cuisine);

  useEffect(() => {
    if (venueId) {
      dispatch(fetchAllCuisines({ venueId, page: 1, limit: 10 }));
    }
  }, [dispatch, venueId]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  return <Component data={cuisines} />;
};

export default CuisineList;
