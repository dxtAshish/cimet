import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import banner1 from "../assets/banner1.jpg";
import banner2 from "../assets/banner2.jpg";
import banner3 from "../assets/banner3.jpg";
import banner4 from "../assets/banner4.jpg";
import banner5 from "../assets/banner5.jpg";

const Banner = () => {
    const banners = [banner1, banner2, banner3, banner4, banner5];
    const [bannerImage, setBannerImage] = useState(banners[0]);
    const [query, setQuery] = useState(""); // State for search query
    const navigate = useNavigate(); // Initialize useNavigate

    useEffect(() => {
        const randomIndex = Math.floor(Math.random() * banners.length);
        setBannerImage(banners[randomIndex]);
    }, []);

    const handleSearch = () => {
        if (query.trim()) { // Check if the query is not empty
            navigate(`/search/${query}`); // Navigate to the search page with the query
        }
    };

    return (
        <div
            className="relative w-full h-screen bg-cover bg-center"
            style={{
                backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(${bannerImage})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center'
            }}
        >
            <div className="flex flex-col justify-center items-center h-full relative z-10">
                <h1 className="text-white text-7xl font-bold mb-4">Welcome to D X T</h1>
                <input
                    type="text"
                    placeholder="Search..."
                    value={query} 
                    onChange={(e) => setQuery(e.target.value)} 
                    className="p-3 w-1/3 md:w-1/4 lg:w-1/3 rounded-[30px] bg-white text-black shadow-md focus:outline-none focus:ring-2 focus:ring-blue-900"
                />
                <button
                    onClick={handleSearch} 
                    className='w-[80px] h-[40px] bg-red-400 text-white focus:outline-none focus:ring-2 focus:ring-red-900 rounded-[20px] absolute top-[389px] right-[500px]'
                >
                    Search
                </button>
            </div>
        </div>
    );
};

export default Banner;
