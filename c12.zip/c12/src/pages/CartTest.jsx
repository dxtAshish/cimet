import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { increaseQuantity, decreaseQuantity, deleteFromCart, selectCartProducts, selectTotal } from '../Redux/Slices/cartSlice';

const CartPage = () => {
  const cartProducts = useSelector(selectCartProducts); // Get all products in the cart
  const total = useSelector(selectTotal); // Get total price
  const dispatch = useDispatch();

  // Check if the cart is empty
  if (cartProducts.length === 0) {
    return (
      <div className="flex justify-center items-center h-screen">
        <h2 className="text-2xl font-bold text-gray-500">Your Cart is Empty</h2>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4">
      <h2 className="text-3xl font-bold mb-6 text-center">Shopping Cart</h2>

      <div className="bg-white shadow-md rounded-lg p-6">
        {cartProducts.map((product) => (
          <div key={product._id} className="flex flex-col md:flex-row justify-between items-center p-4 border-b last:border-b-0">
            <div className="flex items-center mb-4 md:mb-0">
              <img src={product.thumbnail} alt={product.title} className="w-20 h-20 object-cover rounded-lg" />
              <div className="ml-4">
                <h3 className="font-bold text-lg">{product.title}</h3>
                <p className="text-gray-600">₹{product.price}</p>
              </div>
            </div>

            <div className="flex items-center mb-4 md:mb-0">
              <button
                onClick={() => dispatch(decreaseQuantity(product._id))}
                className="bg-gray-300 px-3 py-1 rounded-lg mr-2 transition duration-200 hover:bg-gray-400"
                disabled={product.quantity <= 1}
              >
                -
              </button>
              <span className="text-lg font-semibold">{product.quantity}</span>
              <button
                onClick={() => dispatch(increaseQuantity(product._id))}
                className="bg-gray-300 px-3 py-1 rounded-lg ml-2 transition duration-200 hover:bg-gray-400"
              >
                +
              </button>
            </div>

            <div>
              <button
                onClick={() => dispatch(deleteFromCart(product._id))}
                className="bg-red-500 text-white px-4 py-1 rounded-lg transition duration-200 hover:bg-red-600"
              >
                Remove
              </button>
            </div>
          </div>
        ))}

        <div className="flex justify-end mt-6">
          <h3 className="text-xl font-bold">Total: ₹{total}</h3>
        </div>
      </div>
    </div>
  );
};

export default CartPage;
