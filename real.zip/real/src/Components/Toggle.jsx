import React, { useState } from 'react';

const Toggle = ({ name1, name2, onToggleChange }) => {
  const [isToggled, setIsToggled] = useState(name1);

  const handleToggle = (value) => {
    setIsToggled(value);
    onToggleChange(value);
  };

  return (
    <div className="w-[300px] max-w-sm rounded flex flex-col">
      <div className='mx-8 shadow-lg rounded-full h-10 mt-4 flex p-1 items-center relative'>
        <div className="w-full flex justify-center">
          <button
            onClick={() => handleToggle(name1)}
            className={`flex-1 text-center py-2 rounded-full transition ${isToggled === name1 ? 'bg-gray-200' : 'bg-transparent'}`}
          >
            {name1}
          </button>
          <button
            onClick={() => handleToggle(name2)}
            className={`flex-1 text-center py-2 rounded-full transition ${isToggled === name2 ? 'bg-gray-200' : 'bg-transparent'}`}
          >
            {name2}
          </button>
          <span className={`elSwitch shadow text-white flex items-center justify-center w-1/2 rounded-full h-8 transition-all absolute top-[4px] ${isToggled === name1 ? 'left-0' : 'left-1/2'} `}></span>
        </div>
      </div>
    </div>
  );
};

export default Toggle;
