import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
// import { getCuisineByCategory } from "../../Redux/Slices/cuisineSlice";  // Import the new thunk
import { getCuisineByCategory } from "../../Redux/Slices/cuisineSlice";
const CuisineByCategoryList = ({ category, Component }) => {
  const dispatch = useDispatch();
  
  // Fetching data from the Redux store
  const { cuisines, loading, error } = useSelector((state) => state.cuisine);

  // Dispatching the getCuisineByCategory action on component mount
  useEffect(() => {
    if (category) {
      console.log("chal rha hai bhai")  // Fetch cuisines by category
      dispatch(getCuisineByCategory(category));
    }
  }, [dispatch, category]);  // Add category as a dependency

  // Display loading or error messages if applicable
  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  // Passing the fetched data to the component
  return <Component data={cuisines} />;
};

export default CuisineByCategoryList;
