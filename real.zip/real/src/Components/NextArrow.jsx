export const NextArrow = ({ className, style, onClick }) => {
    return (
      <div
        className={`${className} absolute top-1/2 right-4 z-10`}
        style={{ ...style, display: "block", transform: "translateY(-50%)" }}
        onClick={onClick}
      >
        <button className="bg-gray-800 text-white p-2 rounded-full hover:bg-gray-700">
          {">"}
        </button>
      </div>
    );
  };
  