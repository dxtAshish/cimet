import { Router } from "express";
import {  addCuisine, deleteCuisine, getAllCuisine, getCuisineByCategory, updateCuisine } from "../controllers/cuisine.contorller.js";
import { upload } from "../middlewares/multer.middleware.js";
import { adminRole, jwtVerify } from "../middlewares/auth.middleware.js";

const router=Router()

router.route("/allcuisine/:venueId").get(getAllCuisine)
router.route("/categorycuisine/:category").get(getCuisineByCategory)

router.route("/addcuisne/:venueId").post(
  jwtVerify,  
  adminRole,  
    upload.fields([
        {
          name: "thumbnail",
          maxCount: 1,
        },]),
    addCuisine)
router.route("/deletecuisine/:cuisineId").delete(
  jwtVerify,  
  adminRole,  
  deleteCuisine)
router.route("/editcuisine").patch(
  jwtVerify,  
  adminRole,  
  updateCuisine)

export default router