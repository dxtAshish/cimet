import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  page: 1,
  genre: "",
  sortBy: "popularity.desc",
};

export const movieFilter = createSlice({
  name: 'movieFilter',
  initialState,
  reducers: {
    setGenre: (state, action) => {
      state.genre = action.payload;
    },
    setPage: (state, action) => {
      state.page = action.payload;
    },
    setSortBy: (state, action) => {
      state.sortBy = action.payload;
    },
  },
});

export const { setGenre, setPage, setSortBy } = movieFilter.actions;

export default movieFilter.reducer;
