import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import './App.css'
import Movies from './Pages/Movies'
import TVShows from './Pages/TVShows'
import Home from './Pages/Home'
import Landing from './Pages/Landing'
import { fetchData } from './loaders/fetchData'

const router=createBrowserRouter([
  {
    path:"/",
    element:<Home/>,
    children:[
      {
        index:true,
        element:<Landing/>,
        loader:fetchData
      },
      {
        path:"/movies",
        element:<Movies/>
      },
      {
        path:"/tvshows",
        element:<TVShows/>
      }
    ]
  }
])
function App() {

  return (
  
 <RouterProvider router={router}/>

    
  )
}

export default App
