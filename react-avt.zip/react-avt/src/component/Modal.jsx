
import { useState } from "react";
import "./modalStyle.css";

const Modal = ({ setToggleModal, addAvatar }) => {
  const [text, setText] = useState("");

  const handleChange = (e) => {
    setText(e.target.value);
  };

  const handleSubmit = () => {
    if (text) {
      addAvatar(text); 
      setToggleModal(false); 
    }
  };

  return (
    <div className="modal">
      <span
        className="cross"
        onClick={() => {
          setToggleModal(false);
        }}
      >
        &times;
      </span>
      <div className="heading">Add new Avatar</div>
      <div className="avatarInput">
        <h3>Enter your avatar</h3>
        <input type="text" onChange={handleChange} value={text} />
      </div>
      <div className="modal-btn">
        <button
          className="cancel btn"
          onClick={() => {
            setToggleModal(false);
          }}
        >
          cancel
        </button>
        <button className="add btn" onClick={handleSubmit}>
          add
        </button>
      </div>
    </div>
  );
};

export default Modal;
