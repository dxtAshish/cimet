import React, { useState } from 'react';
import axios from 'axios';

const VenueForm = ({ fetchVenues }) => {
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    description: ''
  });

  const { name, location, description } = formData;

  const onChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:5000/api/venues', formData, {
        headers: { 'x-auth-token': token }
      });
      fetchVenues();
      setFormData({ name: '', location: '', description: '' });
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <form onSubmit={onSubmit} className="bg-gray-100 p-6 rounded-lg shadow-lg mb-6">
      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="name">Venue Name</label>
        <input
          type="text"
          name="name"
          value={name}
          onChange={onChange}
          placeholder="Venue Name"
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
          required
        />
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="location">Location</label>
        <input
          type="text"
          name="location"
          value={location}
          onChange={onChange}
          placeholder="Location"
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
          required
        />
      </div>

      <div className="mb-6">
        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="description">Description</label>
        <textarea
          name="description"
          value={description}
          onChange={onChange}
          placeholder="Description"
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <button
        type="submit"
        className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        Add Venue
      </button>
    </form>
  );
};

export default VenueForm;
