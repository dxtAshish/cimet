import React from 'react'
import MovieCard from '../Components/MovieCard'
import { useLoaderData } from 'react-router-dom'

const Movie = () => {
  const data=useLoaderData()
 
  return (
    <div className='bg-blue-950'>
        <MovieCard data={data}/>
    </div>
  )
}

export default Movie
