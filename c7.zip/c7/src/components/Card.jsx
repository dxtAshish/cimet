import React from "react";
import { Link } from "react-router-dom";

const Card = ({ data }) => {
  return (
    <div className="flex flex-wrap justify-center gap-4">
      {data.map((item) => (
        <Link key={item._id} to={`/menu/${item._id}`}>
          <div className="container mx-4 my-4">
            <div className="card w-full sm:w-80 md:w-64 rounded-lg overflow-hidden shadow-lg hover:shadow-2xl transform transition-all duration-300 ease-in-out hover:scale-105">
              {/* Image */}
              <img
                src={item.thumbnail}
                className="w-full h-48 object-cover object-center"
                alt={item.title}
              />
              {/* Text Content */}
              <div className="p-6 bg-gradient-to-t from-gray-100 via-gray-200 to-gray-300">
                <h5 className="text-xl font-semibold text-gray-800 leading-tight mb-2 hover:text-gray-700">
                  {item.title}
                </h5>
                <p className="text-gray-600 text-sm mb-2">{item.description}</p>
                <p className="text-gray-500 text-xs italic">{item.location}</p>
              </div>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
};

export default Card;
