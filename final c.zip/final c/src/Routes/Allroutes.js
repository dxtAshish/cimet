import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import HomeWrapper from '../pages/wrapper/HomeWrapper';
import Home from '../pages/Home';
import Menu from '../pages/Menu';
import Login from "../components/Login.jsx"
import Register from "../components/Register.jsx"

import Dashboard from '../dashboard/Dashboard.jsx';
import VenueList from '../pages/fetchList/FetchVenue.jsx';
import CategoryList from '../pages/fetchList/FetchCategorgy.jsx';
import ProtectedRoute, { ProtectedRouteUser } from './ProtectedRoute.js';
import Category from '../pages/Category.jsx';
import Cart from '../pages/Cart.jsx';
import PageNotFound from '../pages/PageNotFound.jsx';

const router = createBrowserRouter([
  {
    path: '/',
    element: <HomeWrapper />,
    children: [
      {
        index: true,
        element: <Home />,
      },
      {
        path:"/menu/:venueId",
        element: <Menu />,
      },
      {
        path:"/category/:category",
        element: <Category />,
      },
      {
        path:"/dashboard",
        element: (
          <ProtectedRoute>
            <Dashboard/>
          </ProtectedRoute>
        ),
      },
      {
        path:"/cart",
        element: (
          <ProtectedRouteUser>
            <Cart/>
          </ProtectedRouteUser>
        ),
      },
      {
        path:"/login",
        element:<Login/>
      },
      {
        path:"/register",
        element:<Register/>
      },
      {
        path:"*",
        element:<PageNotFound/>
      }
     
    ],
  },
]);

export const Allroutes = () => {
  return <RouterProvider router={router} />;
};
