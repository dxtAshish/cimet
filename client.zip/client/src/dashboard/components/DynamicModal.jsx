import React, { useState } from "react";
import { validateDynamicForm } from "../../utils/validation.js";

const DynamicFormModal = ({ isOpen, onClose, title, fields, onSubmit }) => {
  const [formData, setFormData] = useState({});
  const [errors, setErrors] = useState({});

  const handleInputChange = (e, fieldKey) => {
    if (e.target.type === "file") {
      setFormData((prevData) => ({
        ...prevData,
        [fieldKey]: e.target.files[0],
      }));
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [fieldKey]: e.target.value,
      }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validateDynamicForm(formData, fields);
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      onSubmit(formData);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center ">
      <div className="bg-white p-6 rounded-lg w-1/3 ">
        <h3 className="text-lg font-bold mb-4">{title}</h3>
        <form onSubmit={handleSubmit}>
          {fields.map((field) => (
            <div key={field.key} className="mb-4">
              <label className="block text-sm font-medium text-gray-700">
                {field.label}
              </label>
              {field.type === "text" && (
                <input
                  type="text"
                  className="w-full border p-2"
                  value={formData[field.key] || ""}
                  onChange={(e) => handleInputChange(e, field.key)}
                />
              )}
              {field.type === "textarea" && (
                <textarea
                  className="w-full border p-2"
                  value={formData[field.key] || ""}
                  onChange={(e) => handleInputChange(e, field.key)}
                />
              )}
              {field.type === "file" && (
                <input
                  type="file"
                  className="w-full border p-2"
                  onChange={(e) => handleInputChange(e, field.key)}
                />
              )}
              {errors[field.key] && (
                <p className="text-red-500 text-sm mt-1">{errors[field.key]}</p>
              )}
            </div>
          ))}

          <div className="flex justify-end">
            <button
              type="button"
              className="bg-gray-500 text-white px-4 py-2 mr-2"
              onClick={onClose}
            >
              Close
            </button>
            <button
              type="submit"
              className="bg-blue-500 text-white px-4 py-2 "
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DynamicFormModal;
