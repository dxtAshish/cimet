import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchAllCuisines } from "../../Redux/Slices/cuisineSlice";

const CuisineList = ({ venueId, Component }) => {
  const dispatch = useDispatch();
  
  // Fetching data from the Redux store
  const { cuisines, loading, error } = useSelector((state) => state.cuisine);

  // Dispatching the fetchAllCuisines action on component mount
  useEffect(() => {
    if (venueId) {
      dispatch(fetchAllCuisines({ venueId, page: 1, limit: 10 }));
    }
  }, [dispatch, venueId]); // Add venueId as a dependency

  // Display loading or error messages if applicable
  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  // Passing the fetched data to the component
  return <Component data={cuisines} />;
};

export default CuisineList;
