// tests/categoryRoutes.test.js
import request from 'supertest';
import { app } from '../app.js'; // Import your Express app
import { connectTestDB, disconnectTestDB } from './TestDB.js';
import { Category } from '../models/category.models.js';

// Mocking the middlewares (jwtVerify, adminRole, multer)
jest.mock('../middlewares/auth.middleware.js', () => ({
  jwtVerify: (req, res, next) => next(),
  adminRole: (req, res, next) => next(),
}));

jest.mock('../middlewares/multer.middleware.js', () => ({
  upload: {
    fields: jest.fn(() => (req, res, next) => next()),
  },
}));

beforeAll(async () => {
  await connectTestDB();
});

afterAll(async () => {
  await disconnectTestDB();
});

describe('Category Routes', () => {
  it('should get all categories', async () => {
    // Prepopulate the database with some categories
    await Category.create({ dishName: 'Pizza', thumbnail: 'pizza.jpg' });
    await Category.create({ dishName: 'Pasta', thumbnail: 'pasta.jpg' });

    const response = await request(app).get('/api/v1/category/allcategory');
    expect(response.statusCode).toBe(200);
    expect(response.body.data.docs.length).toBe(2);
  });

  it('should create a new category', async () => {
    const response = await request(app)
      .post('/api/v1/category/addcategory')
      .field('dishName', 'Burger')
      .attach('thumbnail', 'path_to_image.jpg');

    expect(response.statusCode).toBe(201);
    expect(response.body.data.dishName).toBe('Burger');
  });

  it('should delete a category', async () => {
    const category = await Category.create({ dishName: 'Sushi', thumbnail: 'sushi.jpg' });

    const response = await request(app)
      .post(`/api/v1/category/deletecategory/${category._id}`);

    expect(response.statusCode).toBe(200);
    expect(response.body.message).toBe('Category deleted successfully');
  });

  // it('should update an existing category', async () => {
  //   const category = await Category.create({ dishName: 'Pasta', thumbnail: 'pasta.jpg' });

  //   const response = await request(app)
  //     .patch('/api/v1/category/editcategory')
  //     .send({ id: category._id, title: 'Updated Pasta' });

  //   expect(response.statusCode).toBe(200);
  //   expect(response.body.data.title).toBe('Updated Pasta');
  // });
});
