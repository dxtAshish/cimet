// src/components/Layout.js
import React from 'react';
import Sidebar from './component/Sidebar'; // Adjust the path as necessary
import Topbar from './component/Topbar';

const Layout = ({ children }) => {
  const handleLogout = () => {
    // Handle logout logic here
    console.log('Logout clicked');
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Topbar profilePic="https://robohash.org/173" userName="John Doe" onLogout={handleLogout} />
        <main className="flex-1 p-4 bg-gray-100 overflow-y-auto mt-16 lg:mt-0">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
