import mongoose from "mongoose"
import {Cuisine} from "../models/cuisine.model.js"
import { Venue } from "../models/venue.model.js";
import {ApiError} from "../utils/ApiError.js"
import {ApiResponse} from "../utils/ApiResponse.js"
import {asyncHandler} from "../utils/asyncHandler.js"

const getVenuMenu = asyncHandler(async (req, res) => {
   
    const {venueId} = req.params
    const {page = 1, limit = 10} = req.query
    const venue =Venue.findById(venueId)
    if(!isValidObjectId(venueId) || !venue) {
        throw new ApiError(400, "Either video id is invalid or No video exists")
    }
    const allCuisine = await Venue.aggregate([
        {
            $match: {
                _id: new mongoose.Types.ObjectId(venueId)
            }
        },

        {
            $lookup: {
                from: "cuisine",
                localField: "_id",
                foreignField: "venue",
                as: "allVenueMenu",
                pipeline: [
                    {
                        $project: {
                            _id: 1,
                            content: 1,
                            owner: 1
                        }
                    }
                ]
            }
        },
        {
            $project: {
                allVenueMenu: 1,
                _id: 0
            }
        }
    ])
    if(!allCuisine) {
        throw new ApiError(400, "Something went wrong while getting all cuisine of video")
    }

    return res
    .status(200)
    .json(new ApiResponse(200, allComments, "All cuisine fetched succesfully"))
})
const getCuisineByCategory=asyncHandler(async(req,res)=>{
    
})
const addCuisine = asyncHandler(async (req, res) => {
    
    const {title,price,description} =req.body;
    const {venueId} = req.params
    if(!title)
    {
        throw new ApiError(400,"cuisine title does not found")
    }
    if(!price)
        {
            throw new ApiError(400,"cuisine price does not found")
        }
     if(!description)
            {
                throw new ApiError(400,"cuisine description does not found")
            }
    const newCusine=await Cuisine.create({
        title,
        price,
        description,
        venue:new mongoose.Types.ObjectId(venueId),

    })
    return res.status(200).json(new ApiResponse(200,newComment,"comment added successfully"))
})

const updateCuisine = asyncHandler(async (req, res) => {
    const {title,price,description} =req.body;

    const {cuisineId} = req.params
    if(!cuisineId)
    {
        throw new ApiError(400,"not found Venue id");
    }


    const updateCuisine = Cuisine.findByIdAndUpdate(cuisineId,{
        $set:{
            title:title,
             description:description,
             location:price,
        },
    },
    {
        new: true,
      }
      )
    return res.status(200).json(new ApiResponse(200,updateComment,"comment updated successfully"))

    // TODO: update a comment
})

const deleteCuisine = asyncHandler(async (req, res) => {
    
    const {cuisineId}=req.params
  
    const deleteCuisine=await cuisine.findByIdAndDelete(cuisineId)
    return res.status(200).json(new ApiResponse(200,deleteCuisine,"comment deleted successfully"))
})

export {
       getVenuMenu,
       addCuisine,
       updateCuisine,
       deleteCuisine,
    }