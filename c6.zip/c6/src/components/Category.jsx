import React from 'react';

const Category = ({ data }) => {
  return (
    <div className='flex flex-wrap'>
      {data.map((item) => (
        <div key={item._id} className='w-1/5 bg-slate-500 flex flex-col m-2 p-2'>
          <img src={item.thumbnail} alt={item.dishName} className='h-32 w-full object-cover' />
          <h3 className='text-white text-center mt-2'>{item.dishName}</h3>
        </div>
      ))}
    </div>
  );
};

export default Category;
