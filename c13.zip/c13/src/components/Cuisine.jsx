import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addToCart, deleteFromCart, selectCartProducts } from '../Redux/Slices/cartSlice'; // Adjust the import path as necessary

const Cuisine = ({ data }) => {
  const dispatch = useDispatch();
  const cartProducts = useSelector(selectCartProducts); // Get all products in the cart

  const handleAddToCart = (cuisine) => {
    dispatch(addToCart(cuisine));
  };

  const handleRemoveFromCart = (cuisineId) => {
    dispatch(deleteFromCart(cuisineId));
  };

  // Helper function to check if the cuisine is in the cart
  const isInCart = (cuisineId) => {
    return cartProducts.some(product => product._id === cuisineId);
  };

  return (
    <div className="flex flex-wrap justify-center gap-6 p-4">
      {data.map((cuisine) => (
        <div 
          key={cuisine._id} 
          className="bg-white p-6 rounded-lg shadow-lg max-w-xs transform transition-transform hover:scale-105 flex flex-col justify-between"
        >
          <div className="overflow-hidden rounded-lg mb-4">
            {/* Thumbnail or image section */}
            <img
              src={cuisine.thumbnail || "https://via.placeholder.com/150"}
              alt={cuisine.title}
              className="w-full h-48 object-cover"
            />
          </div>

          {/* Text details */}
          <div className="text-center flex-grow">
            <h3 className="text-2xl font-bold text-gray-800 mb-2">{cuisine.title}</h3>
            <p className="text-gray-600 text-sm mb-2">{cuisine.description}</p>
            <p className="text-lg font-semibold text-gray-900">₹{cuisine.price}</p>
          </div>

          {/* Button logic for Add/Remove from Cart */}
          <div className="mt-4 text-center">
            {isInCart(cuisine._id) ? (
              <button 
                onClick={() => handleRemoveFromCart(cuisine._id)} // Dispatch deleteFromCart on button click
                className="px-4 py-2 bg-red-500 text-white rounded-full hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400 focus:ring-opacity-50 transition"
              >
                Remove from Cart
              </button>
            ) : (
              <button 
                onClick={() => handleAddToCart(cuisine)} // Dispatch addToCart on button click
                className="px-4 py-2 bg-yellow-500 text-white rounded-full hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:ring-opacity-50 transition"
              >
                Add to Cart
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default Cuisine;
