/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      dropShadow: {
        'custom-red': '5px 5px 10px #ef4444'
      },
    },
  },
  plugins: [],
}