import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { BaseUrl } from "../../services/API";




export const fetchAllVenues = createAsyncThunk(
  "venues/fetchAll",
  async ({ page = 1, limit = 10, query, sortBy, sortType }, { rejectWithValue }) => {
    try {
    
      const token = localStorage.getItem("token");


      const config = {
        headers: {
          Authorization: `Bearer ${token}`, 
        },
        params: { page, limit, query, sortBy, sortType },
      };

      const response = await axios.get(`${BaseUrl}/venues/get-venues`, config);

      return response.data.data; 
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);


export const addVenue = createAsyncThunk(
  "venues/add",
  async (venueData, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem("token");

      const response = await axios.post(`${BaseUrl}/venues/upload-venue`, venueData, {
        headers: { "Content-Type": "multipart/form-data",
            Authorization: `Bearer ${token}`,
         },
      });
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const updateVenue = createAsyncThunk(
  "venues/update",
  async ({ venueId, updatedData }, { rejectWithValue }) => {
    try {
      const response = await axios.put(`${BaseUrl}/c/${venueId}`, updatedData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const deleteVenue = createAsyncThunk(
  "venues/delete",
  async (venueId, { rejectWithValue }) => {
    
    try {
      const token = localStorage.getItem("token");


      const config = {
        headers: {
          Authorization: `Bearer ${token}`, 
        },
      };

      const response = await axios.delete(`${BaseUrl}/venues/c/${venueId}`,config);
      return venueId;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);


const venueSlice = createSlice({
  name: "venues",
  initialState: {
    venues: [],      
    loading: false,  
    error: null,     
  },
  reducers: {
    clearVenues: (state) => {
      state.venues = [];
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder

      .addCase(fetchAllVenues.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAllVenues.fulfilled, (state, action) => {
        state.loading = false;
        state.venues = action.payload;  
      })
      .addCase(fetchAllVenues.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })

      .addCase(addVenue.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addVenue.fulfilled, (state, action) => {
        state.loading = false;
        state.venues.push(action.payload); 
      })
      .addCase(addVenue.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })


      .addCase(updateVenue.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateVenue.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.venues.findIndex((venue) => venue._id === action.payload._id);
        if (index !== -1) {
          state.venues[index] = action.payload;  
        }
      })
      .addCase(updateVenue.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })

  
      .addCase(deleteVenue.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteVenue.fulfilled, (state, action) => {
        state.loading = false;
        state.venues = state.venues.filter((venue) => venue._id !== action.payload);  
      })
      .addCase(deleteVenue.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { clearVenues } = venueSlice.actions;
export default venueSlice.reducer;
