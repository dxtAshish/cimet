import React, { useState } from "react";
import CuisineList from "../../pages/fetchList/FetchCuisine";
import MenuCard from "./MenuCard";
// import DynamicFormModal from "./DynamicFormModal"; // Import DynamicFormModal
import DynamicFormModal from "./DynamicModal";
import { addCuisine } from "../../Redux/Slices/cuisineSlice";
import { useDispatch } from "react-redux";
const MenuListModal = ({ isOpen, onClose, venueId }) => {
  const dispatch=useDispatch()
  const [isDynamicModalOpen, setIsDynamicModalOpen] = useState(false);

  const openDynamicFormModal = () => {
    setIsDynamicModalOpen(true);
  };

  const closeDynamicFormModal = () => {
    setIsDynamicModalOpen(false);
  };
  const handleFormSubmit = (formData) => {
    console.log("Form Data Submitted:", formData);
    dispatch(addCuisine({venueId,formData}))

    closeDynamicFormModal();
  };

  const formFields = [
    { key: "title", label: "Title", type: "text" },
    { key: "price", label: "Price", type: "text" },
    { key: "description", label: "Description", type: "textarea" },
    { key: "category", label: "Category", type: "text" },

    { key: "thumbnail", label: "Image", type: "file" }
  ];


  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-gray-700 bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg w-[80vw] h-[80vh] overflow-hidden shadow-lg">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-2xl font-bold">Menu List</h3>
          <button onClick={onClose} className="text-red-500">
            Close
          </button>
        </div>
        <div className="mb-4">
        
          <button
            onClick={openDynamicFormModal}
            className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:shadow-lg hover:from-yellow-500 hover:to-orange-600 transition-all duration-300 ease-in-out"
          >
            Add++
          </button>
        </div>
        <div className="menu-list overflow-y-auto max-h-[60vh]">
          <CuisineList venueId={venueId} Component={MenuCard} />
        </div>
      </div>

      <DynamicFormModal
        isOpen={isDynamicModalOpen}
        onClose={closeDynamicFormModal}
        title="Add Menu Item"
        fields={formFields}
        onSubmit={handleFormSubmit}
      />
    </div>
  );
};

export default MenuListModal;
