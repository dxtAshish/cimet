import { configureStore } from '@reduxjs/toolkit';
import userReducer from './Slices/userSlice';
import venueReducer from './Slices/venueSlice'
import categoryReducer from './Slices/categorySlice'
import cuisineReducer from './Slices/cuisineSlice'
import headerReducer from './Slices/headerSlice'
import cartSlice from "./Slices/cartSlice";
export const store = configureStore({
  reducer: {
    cart: cartSlice,
    user: userReducer,
    venues: venueReducer,
    category:categoryReducer,
    cuisine:cuisineReducer,
    header:headerReducer
  },
});
