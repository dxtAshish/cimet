import React from 'react';
import { useParams } from 'react-router-dom';
import CuisineByCategoryList from './fetchList/FetchCuisineByCategory';
import Cuisine from '../components/Cuisine';

const Category = () => {
  const { category } = useParams(); 

  return (
    <div>
      <CuisineByCategoryList category={category} Component={Cuisine} />
    </div>
  );
};

export default Category;
