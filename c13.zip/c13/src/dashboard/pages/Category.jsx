import React, { useState } from "react";
import DashboardTable from "../components/DashboardTable";
import DynamicFormModal from "../components/DynamicModal"; // Import your modal component
import { useDispatch } from "react-redux";
import { addCategory, deleteCategory } from "../../Redux/Slices/categorySlice";

const Category = ({ data }) => {
  const dispatch = useDispatch();
  const [showModal, setShowModal] = useState(false);  // State to control modal visibility

  // Define columns for the Category table
  const columns = [
    { key: "_id", header: "ID" },
    { key: "dishName", header: "Title" },
    {
      key: "thumbnail",
      header: "Image",
      render: (thumbnail) => <img src={thumbnail} alt="thumbnail" className="h-10 w-10" />,
    },
  ];

  // Define actions for each row
  const actions = [
    {
      label: "Edit",
      className: "bg-blue-500 hover:bg-blue-700",
      onClick: (row) => console.log("Edit", row),
    },
    {
      label: "Delete",
      className: "bg-red-500 hover:bg-red-700",
      onClick: (row) => handleDeleteCategory(row._id),  // Dispatch delete action
    },
  ];

  // Fields for the modal (this can be dynamic based on your requirements)
  const modalFields = [
    { key: "dishName", label: "Dish Name", type: "text" },
    { key: "thumbnail", label: "Image", type: "file" },  // File input for image upload
  ];

  // Handle form submission for adding new category
  const handleAddNewCategory = (formData) => {
    console.log("New Category Data:", formData);
    dispatch(addCategory(formData));  // Dispatch add category action
    setShowModal(false);  // Close the modal after submission
  };

  // Handle category deletion
  const handleDeleteCategory = (id) => {
    console.log("Deleting Category with ID:", id);
    dispatch(deleteCategory(id));  // Dispatch delete category action
  };


  return (
    <div>
      <h2>Category Dashboard</h2>
      <button
        className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:shadow-lg hover:from-yellow-500 hover:to-orange-600 transition-all duration-300 ease-in-out"
        onClick={() => setShowModal(true)}
      >
        Add+
      </button>

      {/* Display the table */}
      <DashboardTable columns={columns} data={data} actions={actions} />

      {/* DynamicFormModal for adding or editing category */}
      <DynamicFormModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title="Add New Category"
        fields={modalFields}
        onSubmit={handleAddNewCategory}
      />
    </div>
  );
};

export default Category;
