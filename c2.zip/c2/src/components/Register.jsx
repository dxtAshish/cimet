import React from 'react';

const Register = () => {
  return (
    <div className="antialiased bg-gray-200 text-gray-900 font-sans min-h-screen flex items-center justify-center">
      <div className="w-full bg-white rounded shadow-lg p-8 m-4 md:max-w-sm md:mx-auto">
        <span className="block w-full text-xl uppercase font-bold mb-4">Register</span>
        <form className="mb-4" action="/" method="post">
          {/* First Name */}
          <div className="mb-4 md:w-full">
            <label htmlFor="firstName" className="block text-xs mb-1">First Name</label>
            <input 
              className="w-full border rounded p-2 outline-none focus:shadow-outline" 
              type="text" 
              name="firstName" 
              id="firstName" 
              placeholder="First Name" 
            />
          </div>

          {/* Last Name */}
          <div className="mb-4 md:w-full">
            <label htmlFor="lastName" className="block text-xs mb-1">Last Name</label>
            <input 
              className="w-full border rounded p-2 outline-none focus:shadow-outline" 
              type="text" 
              name="lastName" 
              id="lastName" 
              placeholder="Last Name" 
            />
          </div>

          {/* Email */}
          <div className="mb-4 md:w-full">
            <label htmlFor="email" className="block text-xs mb-1">Email</label>
            <input 
              className="w-full border rounded p-2 outline-none focus:shadow-outline" 
              type="email" 
              name="email" 
              id="email" 
              placeholder="Email" 
            />
          </div>

          {/* Password */}
          <div className="mb-4 md:w-full">
            <label htmlFor="password" className="block text-xs mb-1">Password</label>
            <input 
              className="w-full border rounded p-2 outline-none focus:shadow-outline" 
              type="password" 
              name="password" 
              id="password" 
              placeholder="Password" 
            />
          </div>

          {/* Confirm Password */}
          <div className="mb-4 md:w-full">
            <label htmlFor="confirmPassword" className="block text-xs mb-1">Confirm Password</label>
            <input 
              className="w-full border rounded p-2 outline-none focus:shadow-outline" 
              type="password" 
              name="confirmPassword" 
              id="confirmPassword" 
              placeholder="Confirm Password" 
            />
          </div>

          {/* Address */}
          <div className="mb-4 md:w-full">
            <label htmlFor="address" className="block text-xs mb-1">Address</label>
            <input 
              className="w-full border rounded p-2 outline-none focus:shadow-outline" 
              type="text" 
              name="address" 
              id="address" 
              placeholder="Address" 
            />
          </div>

          {/* Phone */}
          <div className="mb-6 md:w-full">
            <label htmlFor="phone" className="block text-xs mb-1">Phone</label>
            <input 
              className="w-full border rounded p-2 outline-none focus:shadow-outline" 
              type="tel" 
              name="phone" 
              id="phone" 
              placeholder="Phone" 
            />
          </div>

          <button className="bg-green-500 hover:bg-green-700 text-white uppercase text-sm font-semibold px-4 py-2 rounded">
            Register
          </button>
        </form>
      </div>
    </div>
  );
};

export default Register;
