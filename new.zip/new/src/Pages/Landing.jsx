import React from "react";
import Banner from "../Components/Banner";

import MovieCard from "../Components/MovieCard";
import Carousel from "../Components/Carousel";

import { useLoaderData } from "react-router-dom";


const Landing = () => {
  const [popularMovies,popularTv,topRatedMovies,topRatedTv,trendingMoviesDay,trendingMoviesweek]=useLoaderData();
  console.log(popularMovies.value.data.results)
  return (
    <div className="bg-blue-950">
      <Banner />

      

      <Carousel data1={trendingMoviesDay.value.data.results} data2={trendingMoviesweek.value.data.results} sectionName="Trending" name1={"Day"} name2={"Week"}/>
      <Carousel data1={popularMovies.value.data.results} data2={popularTv.value.data.results} sectionName="What's Popular" name1={"Movie"} name2={"Tv Show"} />
      <Carousel data1={topRatedMovies.value.data.results} data2={topRatedTv.value.data.results} sectionName="Top Rated" name1={"Movie"} name2={"Tv Show"}/>


   


      {/* <MovieCard /> */}
    </div>
  );
};

export default Landing;
