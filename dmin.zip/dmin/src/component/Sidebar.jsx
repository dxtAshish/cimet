// src/components/Sidebar.js
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaHome, FaUser, FaCog, FaSignOutAlt, FaBars, FaTimes, FaGamepad } from 'react-icons/fa';

const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="flex flex-col lg:h-screen bg-gray-100">
      <div className="bg-blue-500 text-white flex items-center justify-between h-16 p-4 md:hidden">
        <h1 className="text-2xl font-bold">Admin Panel</h1>
        <button onClick={toggleSidebar} className="focus:outline-none">
          {isOpen ? <FaTimes size={24} /> : <FaBars size={24} />}
        </button>
      </div>

      <div
        className={`bg-blue-500 text-white flex flex-col h-full w-64 fixed md:relative z-20 transform ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } transition-transform duration-300 ease-in-out lg:translate-x-0`}
      >
        <div className="flex items-center justify-center h-16 border-b border-blue-400">
          <h1 className="text-2xl font-bold">Admin Panel</h1>
        </div>
        <div className="flex-grow">
          <ul className="flex flex-col p-4">
            <li className="mb-4">
              <Link to="/" className="flex items-center p-2 hover:bg-blue-600 rounded">
                <FaHome className="mr-2" /> Dashboard
              </Link>
            </li>
            <li className="mb-4">
              <Link to="/admin" className="flex items-center p-2 hover:bg-blue-600 rounded">
                <FaUser className="mr-2" /> Users
              </Link>
            </li>
            <li className="mb-4">
              <Link to="/game-screen" className="flex items-center p-2 hover:bg-blue-600 rounded">
                <FaGamepad className="mr-2" /> Games
              </Link>
            </li>
            <li className="mb-4">
              <Link to="/settings" className="flex items-center p-2 hover:bg-blue-600 rounded">
                <FaCog className="mr-2" /> Settings
              </Link>
            </li>
          </ul>
        </div>
        <div className="p-4 border-t border-blue-400">
          <Link to="/logout" className="flex items-center p-2 hover:bg-blue-600 rounded">
            <FaSignOutAlt className="mr-2" /> Logout
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
