import { createBrowserRouter, RouterProvider } from "react-router-dom";
import "./App.css";
import Movies from "./Pages/Movies";
import TVShows from "./Pages/TVShows";
import Home from "./Pages/Home";
import Landing from "./Pages/Landing";
import { fetchData } from "./loaders/fetchData";
import { fetchMovieData } from "./loaders/fetchMovieData";
// import { fetchTvData } from "./loaders/fetchTvData";
import { fetchTvData } from "./loaders/fetchTvData";
import MovieWrapper from "./Components/movieWrapper";
import TvWrapper from "./Components/TvWrapper";
import Movie from "./Pages/Movie";
import { fetchSingleMovie } from "./loaders/fetchSingleMovie";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Home />,
    children: [
      {
        index: true,
        element: <Landing />,
        loader: fetchData,
      },
      {
        path: "/movies",
        element: <MovieWrapper />,

        children: [
          {
            path: ":id",
            element: <Movie/>,
            loader:(event)=>fetchSingleMovie(event)
          },
          {
            index: true,
            element: <Movies />,
            loader: fetchMovieData,
          },
        ],
      },
      {
        path: "/tvshows",
        element: <TvWrapper />,
        children: [
          // {
          //   path: "/:id",
          //   element: <TVShows />,
          // },
          {
            index: true,
            element: <TVShows />,
            loader: fetchTvData,
          },
        ],
      },
    ],
  },
]);
function App() {
  return <RouterProvider router={router} />;
}

export default App;
//https://api.themoviedb.org/3/movie/id/credits