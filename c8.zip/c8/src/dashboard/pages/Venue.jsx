import React, { useState } from "react";
import DashboardTable from "../components/DashboardTable";
// import DynamicFormModal from "../components/DynamicFormModal";
import DynamicFormModal from "../components/DynamicModal";
import { addVenue } from "../../Redux/Slices/venueSlice";
import { deleteVenue } from "../../Redux/Slices/venueSlice";
import { useDispatch } from "react-redux";
import MenuListModal from "../components/MenuListModal";


const Venue = ({ data }) => {
    const dispatch = useDispatch();
    const [showModal, setShowModal] = useState(false);
    const [showMenuModal, setShowMenuModal] = useState(false); // State to control the menu modal
    const [selectedMenu, setSelectedMenu] = useState([]);
    const [selectedVenueId, setSelectedVenueId] = useState(null); // To store the selected venue ID

    // Define columns for the Venue table
    const columns = [
        { key: "_id", header: "ID" },
        { key: "title", header: "Title" },
        { key: "description", header: "Description" },
        { key: "location", header: "Location" },
        {
            key: "thumbnail",
            header: "Image",
            render: (thumbnail) => <img src={thumbnail} alt="thumbnail" className="h-10 w-10" />,
        },
        {
            key: "menu",
            header: "Menu",
            render: (menu, row) => (
                <button
                    className="text-blue-500"
                    onClick={() => handleViewMenu(row._id)} // Pass venue id to the function
                >
                    View Menu
                </button>
            ),
        },
    ];

    // Define actions for each row (optional)
    const actions = [
        {
            label: "Edit",
            className: "bg-blue-500 hover:bg-blue-700",
            onClick: (row) => console.log("Edit", row),
        },
        {
            label: "Delete",
            className: "bg-red-500 hover:bg-red-700",
            onClick: (row) => handleDeleteVenue(row._id),
        },
    ];

    const modalFields = [
        { key: "title", label: "Title", type: "text" },
        { key: "description", label: "Description", type: "textarea" },
        { key: "location", label: "Location", type: "text" },
        { key: "thumbnail", label: "Image", type: "file" },
        { key: "menu", label: "Menu URL", type: "text" },
    ];

    const handleAddNewVenue = (formData) => {
        console.log("New Venue Data:", formData);
        dispatch(addVenue(formData));
        setShowModal(false);
    };

    const handleDeleteVenue = (id) => {
        console.log(id);
        dispatch(deleteVenue(id));
    };

    // Function to handle opening the menu modal
    const handleViewMenu = (venueId) => {
        const venue = data.find((v) => v._id === venueId);
        setSelectedMenu(venue.menu); // Set the selected venue's menu
        setSelectedVenueId(venueId); // Set the venue ID
        setShowMenuModal(true); // Open the menu modal
    };

    return (
        <div>
            <h2>Venue Dashboard</h2>
            <button
                className="bg-green-500 text-white px-4 py-2"
                onClick={() => setShowModal(true)}
            >
                Add+
            </button>

            {/* Display the table */}
            <DashboardTable columns={columns} data={data} actions={actions} />

            {/* DynamicFormModal for adding new venue */}
            <DynamicFormModal
                isOpen={showModal}
                onClose={() => setShowModal(false)}
                title="Add New Venue"
                fields={modalFields}
                onSubmit={handleAddNewVenue}
            />

            {/* Menu List Modal */}
            <MenuListModal
                isOpen={showMenuModal}
                onClose={() => setShowMenuModal(false)}
                venueId={selectedVenueId} // Pass the selected venue ID to the modal
                menu={selectedMenu} // Pass the selected menu to the modal
            />
        </div>
    );
};

export default Venue;
