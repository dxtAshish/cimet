import React from 'react';
import { Link } from 'react-router-dom';

const Category = ({ data }) => {
  return (
    <div className="flex flex-wrap justify-center">
      {data.map((item) => (
        <Link key={item._id} to={`/category/${item.dishName}`}>
          <div
            className="w-60 h-60 m-4 p-2 rounded-full flex items-center justify-center overflow-hidden shadow-lg shadow-yellow-500 hover:scale-105 transition-transform duration-300"
          >
            <img
              src={item.thumbnail}
              alt={item.dishName}
              className="w-full h-full object-cover rounded-full"
            />
          </div>
          <h3 className="text-gray-800 font-bold text-center mt-2">{item.dishName}</h3>
        </Link>
      ))}
    </div>
  );
};

export default Category;
