import React from 'react'
import { useLoaderData } from 'react-router-dom'

const Search = () => {
    const data=useLoaderData()
    console.log(data)
  return (
    <div>
    search  
    </div>
  )
}

export default Search
