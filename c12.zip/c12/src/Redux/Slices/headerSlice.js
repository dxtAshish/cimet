import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  selectedLocation: 'select', // Default value
};

const headerSlice = createSlice({
  name: 'header',
  initialState,
  reducers: {
    setLocation: (state, action) => {
      state.selectedLocation = action.payload;
    },
  },
});

export const { setLocation } = headerSlice.actions;

export default headerSlice.reducer;
