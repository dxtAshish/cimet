import React, { useEffect, useState, useCallback } from "react";
import DropDown from "../Components/DropDown";
import Card from "../Components/Card";
import { API_OPTIONS } from "../utils/constants";
import axios from "axios";
import { useSelector } from "react-redux";

const Movies = () => {
  const [list, setList] = useState([]);
  const [movieListArr, setMovieListArr] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(1); // Track current page
  const { genre, sortBy } = useSelector((state) => state.movieFilter);

  useEffect(() => {
    const fetchGenres = async () => {
      try {
        const { data } = await axios.get(
          "https://api.themoviedb.org/3/genre/movie/list",
          API_OPTIONS
        );
        setList(data.genres);
      } catch (err) {
        console.error("Error fetching genres:", err);
      }
    };

    fetchGenres();
  }, []);

  const fetchMovieData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const API_URL = `https://api.themoviedb.org/3/discover/movie?page=${page}&with_genres=${genre}&sort_by=${sortBy}`;
      const response = await axios.get(API_URL, API_OPTIONS);
      setMovieListArr((prev) => [...prev, ...response.data.results]); 
    } catch (err) {
      setError("Failed to fetch movie data");
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [genre, sortBy, page]);

  useEffect(() => {
    setMovieListArr([]); 
    
    fetchMovieData();
  }, [genre, sortBy, fetchMovieData]);

  const handleScroll = useCallback(() => {
    const scrollY = window.scrollY;
    const windowHeight = window.innerHeight;
    const documentHeight = document.documentElement.scrollHeight;

    if (scrollY + windowHeight >= documentHeight - 200 && !loading) {
      setPage((prev) => prev + 1); 
    }
  }, [loading]);

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [handleScroll]);

  const arry = [
    { id: "popularity.desc", name: "Popularity Descending" },
    { id: "popularity.asc", name: "Popularity Ascending" },
    { id: "vote_average.desc", name: "Rating Descending" },
    { id: "vote_average.asc", name: "Rating Ascending" },
    { id: "primary_release_date.asc", name: "Release Date Ascending" },
    { id: "primary_release_date.desc", name: "Release Date Descending" },
    { id: "original_title.asc", name: "Title (A-Z)" },
  ];

  if (loading && page === 1) {
    return <p className="text-white">Loading...</p>;
  }

  if (error) {
    return <p className="text-red-500">{error}</p>;
  }

  return (
    <div className="w-100vw h-100vh bg-[#04152d] pt-[100px] px-[100px]">
      <div className="flex justify-between items-center h-[100px]">
        <div>
          <p className="text-white text-2xl font-light">Explore Movies</p>
        </div>
        <div className="flex justify-center items-center">
          <DropDown dropDownName="Select genres" arr={list} type="genre" />
          <DropDown dropDownName="Sort by" arr={arry} type="sort" />
        </div>
      </div>
      <div className="flex flex-wrap w-full gap-16">
        {movieListArr.map((value) => (
          <Card value={value} key={value.id} />
        ))}
      </div>
      {loading && <p className="text-white">Loading more movies...</p>}
    </div>
  );
};

export default Movies;
