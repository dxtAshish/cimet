import React from 'react';
import { Link } from 'react-router-dom';
const Header = () => {
  return (
    <header className="bg-white shadow-md py-4 px-6">
      <div className="container mx-auto flex justify-between items-center">
        {/* Left Section: Logo/Brand */}
        <div className="text-2xl font-bold text-gray-800">
          BrandLogo
        </div>

        {/* Center Section: Location Select (hidden on mobile, visible on larger screens) */}
        <div className="hidden md:block">
          <select className="bg-gray-100 border border-gray-300 text-gray-600 p-2 rounded-lg">
            <option value="select">Select Location</option>
            <option value="location1">Agra</option>
            <option value="location2">Delhi</option>
            <option value="location2">Mumbai</option>
            <option value="location2">Kolkata</option>
            <option value="location2">Benglor</option>



          </select>
        </div>

        {/* Right Section: Login/Sign-in and User Profile */}
        <div className="flex items-center space-x-4">
          {/* Login / Sign-in buttons */}
          <button className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">
            <Link to="/login">Login</Link>
          </button>
          <button className="bg-transparent text-blue-500 px-4 py-2 rounded-lg border border-blue-500 hover:bg-blue-50">
          <Link to="/register">SignUp</Link>
            
          </button>
          <button className="bg-transparent text-blue-500 px-4 py-2 rounded-lg border border-blue-500 hover:bg-blue-50">
          <Link to="/dashboard">Dashboard</Link>
            
          </button>

          {/* Avatar for user profile */}
          <div className="relative w-10 h-10">
            <img 
              src="https://via.placeholder.com/150" 
              alt="User Avatar" 
              className="w-full h-full rounded-full object-cover"
            />
          </div>
        </div>
      </div>

      {/* Location select for mobile (visible on mobile, hidden on larger screens) */}
      <div className="md:hidden mt-4">
        <select className="bg-gray-100 border border-gray-300 text-gray-600 p-2 w-full rounded-lg">
          <option value="select">Select Location</option>
          <option value="location1">Location 1</option>
          <option value="location2">Location 2</option>
        </select>
      </div>
    </header>
  );
};

export default Header;
