import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
const BaseUrl = "http://localhost:5000/api/v1";
const token = localStorage.getItem("token");

// Fetch all categories with pagination
// Fetch all categories with pagination
export const fetchAllCategories = createAsyncThunk(
    "categories/fetchAll",
    async ({ page = 1, limit = 10 }, { rejectWithValue }) => {
      try {
        const response = await axios.get(`${BaseUrl}/category/allcategory`, {
          params: { page, limit },
        });
        return response.data.data;  
      } catch (error) {
        return rejectWithValue(error.response.data);
      }
    }
  );
  


export const addCategory = createAsyncThunk(
  "categories/add",
  async (formData, { rejectWithValue }) => {
    try {

   

      const response = await axios.post(`${BaseUrl}/category/addcategory`, formData, {
        headers: { "Content-Type": "multipart/form-data" ,
          Authorization: `Bearer ${token}`,
        },
      });
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);


export const editCategory = createAsyncThunk(
  "categories/edit",
  async ({ id, title, image }, { rejectWithValue }) => {
    try {
      const formData = new FormData();
      if (title) formData.append("title", title);
      if (image) formData.append("image", image);

      const response = await axios.put(`${BaseUrl}/categories/edit/${id}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);


export const deleteCategory = createAsyncThunk(
  "categories/delete",
  async (id, { rejectWithValue }) => {
    try {
     
      const token = localStorage.getItem('token'); 

   
      if (!token) {
        throw new Error("Token is missing. Please login again.");
      }

     
      const response = await axios.post(
        `${BaseUrl}/category/deletecategory/${id}`,
        {},  // Empty request body, assuming the deletion doesn't require a body
        {
          headers: {
            Authorization: `Bearer ${token}`, 
          },
        }
      );

      return response.data.data;
    } catch (error) {
     
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);


const categorySlice = createSlice({
  name: "categories",
  initialState: {
    categories: [],
    loading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    
    builder
    .addCase(fetchAllCategories.pending, (state) => {
      state.loading = true;
      state.error = null;
    })
    .addCase(fetchAllCategories.fulfilled, (state, action) => {
      state.loading = false;
      state.categories = action.payload.docs;  // Now referencing `docs` from `message`
    })
    .addCase(fetchAllCategories.rejected, (state, action) => {
      state.loading = false;
      state.error = action.payload;
    });

  


    // Handle addCategory
    builder
      .addCase(addCategory.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addCategory.fulfilled, (state, action) => {
        state.loading = false;
        state.categories.push(action.payload);
      })
      .addCase(addCategory.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });

    // Handle editCategory
    builder
      .addCase(editCategory.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(editCategory.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.categories.findIndex((cat) => cat._id === action.payload._id);
        if (index !== -1) {
          state.categories[index] = action.payload;
        }
      })
      .addCase(editCategory.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });

    // Handle deleteCategory
   // Handle deleteCategory
builder
.addCase(deleteCategory.pending, (state) => {
  state.loading = true;
  state.error = null;
})
.addCase(deleteCategory.fulfilled, (state, action) => {
  state.loading = false;
  // Assuming the payload is just the ID of the deleted category
  state.categories = state.categories.filter((cat) => cat._id !== action.payload);
})
.addCase(deleteCategory.rejected, (state, action) => {
  state.loading = false;
  state.error = action.payload;
});

  },
});

export default categorySlice.reducer;
