import React from "react";

const DashboardTable = ({ columns, data, actions }) => {
  return (
    <div className="">
      <table className="min-w-full bg-yellow-200 border-collapse border border-black">
        <thead>
          <tr>
            {columns.map((column) => (
              <th key={column.key} className="px-4 py-2 border border-black">
                {column.header}
              </th>
            ))}
            {actions && <th className="px-4 py-2 border border-black">Actions</th>}
          </tr>
        </thead>
        <tbody>
          {data.map((row, rowIndex) => (
            <tr key={rowIndex} className="text-center">
              {columns.map((column) => (
                <td key={column.key} className="px-4 py-2 border border-black">
                  {column.render ? column.render(row[column.key], row) : row[column.key]}
                </td>
              ))}
              {actions && (
                <td className="px-4 py-2 border border-black">
                  {actions.map((action, actionIndex) => (
                    <button
                      key={actionIndex}
                      onClick={() => action.onClick(row)}
                      className={`px-2 py-1 text-white ${action.className}`}
                    >
                      {action.label}
                    </button>
                  ))}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DashboardTable;
