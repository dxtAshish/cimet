import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import HomeWrapper from '../pages/wrapper/HomeWrapper';
import Home from '../pages/Home';
import Menu from '../pages/Menu';
import Login from "../components/Login.jsx"
import Register from "../components/Register.jsx"

import Dashboard from '../dashboard/Dashboard.jsx';
import VenueList from '../pages/fetchList/FetchVenue.jsx';
import CategoryList from '../pages/fetchList/FetchCategorgy.jsx';
import ProtectedRoute from './ProtectedRoute.js';
import Category from '../pages/Category.jsx';

const router = createBrowserRouter([
  {
    path: '/',
    element: <HomeWrapper />,
    children: [
      {
        index: true,
        element: <Home />,
      },
      {
        path:"/menu/:venueId",
        element: <Menu />,
      },
      {
        path:"/category/:category",
        element: <Category />,
      },
      {
        path:"/dashboard",
        element: (
          <ProtectedRoute>
            <Dashboard/>
          </ProtectedRoute>
        ),
      },
      {
        path:"/login",
        element:<Login/>
      },
      {
        path:"/register",
        element:<Register/>
      },
     
    ],
  },
]);

export const Allroutes = () => {
  return <RouterProvider router={router} />;
};
