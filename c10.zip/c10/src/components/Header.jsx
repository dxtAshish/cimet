import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { logoutUser } from "../Redux/Slices/userSlice";
import { setLocation } from "../Redux/Slices/headerSlice";

const Header = () => {
  const dispatch = useDispatch();

  // Access the auth state from Redux
  const { user, token } = useSelector((state) => state.user);
  const { selectedLocation } = useSelector((state) => state.header);

  const isAuthenticated = Boolean(token); // Check if the user is authenticated
  const role = localStorage.getItem("role");
  const isAdmin = isAuthenticated && role === "admin"; // Check if the user is an admin

  const handleLogout = () => {
    dispatch(logoutUser()); // Dispatch the logout action
  };

  const handleLocationChange = (e) => {
    dispatch(setLocation(e.target.value)); // Update the selected location in Redux
  };

  return (
    <header className="antialiased bg-gradient-to-r from-orange-500 to-yellow-400 py-4 px-6 shadow-md">
      <div className="container mx-auto flex justify-between items-center">
        {/* Left Section: Logo/Brand */}
        <Link to="/">
          <div className="text-2xl font-bold text-white">D X T-Food</div>
        </Link>

        {/* Center Section: Location Select (hidden on mobile, visible on larger screens) */}
        <div className="hidden md:block">
          <select
            className="bg-gray-100 border border-yellow-300 text-gray-600 p-2 rounded-lg focus:bg-yellow-400"
            value={selectedLocation} // Bind the value to Redux state
            onChange={handleLocationChange} // Handle location change
          >
            <option value="select" className="bg-yellow-100 text-gray-700">
              Select Location
            </option>
            <option value="Agra" className="bg-yellow-400 text-gray-700">
              Agra
            </option>
            <option value="Delhi" className="bg-yellow-400 text-gray-700">
              Delhi
            </option>
            <option value="Mumbai" className="bg-yellow-400 text-gray-700">
              Mumbai
            </option>
            <option value="Kolkata" className="bg-yellow-400 text-gray-700">
              Kolkata
            </option>
            <option value="Bangalore" className="bg-yellow-400 text-gray-700">
              Bangalore
            </option>
          </select>
        </div>

        {/* Right Section: Login/Sign-in and User Profile */}
        <div className="flex items-center space-x-4">
          <Link to="/">
            <div className="text-2xl font-bold text-white hover:underline hover:text-orange-400">
              Home
            </div>
          </Link>
          {!isAuthenticated ? (
            <>
              {/* Login / Sign-in buttons */}
              <button className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors">
                <Link to="/login">Login</Link>
              </button>
              <button className="bg-transparent text-orange-600 px-4 py-2 rounded-lg border border-orange-600 hover:bg-orange-50 transition-colors">
                <Link to="/register">SignUp</Link>
              </button>
            </>
          ) : (
            <>
              {/* Show Dashboard only if the user is an admin */}
              {isAdmin && (
                <Link to="/dashboard">
                  <button className="bg-transparent text-orange-600 px-4 py-2 rounded-lg border border-orange-600 hover:bg-orange-50 transition-colors">
                    Dashboard
                  </button>
                </Link>
              )}
              {/* Logout button */}
              <button
                onClick={handleLogout}
                className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600"
              >
                Logout
              </button>
            </>
          )}
        </div>
      </div>

      {/* Mobile Location Select */}
      <div className="md:hidden mt-4">
        <select
          className="bg-gray-100 border border-yellow-300 text-gray-600 p-2 w-full rounded-lg"
          value={selectedLocation} // Bind the value to Redux state
          onChange={handleLocationChange} // Handle location change
        >
          <option value="select">Select Location</option>
          <option value="Agra">Agra</option>
          <option value="Delhi">Delhi</option>
          <option value="Mumbai">Mumbai</option>
          <option value="Kolkata">Kolkata</option>
          <option value="Bangalore">Bangalore</option>
        </select>
      </div>
    </header>
  );
};

export default Header;
