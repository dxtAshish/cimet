import React, { useState } from "react";
import Sidebar from "./components/Sidebar";
import Menu from "./components/Menu";
import PageView from "./components/PageView";
import Venue from "./pages/Venue";
import Category from "./pages/Category";
import CategoryList from "../pages/fetchList/FetchCategorgy";
import VenueList from "../pages/fetchList/FetchVenue";

const Dashboard = () => {
  // State to hold pages and the selected page
  const [pages] = useState([
    { id: "1", name: "Category", component:  <CategoryList Component={Category}/>  },
    { id: "2", name: "Venue", component: <VenueList Component={Venue}/>},
  ]);

  const [selectedPage, setSelectedPage] = useState(pages[0]); 


  const handleMenuItemClick = (page) => {
    setSelectedPage(page); 
  };

  return (
    <div className="flex h-screen bg-gray-100">
 
      <Sidebar>
        <Menu pages={pages} onMenuItemClick={handleMenuItemClick} />
      </Sidebar>
      <div className="flex-1 p-6">
        <PageView page={selectedPage.component} />
      </div>
    </div>
  );
};

export default Dashboard;
