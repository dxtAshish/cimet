import { Router } from "express";
import {
  addVenue,
  getAllVenues,
  deleteVenue,
  getVenueById,
  updateVenue,
} from "../controllers/venue.controllere.js";
import { jwtVerify } from "../middlewares/auth.middleware.js";
import { upload } from "../middlewares/multer.middleware.js";

const router = Router();
router.use(jwtVerify);

router.route("/get-venues").get(getAllVenues);
router.route("/upload-venue").post(
  jwtVerify,

  upload.fields([
    {
      name: "thumbnail",
      maxCount: 1,
    },
  ]),

  addVenue
);

router
  .route("/c/:venueId")
  .get(getVenueById)
  .delete(jwtVerify, deleteVenue)
  .patch(jwtVerify, upload.single("thumbnail"), updateVenue);
export default router;
