// src/components/Topbar.js
import React, { useState } from 'react';

const Topbar = ({ profilePic, userName, onLogout }) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  return (
    <div className="bg-blue-500 p-4 flex justify-between items-center fixed w-full lg:relative lg:w-auto">
      <div className="text-white text-lg font-bold">Admin Panel</div>
      <div className="relative">
        <button onClick={toggleDropdown} className="flex items-center focus:outline-none">
          <img
            src={profilePic}
            alt="Profile"
            className="w-10 h-10 rounded-full border-2 border-white mr-2" // Added border and margin-right
          />
          <span className="text-white">{userName}</span>
        </button>
        <div
          className={`absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-2 transition-transform duration-300 ${
            dropdownOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
          }`}
        >
          <button
            onClick={onLogout}
            className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left"
          >
            Logout
          </button>
        </div>
      </div>
    </div>
  );
};

export default Topbar;
