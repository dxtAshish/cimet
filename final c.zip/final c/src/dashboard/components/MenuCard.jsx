import React from 'react';
import { deleteCuisine } from '../../Redux/Slices/cuisineSlice';
import { useDispatch } from 'react-redux';
import { faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
const MenuCard = ({ data }) => {
  const dispatch=useDispatch()
  const handleDelete=(cuisineId)=>{
     dispatch(deleteCuisine(cuisineId))
  }
  console.log(data,"menu")
  return (
    <div >
      {data && data?.map((item) => (
        <div 
          key={item._id} 
          className="bg-white relative p-2 rounded-lg shadow-xl flex flex-col md:flex-row items-center md:items-start justify-between border-b-2 border-gray-500"
        >
          <div className="mb-4 md:mb-0 md:mr-6">
            <h2 className="font-bold text-2xl text-gray-600">{item.title}</h2> 
            <p className="text-gray-500">{item.description}</p> 
            <h3 className='font-bold text-2xl text-gray-600'>{`₹${item.price}`}</h3>

          </div>
          <div className='absolute right-[145px] top-[50px] '>
          <button onClick={()=>handleDelete(item._id)}><FontAwesomeIcon icon={faTrash} className="text-red-600 size-6"/></button>

          </div>
          <div className="flex-shrink-0">
            <img 
              src={item.thumbnail || "https://via.placeholder.com/150"} 
              className="w-full md:w-32 rounded-lg" 
              alt={item.title} 
            />
          </div>
        </div>
      ))}
     </div>
  );
};

export default MenuCard;
