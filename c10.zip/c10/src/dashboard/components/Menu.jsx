import React from 'react';
import MenuItem from './MenuItem';

const Menu = ({ pages, onMenuItemClick }) => {
  return (
    <div className="flex flex-col p-4">
      {pages.map((page) => (
        <MenuItem 
          key={page.id} 
          title={page.name} 
          icon="home"  // Add relevant icons for each page
          onClick={() => onMenuItemClick(page)} 
        />
      ))}
    </div>
  );
};

export default Menu;
