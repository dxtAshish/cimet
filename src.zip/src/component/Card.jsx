import React from "react";
// import pokeball from "../assets/Squirtle.png";
import "./card.css";

const Card = ({ onClick, card, index, isInactive, isFlipped, isDisabled }) => {
  const handleClick = () => {
    if (!isFlipped && !isDisabled) {
      onClick(index);
    }
  };

  const cardClass = `card ${isFlipped ? "is-flipped" : ""} ${
    isInactive ? "is-inactive" : ""
  }`;

  return (
    <div className={cardClass} onClick={handleClick}>
      <div className="card-face card-front-face">
        {/* <img src={pokeball} alt="pokeball" /> */}
      </div>
      <div className="card-face card-back-face">
        <img src={card.image} alt="pokeball" />
      </div>
    </div>
  );
};

export default Card;
