import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";

function App() {
  const UPI = ["ybl", "nbl", "paytm"];
  const [text, setText] = useState("");
  const [show, setShow] = useState(false);
  const [upiText,setUpiText] = useState("");

  function handlesubmit() {
    if (show) {
      alert(`Payment initiated for: ${text}`);
    } else {
      alert("Please enter a valid UPI ID.");
    }
  }

  const handleChange = (e) => {
    const value = e.target.value;
    const result = /^[a-zA-Z0-9._-]+@+$/.test(value);
    setText(value);

   
    setShow(result);
  };

  return (
    <>
      <input
        type="text"
        value={text}
        onChange={handleChange}
        placeholder="Enter your UPI ID"
      />

      {show && (
        <ul>
          {UPI.map((item) => (
            <li key={item} onClick={()=>{
              setText((prev)=>prev+item);
              setShow(false);
            }}>{item}</li>
          ))}
        </ul>
      )}

      <button onClick={handlesubmit}>Pay</button>
    </>
  );
}

export default App;
