import React, { useState } from "react";
import AvatarCircle from "./AvatarCircle";
import "./avatarStyle.css";
import Modal from "./Modal";
const Avatar = () => {
  const [toggleModal, setToggleModal] = useState(false);
  const [avatarName, setAvatarName] = useState("");
  const [avatarArr, setAvatarArr] = useState([]);
  const color = ["#3cb371", "#ee82ee", "#6a5acd", "pink", "#ff6347"];
  const index = Math.floor(Math.random() * color.length);
  const handleModal = () => {
    setToggleModal(!toggleModal);
  };
  const submitAvatarName=()=>{
    setAvatarArr((prev)=>[...prev,avatarName])
  }
  console.log(avatarArr);
  return (
    <div className="wrapper">
      <div className="box">
        {toggleModal ? (
          <Modal
            setToggleModal={setToggleModal}
            setAvatarName={setAvatarName}
            submitAvatarName={submitAvatarName}
            avatarName={avatarName}
          />
        ) : (
          <></>
        )}
        {avatarArr.map((name, index) => (
          <AvatarCircle
            key={index}
            name={name}
            setAvatarArr={setAvatarArr}
            color={color[index]}
          />
        ))}
        <button className="add-btn" onClick={handleModal}>
          +
        </button>
      </div>
    </div>
  );
};

export default Avatar;
