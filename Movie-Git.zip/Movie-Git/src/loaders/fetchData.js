import axios from "axios";
import { API_OPTIONS } from "../utils/constants";


export const fetchData= async()=>{
    const popularData=await axios.get("https://api.themoviedb.org/3/movie/popular",API_OPTIONS)
    console.log(popularData);
    return popularData.data.results
}

