import axios from "axios";
import { API_OPTIONS } from "../utils/constants";
import { useSelector } from "react-redux";
// import { movieFilter } from "../store/slices/movieFilterSlice";



export const fetchMovieData = async () => {
const {genre,sortBy,page}=useSelector((state)=>state.movieFilter)

const API_URLS = [

`https://api.themoviedb.org/3/discover/movie?page=${page}&with_genres=${genre}&sort_by=${sortBy}`,


];

  const arrayOfPromises = API_URLS.map((url) => axios.get(url, API_OPTIONS));
  const movieData = await Promise.allSettled(arrayOfPromises);
  console.log(movieData)
  return movieData;
};





