import React from "react";
import CircularRange from "./CircularRange";
import { Link } from "react-router-dom";
const Card = ({ value }) => {
  console.log(value);

  const date = new Date(value.release_date || value.first_air_date);

  const year = date.getFullYear();
  const monthIndex = date.getMonth();
  const day = date.getDate();

  const monthsAbbreviated = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];
  const month = monthsAbbreviated[monthIndex];

  const formattedDate = `${month} ${day}, ${year}`;

  const limitTitleToFourWords = (title) => {
    if (!title) return "";
    const words = title.split(" ");
    return words.slice(0, 3).join(" ") + (words.length > 3 ? "..." : "");
  };

  return (
    <Link to={`/movies/${value.id}`}>
    <div className="flex flex-col hover:shadow-xl">
      <div className="w-[225px] rounded-[10px] bg-cover bg-center relative ">
        <img
          src={`https://image.tmdb.org/t/p/original/${value.poster_path}`}
          className="w-full h-auto rounded-[10px]"
          alt="Harry Potter"
        />
        <div className="rounded-full absolute bottom-[-35px] right-[145px] flex items-center justify-center ">
          <CircularRange value={value.vote_average.toFixed(1)} />
        </div>
      </div>
      <div className="mt-10 flex flex-col gap-3">
        <p className="text-[#f3f4f5] text-xl text-wrap">
          {limitTitleToFourWords(value.title || value.name)}
        </p>
        <p className="text-[#757a83] text-sm">{formattedDate}</p>
      </div>
    </div>
    </Link>
  );
};

export default Card;
