import React from 'react';

const PageView = ({ page }) => {
  return (
    <div className="bg-gradient-to-b from-yellow-600 to-yellow-800 rounded-lg shadow-md p-6">
      {page}
    </div>
  );
};

export default PageView;
