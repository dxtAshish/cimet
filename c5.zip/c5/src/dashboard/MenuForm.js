import React, { useState } from 'react';
import axios from 'axios';

const MenuForm = ({ venue, fetchVenues }) => {
  const [menuData, setMenuData] = useState({
    name: '',
    price: ''
  });

  const { name, price } = menuData;

  const onChange = (e) => setMenuData({ ...menuData, [e.target.name]: e.target.value });

  const addMenu = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post(`http://localhost:5000/api/venues/${venue._id}/menu`, menuData, {
        headers: { 'x-auth-token': token }
      });
      fetchVenues(); // Refresh the venues after adding a menu item
      setMenuData({ name: '', price: '' }); // Reset form fields
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <form onSubmit={addMenu} className="bg-gray-50 p-4 rounded-lg shadow-md mt-4">
      <h3 className="text-xl font-semibold mb-4">Add Menu Item for {venue.name}</h3>
      
      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="name">Menu Name</label>
        <input
          type="text"
          name="name"
          value={name}
          onChange={onChange}
          placeholder="Menu Item Name"
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
          required
        />
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="price">Price</label>
        <input
          type="number"
          name="price"
          value={price}
          onChange={onChange}
          placeholder="Price"
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
          required
        />
      </div>

      <button
        type="submit"
        className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
      >
        Add Menu Item
      </button>
    </form>
  );
};

export default MenuForm;
