import mongoose from "mongoose";
import { Cuisine } from "../models/cuisine.model.js";
import { Venue } from "../models/venue.model.js";
import { ApiError } from "../utils/APIErrors.js";
import { ApiResponse } from "../utils/ApiResponse.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { uploadOnCloudinary } from "../utils/Cloudinary.js";
import { isValidObjectId } from "mongoose";
const getAllCuisine = asyncHandler(async (req, res) => {
    const { venueId } = req.params;
    const { page = 1, limit = 10 } = req.query;
  
    // Check if the venueId is valid
    if (!isValidObjectId(venueId)) {
      throw new ApiError(400, "Invalid venue ID");
    }
  
    // Check if the venue exists
    const venue = await Venue.findById(venueId);
    if (!venue) {
      throw new ApiError(404, "Venue not found");
    }
  
    // Aggregate query to fetch all cuisines for the given venue
    const allCuisine = await Venue.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(venueId), // Match the venue by its ID
        },
      },
      {
        $lookup: {
          from: "cuisines", // The name of the Cuisine collection
          localField: "_id", // Venue's _id field
          foreignField: "venue", // The field in Cuisine that references the venue (likely 'venue' field in your Cuisine schema)
          as: "allCuisine",
        },
      },
    //   {
    //     $unwind: "$allCuisine", // Unwind the array if you want individual cuisine items
    //   },
      {
        $project: {
          "allCuisine._id": 1,
          "allCuisine.title": 1,  // Adjust the fields to include the desired fields from Cuisine
          "allCuisine.price": 1,
          "allCuisine.description": 1,
        },
      },
      {
        $skip: (page - 1) * limit, // Pagination
      },
      {
        $limit: Number(limit), // Limit the number of results
      },
    ]);
  
    if (!allCuisine || allCuisine.length === 0) {
      throw new ApiError(404, "No cuisines found for this venue");
    }
  
    res.status(200).json(new ApiResponse(200, allCuisine, "All cuisines fetched successfully"));
  });
  
const getCuisineByCategory = asyncHandler(async (req, res) => {});
const addCuisine = asyncHandler(async (req, res) => {
    const { title, price, description,category } = req.body;
    const thumbnailLocalPath = req.files?.thumbnail?.[0]?.path;
    // console.log(category,title,"wee")
  const { venueId } = req.params;
  if (!title) {
    throw new ApiError(400, "cuisine title does not found");
  }
  if (!price) {
    throw new ApiError(400, "cuisine price does not found");
  }
  if (!description) {
    throw new ApiError(400, "cuisine description does not found");
  }
  if (!category) {
    throw new ApiError(400, "cuisine category does not found");
  }
  if (!thumbnailLocalPath) {
    throw new ApiError(400, "Cuisine image is required");
  }
 
  const thumbnail = await uploadOnCloudinary(thumbnailLocalPath);
  if (!thumbnail) {
    throw new ApiError(400, "Image upload failed");
  }

  const newCusine = await Cuisine.create({
    title,
    price,
    description,
    thumbnail: thumbnail.url,
    category,
    venue: new mongoose.Types.ObjectId(venueId),
  });
  return res
    .status(200)
    .json(new ApiResponse(200, newCusine, "comment added successfully"));
});

const updateCuisine = asyncHandler(async (req, res) => {
  const { title, price, description } = req.body;

  const { cuisineId } = req.params;
  if (!cuisineId) {
    throw new ApiError(400, "not found Venue id");
  }

  const updateCuisine = Cuisine.findByIdAndUpdate(
    cuisineId,
    {
      $set: {
        title: title,
        description: description,
        location: price,
      },
    },
    {
      new: true,
    }
  );
  return res
    .status(200)
    .json(new ApiResponse(200, updateComment, "comment updated successfully"));
});

const deleteCuisine = asyncHandler(async (req, res) => {
  const { cuisineId } = req.params;

  const deleteCuisine = await cuisine.findByIdAndDelete(cuisineId);
  return res
    .status(200)
    .json(new ApiResponse(200, deleteCuisine, "comment deleted successfully"));
});

export { getAllCuisine, addCuisine, updateCuisine, deleteCuisine };
