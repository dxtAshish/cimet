import React from "react";
import Layout from "./Layout";
import GameScreen from "./Screen/GameScreen/GameScreen";
import { BrowserRouter as Router,Routes,Route } from "react-router-dom";
import Admin from "./Screen/Users/Users";
import Login from "./Screen/Login/Login";
import Dashboard from "./Screen/Dashboard/Dashboard";
function App() {
  return (
    <Router>
  <Routes>
    <Route exact path="/login" element={<Login/>}/>
  </Routes>
      
      <Layout>
      <Routes>
    <Route exact path="/game-screen" element={<GameScreen/>}/>
    <Route exact path="/admin" element={<Admin/>}/>
    <Route exact path="/" element={<Dashboard/>}/>

      </Routes>
      </Layout>
    </Router>
  );
}

export default App;
