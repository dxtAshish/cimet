import React from 'react';
import Category from '../components/Category';
import Card from '../components/Card';
import CategoryList from './fetchList/FetchCategorgy';
import VenueList from './fetchList/FetchVenue';
import Hero from '../components/Hero';

const Home = () => {
  return (
    <div>
      {/* Hero Section */}
      <Hero />
      
      {/* Category Section */}
      <div className='flex flex-col justify-center items-center bg-white py-12'>
        <h1 className='text-3xl md:text-4xl font-extrabold text-gray-800 mb-6'>
          Categories
        </h1>
        <CategoryList Component={Category} />
      </div>
      
      {/* Venue Section */}
      <div className='flex flex-col justify-center items-center bg-gray-100 py-12'>
        <h1 className='text-3xl md:text-4xl font-extrabold text-gray-800 mb-6'>
          You Might Like These Venues
        </h1>
        <VenueList Component={Card} />
      </div>
    </div>
  );
};

export default Home;
