import React from 'react';
import { Link } from 'react-router-dom';

const Category = ({ data }) => {
  return (
    <div className="flex flex-wrap justify-center">
      {data.map((item) => (
         <Link key={item._id} to={`/category/${item.dishName}`}>
        <div
          // key={item._id}
          className="w-32 h-32  flex flex-col items-center justify-center m-2 p-2 rounded-full overflow-hidden"
        >
          <img
            src={item.thumbnail}
            alt={item.dishName}
            className="h-24 w-24 object-cover rounded-full border-4 border-white"
          />
          <h3 className="text-gray-800 font-bold text-center mt-2">{item.dishName}</h3>
        </div>
        </Link>
      ))}
    </div>
  );
};

export default Category;
