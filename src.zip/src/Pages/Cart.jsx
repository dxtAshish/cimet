import React, { useContext, useEffect } from 'react'
import { useCart } from '../Context/CartContext'
import Card from '../components/Card'

const Cart = () => {
   
    const {cart}=useCart()
    // console.log(cart)
    const arr=localStorage.getItem('cart')
    const data=JSON.parse(arr)

    useEffect(()=>{
        console.log(cart,'cart')
    },[cart])
  return (
    <div>
      {cart.map((item)=>{
           
      return  <Card item={item} key={item.id}/>
      })}
    </div>
  )
}

export default Cart
