import React from 'react'
import MenuCard from '../components/MenuCard'

const Menu = () => {
  return (
    <div>
        <MenuCard/>
    </div>
  )
}

export default Menu