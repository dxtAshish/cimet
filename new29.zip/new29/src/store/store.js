import { configureStore } from '@reduxjs/toolkit';
import movieFilterReducer from "./slices/movieFilterSlice.js" 

export const store = configureStore({
  reducer: {
    movieFilter: movieFilterReducer, // Add your reducer to the store
  },
});
