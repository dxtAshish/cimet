import React, { useState } from "react";
import CuisineList from "../../pages/fetchList/FetchCuisine";
import MenuCard from "./MenuCard";
// import DynamicFormModal from "./DynamicFormModal"; // Import DynamicFormModal
import DynamicFormModal from "./DynamicModal";

const MenuListModal = ({ isOpen, onClose, venueId }) => {
  const [isDynamicModalOpen, setIsDynamicModalOpen] = useState(false);
  const [menuItems, setMenuItems] = useState([]); // Menu items state

  // Handle opening of DynamicFormModal
  const openDynamicFormModal = () => {
    setIsDynamicModalOpen(true);
  };

  // Handle closing of DynamicFormModal
  const closeDynamicFormModal = () => {
    setIsDynamicModalOpen(false);
  };

  // Handle form submission
  const handleFormSubmit = (formData) => {
    console.log("Form Data Submitted:", formData);
    // Here you would typically call an API to save the data
    // For now, just close the modal after submission
    closeDynamicFormModal();
  };

  // Define form fields for the DynamicFormModal
  const formFields = [
    { key: "name", label: "Name", type: "text" },
    { key: "price", label: "Price", type: "text" },
    { key: "description", label: "Description", type: "textarea" },
    { key: "image", label: "Image", type: "file" }
  ];

  // Handle delete action for a menu item
  const handleDelete = (itemId) => {
    const updatedMenuItems = menuItems.filter((item) => item._id !== itemId);
    setMenuItems(updatedMenuItems); // Update the state after deletion

    // Call API to delete the item from the backend if needed
    // Example: axios.delete(`/api/menu/${itemId}`)
  };

  // Return null if modal is not open
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-gray-700 bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg w-[80vw] h-[80vh] overflow-hidden shadow-lg">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-2xl font-bold">Menu List</h3>
          <button onClick={onClose} className="text-red-500">
            Close
          </button>
        </div>
        <div className="mb-4">
          {/* Add Button that opens the DynamicFormModal */}
          <button
            onClick={openDynamicFormModal}
            className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:shadow-lg hover:from-yellow-500 hover:to-orange-600 transition-all duration-300 ease-in-out"
          >
            Add
          </button>
        </div>
        <div className="menu-list overflow-y-auto max-h-[60vh]">
          {/* Fetch and display Cuisine List */}
          <CuisineList venueId={venueId} Component={MenuCard} />

          {/* Render the menu items with Delete functionality */}
          <div>
            {menuItems.map((item) => (
              <div key={item._id} className="flex justify-between items-center mb-4">
                <MenuCard item={item} />
                <button
                  onClick={() => handleDelete(item._id)}
                  className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-all duration-300 ease-in-out"
                >
                  Delete
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Dynamic Form Modal */}
      <DynamicFormModal
        isOpen={isDynamicModalOpen}
        onClose={closeDynamicFormModal}
        title="Add Menu Item"
        fields={formFields}
        onSubmit={handleFormSubmit}
      />
    </div>
  );
};

export default MenuListModal;
