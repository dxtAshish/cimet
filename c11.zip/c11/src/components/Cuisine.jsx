const Cuisine = ({ data }) => {
    return (
      <div className="flex flex-wrap justify-center gap-6 p-4">
        {data.map((cuisine) => (
           
          <div key={cuisine._id} className="bg-white p-6 rounded-lg shadow-lg max-w-xs transform transition-transform hover:scale-105">
            <div className="overflow-hidden rounded-lg">
              {/* Thumbnail or image section */}
              <img
                src={cuisine.thumbnail || "https://via.placeholder.com/150"}
                alt={cuisine.title}
                className="w-full h-48 object-cover mb-4 rounded-lg"
              />
            </div>
  
            {/* Text details */}
            <div className="text-center">
              <h3 className="text-2xl font-bold text-gray-800 mb-2">{cuisine.title}</h3>
              <p className="text-gray-600 text-sm mb-2">{cuisine.description}</p>
              <p className="text-lg font-semibold text-gray-900">₹{cuisine.price}</p>
            </div>
  
            {/* Hover effect */}
            <div className="mt-4 text-center">
              <button className="px-4 py-2 bg-yellow-500 text-white rounded-full hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:ring-opacity-50 transition">
                Order Now
              </button>
            </div>
          </div>
        
        ))}
      </div>
    );
  };
  
  export default Cuisine;
  