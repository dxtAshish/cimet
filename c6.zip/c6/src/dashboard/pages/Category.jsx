import React, { useState } from "react";
import DashboardTable from "../components/DashboardTable";
import DynamicFormModal from "../components/DynamicModal"; // Import your modal component
import { useDispatch } from "react-redux";
import { addCategory } from "../../Redux/Slices/categorySlice";

const Category = ({ data }) => {
    const dispatch=useDispatch()
  const [showModal, setShowModal] = useState(false);  // State to control modal visibility

  // Define columns for the Category table
  const columns = [
    { key: "_id", header: "ID" },
    { key: "dishName", header: "Title" },
    {
      key: "thumbnail",
      header: "Image",
      render: (thumbnail) => <img src={thumbnail} alt="thumbnail" className="h-10 w-10" />,
    },
  ];

  // Define actions for each row (optional)
  const actions = [
    {
      label: "Edit",
      className: "bg-blue-500 hover:bg-blue-700",
      onClick: (row) => console.log("Edit", row),
    },
    {
      label: "Delete",
      className: "bg-red-500 hover:bg-red-700",
      onClick: (row) => console.log("Delete", row),
    },
  ];

  // Fields for the modal (this can be dynamic based on your requirements)
  const modalFields = [
    { key: "dishName", label: "Dish Name", type: "text" },
    { key: "thumbnail", label: "Image", type: "file" },  // File input for image upload
  ];

  // Handle form submission for adding new category
  const handleAddNewCategory = (formData) => {
    console.log("New Category Data:", formData);
    dispatch(addCategory(formData))
    // You can add your logic here to send this form data to an API or save it

    setShowModal(false); // Close the modal after submission
  };

  return (
    <div>
      <h2>Category Dashboard</h2>
      <button
        className="bg-green-500 text-white px-4 py-2"
        onClick={() => setShowModal(true)}
      >
        Add+
      </button>

      {/* Display the table */}
      <DashboardTable columns={columns} data={data} actions={actions} />

      {/* DynamicFormModal for adding or editing category */}
      <DynamicFormModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title="Add New Category"
        fields={modalFields}
        onSubmit={handleAddNewCategory}
      />
    </div>
  );
};

export default Category;
