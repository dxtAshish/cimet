import React from 'react';

const Sidebar = ({ children }) => {
  return (
    <div className="w-[230px] h-full bg-yellow-700 z-50 flex flex-col">
      {children}
    </div>
  );
};

export default Sidebar;
