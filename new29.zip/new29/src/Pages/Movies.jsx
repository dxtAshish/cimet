import React, { useEffect, useState } from "react";
import DropDown from "../Components/DropDown";
import Card from "../Components/Card";
import { API_OPTIONS } from "../utils/constants";
import axios from "axios";
// const [loading, setLoading] = useState(false

import { useLoaderData } from "react-router-dom";

const Movies = () => {
  const [list, setList] = useState([]);
  useEffect(() => {
    async function callFunc() {
      const data = await axios.get(
        "https://api.themoviedb.org/3/genre/movie/list",
        API_OPTIONS
      );
      setList(data.data.genres);
    }
    callFunc();
  }, []);

  const arry = [
    {
      id: "popularity.desc",
      name: "Popularity Descending",
    },
    {
      id: "popularity.asc",
      name: "Popularity Ascending",
    },
    {
      id: "vote_average.desc",
      name: "Rating Descending",
    },
    {
      id: "vote_average.asc",
      name: "Rating Ascending",
    },
    {
      id: "primary_release_date.asc",
      name: "Release Date Ascending",
    },
    {
      id: "primary_release_date.desc",
      name: "Release Date Descending",
    },
    {
      id: "original_title.asc",
      name: "Title(A-Z)",
    },
  ];
  const movieData = useLoaderData();
  const movieList = movieData[0].value.data.results;
  console.log(movieList);
  // console.log(movieData)
  return (
    <div className="w-100vw h-100vh bg-[#04152d] pt-[100px] px-[100px]">
      <div className="flex justify-between items-center h-[100px]">
        <div>
          <p className="text-white text-2xl font-light">Explore Movies</p>
        </div>
        <div className="flex justify-center items-center">
          <DropDown dropDownName="Select genres" arr={list} />
          <DropDown dropDownName="Sort by" arr={arry} />
        </div>
      </div>
      <div className="flex flex-wrap w-full gap-16">
        {movieList.map((value) => (
          <Card value={value} key={value.id} />
        ))}
      </div>
    </div>
  );
};

export default Movies;
