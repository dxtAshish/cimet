import { API } from '../API';

export const fetchAllUsers = async () => {
    return await API.get('/users');
}

export const fetchUserById = async (id) => {
    return await API.get(`/users/${id}`);
}
