import React, { useState } from 'react';

const Toggle = ({ name1, name2 }) => {
  const [isToggled, setIsToggled] = useState('Day');

  const handleToggle = (day) => {
    setIsToggled(day);
  };

  return (
    <div className="w-[300px] max-w-sm rounded flex flex-col">
        <div className='mx-8 shadow-lg rounded-full h-10 mt-4 flex p-1 items-center'>
            <div className="w-full flex justify-center">
                <button
                onClick={()=>handleToggle('Day')}
                className={`flex-1 text-center py-2 rounded-full transition ${isToggled==='Day'?'bg-gray-200':'bg-transparent'}`}
                >
                    day
                </button>
            </div>
            <div className="w-full flex justify-center">
                <button
                onClick={()=>handleToggle('Week')}
                className={`flex-1 text-center py-2 rounded-full transition ${isToggled==='Week'?'bg-gray-200':'bg-transparent'}`}
                >
                    week
                </button>
                <span className={`elSwitch bg-black shadow text-white flex items-center justify-center w-1/2 rounded-full h-8 transition-all absolute top-[4px] ${isToggled==='Day'? 'left-1' : '[calc(100%-50%)]'} `}></span>
            </div>
        </div>
     
     
    </div>
  );
};

export default Toggle;
