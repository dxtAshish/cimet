import { API } from "."

export const adminLogin = async () => {
    return await API.post('/login');
}