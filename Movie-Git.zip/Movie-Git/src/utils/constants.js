export const API_OPTIONS = {
    method: 'GET',
    headers: {
      accept: 'application/json',
      Authorization: `Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJhYzNlODdiMGU3ZGJiZGQ1Yjg0ZmQzMWEwYjBjODY4ZSIsIm5iZiI6MTcyNzI4NDY0NS4yMzc1NTQsInN1YiI6IjY2ZjQ0NTA3NzQwMTM4NjQxZTZhMWQ3MSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.9fwKSriBb3lDchgb_CQmqo5geSnBQhH2d3N48uh5DWg`
    }
  };
