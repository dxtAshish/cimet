import { BaseUrl } from "./API";
import axios from "axios";
export const registerApi = async () => {
    try {
      const response = await axios.post(`${BaseUrl}/api/users/`);
      const data = await response.json();
      return data;
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }