import mongoose, { Schema } from "mongoose";
import mongooseAggregatePaginate from "mongoose-aggregate-paginate-v2";
const venueSchema = new Schema(
  {

    title: {
      type: String,
      required: true,
    },
    image: {
        type: String,
        required: true,
      },
    description: {
      type: String,
      required: true,
    },
    location: {
        type: String,
        required: true,
      },
    menu:[{
        type:Schema.Types.ObjectId,
        ref:"cuisine"
       }
    ],

  },
  {
    timestamps: true,
  }
);
videoSchema.plugin(mongooseAggregatePaginate);
export const Video = mongoose.model("Venue", venueSchema);