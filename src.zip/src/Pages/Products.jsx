import React from "react";
import { useLoaderData } from "react-router-dom";
import Card from "../components/Card";

const Products = () => {
  const data = useLoaderData();
  return (
    <>
    <div className="flex flex-wrap justify-center items-center ">
      {data.map((item) => (
        <Card item={item} key={item.id} />
      ))}
    </div>
    </>
  );
};

export default Products;
