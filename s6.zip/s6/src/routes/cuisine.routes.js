import { Router } from "express";
import {  addCuisine, deleteCuisine, getAllCuisine, updateCuisine } from "../controllers/cuisine.contorller.js";
import { upload } from "../middlewares/multer.middleware.js";
const router=Router()

router.route("/allcuisine/:venueId").get(getAllCuisine)
router.route("/addcuisne/:venueId").post(
    upload.fields([
        {
          name: "thumbnail",
          maxCount: 1,
        },]),
    addCuisine)
router.route("/deletecuisine").post(deleteCuisine)
router.route("/editcuisine").patch(updateCuisine)

export default router