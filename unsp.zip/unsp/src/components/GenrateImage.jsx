import React, { useState } from 'react'

const ACCESS_KEY = 'tiC8yPQmKp4J8ijfNXjnyzU7P5ei8GPBSdkaCC-PdO4';
const BASE_URL = 'https://api.unsplash.com';

const GenrateImage = () => {
  const [formData, setFormData] = useState({
    category: '',
    numberOfPhotos: 1,
    orientation: '',
    random: false
  });

  const [images, setImages] = useState([]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    let url;

    // If random is checked, fetch random images without category
    if (formData.random) {
      url = `${BASE_URL}/photos/random?count=${formData.numberOfPhotos}&client_id=${ACCESS_KEY}`;
    } else {
      
      const { category, numberOfPhotos, orientation } = formData;
      url = `${BASE_URL}/search/photos?query=${category}&orientation=${orientation}&per_page=${numberOfPhotos}&client_id=${ACCESS_KEY}`;
    }

    try {
      const response = await fetch(url);
      const data = formData.random ? response.json() : await response.json();
      setImages(formData.random ? data : data.results);
    } catch (error) {
      console.error('Error fetching images:', error);
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-100">
      <div>
        <form 
          onSubmit={handleSubmit}
          className="flex flex-col gap-6 bg-white p-8 rounded-lg shadow-lg w-[350px] border border-gray-300"
        >
          <h2 className="text-2xl font-semibold text-gray-700 text-center mb-4">Generate Image</h2>
          
          <input 
            type="text" 
            name="category"
            value={formData.category}
            onChange={handleChange}
            placeholder="Search Category" 
            disabled={formData.random} // Disable when "random" is checked
            className={`p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-300 ${formData.random ? 'bg-gray-200' : ''}`}
          />
          
          <input 
            type="number" 
            name="numberOfPhotos"
            value={formData.numberOfPhotos}
            onChange={handleChange}
            placeholder="Number of images" 
            className="p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-300"
          />
          
          <div className="flex items-center gap-3">
            <label htmlFor="random" className="text-gray-600">Random</label>
            <input 
              type="checkbox" 
              id="random" 
              name="random"
              checked={formData.random}
              onChange={handleChange}
              className="w-5 h-5"
            />
          </div>
          
          <select 
            name="orientation" 
            value={formData.orientation}
            onChange={handleChange}
            className="p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-300"
          >
            <option value="">Orientation</option>
            <option value="landscape">Horizontal</option>
            <option value="portrait">Vertical</option>
          </select>
          
          <button 
            type="submit" 
            className="w-full py-3 bg-blue-500 text-white font-semibold rounded-md hover:bg-blue-600 transition-colors"
          >
            Submit
          </button>
        </form>

        {/* Displaying Images */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {images.map((image) => (
            <img 
              key={image.id} 
              src={image.urls.small} 
              alt={image.alt_description} 
              className="w-full h-64 object-cover rounded-lg shadow-md"
            />
          ))}
        </div>
      </div>
    </div>
  )
}

export default GenrateImage;
