import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { BaseUrl } from "../../services/API";


export const fetchAllCuisines = createAsyncThunk(
  "cuisines/fetchAll",
  async ({ venueId, page = 1, limit = 10 }, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${BaseUrl}/cuisine/allcuisine/${venueId}`, {
        params: { page, limit },
      });
      const cuisines = response.data.data.length > 0 ? response.data.data[0].allCuisine : [];
      return cuisines;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);


export const addCuisine = createAsyncThunk(
  "cuisines/add",
  async ({ venueId, formData }, { rejectWithValue }) => {
    try {
      const response = await axios.post(
        `${BaseUrl}/cuisine/addcuisne/${venueId}`,
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);


export const editCuisine = createAsyncThunk(
  "cuisines/edit",
  async ({ cuisineId, formData }, { rejectWithValue }) => {
    try {
      const response = await axios.put(
        `${BaseUrl}/cuisine/update/${cuisineId}`,
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);


export const deleteCuisine = createAsyncThunk(
  "cuisines/delete",
  async (cuisineId, { rejectWithValue }) => {
    try {
      const response = await axios.delete(
        `${BaseUrl}/cuisine/deletecuisine/${cuisineId}`
      );
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);


export const getCuisineByCategory = createAsyncThunk(
  "cuisines/cuisinesByCategory",
  async (category, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${BaseUrl}/cuisine/categorycuisine/${category}`);
      console.log(response.data.data)
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);


const cuisineSlice = createSlice({
  name: "cuisines",
  initialState: {
    cuisines: [],
    loading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
  
    builder
      .addCase(fetchAllCuisines.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAllCuisines.fulfilled, (state, action) => {
        state.loading = false;
        state.cuisines = action.payload;
      })
      .addCase(fetchAllCuisines.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });


    builder
      .addCase(addCuisine.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addCuisine.fulfilled, (state, action) => {
        state.loading = false;
        state.cuisines.push(action.payload);
      })
      .addCase(addCuisine.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });

   
    builder
      .addCase(editCuisine.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(editCuisine.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.cuisines.findIndex(
          (cuisine) => cuisine._id === action.payload._id
        );
        if (index !== -1) {
          state.cuisines[index] = action.payload;
        }
      })
      .addCase(editCuisine.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });

    builder
      .addCase(deleteCuisine.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteCuisine.fulfilled, (state, action) => {
        state.loading = false;
        state.cuisines = state.cuisines.filter(
          (cuisine) => cuisine._id !== action.payload._id
        );
      })
      .addCase(deleteCuisine.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });

    
    builder
      .addCase(getCuisineByCategory.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getCuisineByCategory.fulfilled, (state, action) => {
        state.loading = false;
        state.cuisines = action.payload; 
      })
      .addCase(getCuisineByCategory.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export default cuisineSlice.reducer;
