import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";

import { getCuisineByCategory } from "../../Redux/Slices/cuisineSlice";
const CuisineByCategoryList = ({ category, Component }) => {
  const dispatch = useDispatch();
  const { cuisines, loading, error } = useSelector((state) => state.cuisine);
  useEffect(() => {
    if (category) {
      console.log("chal rha hai bhai") 
      dispatch(getCuisineByCategory(category));
    }
  }, [dispatch, category]);  
  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;
  return <Component data={cuisines} />;
};

export default CuisineByCategoryList;
