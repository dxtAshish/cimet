
import React, { useState } from "react";
import AvatarCircle from "./AvatarCircle";
import "./avatarStyle.css";
import Modal from "./Modal";

const Avatar = () => {
  const [toggleModal, setToggleModal] = useState(false);
  const [avatarArr, setAvatarArr] = useState([]);
  const colors = ["#3cb371", "#ee82ee", "#6a5acd", "pink", "#ff6347"];

  const handleModal = () => {
    setToggleModal(!toggleModal);
  };

  const addAvatar = (name) => {
    setAvatarArr((prev) => [...prev, name]); 
  };

  return (
    <div className="wrapper">
      <div className="box">
        {toggleModal && (
          <Modal
            setToggleModal={setToggleModal}
            addAvatar={addAvatar}
          />
        )}
        {avatarArr.map((name, index) => (
          <AvatarCircle
            key={index}
            name={name}
            setAvatarArr={setAvatarArr}
            color={colors[index % colors.length]} 
          />
        ))}
        <button className="add-btn" onClick={handleModal}>
          +
        </button>
      </div>
    </div>
  );
};

export default Avatar;
