import React from 'react'
import Carousel from './components/carousle'
import GenrateImage from './components/GenrateImage'

const App = () => {
  return (
    <div className='flex justify-center items-center'>
<GenrateImage/>
 <Carousel/>
    </div>
  )
}

export default App
