import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";

const ProtectedRoute = ({ children }) => {
  const { user } = useSelector((state) => state.user); // Assuming user info is stored in Redux state
  const role=localStorage.getItem('role')
  console.log(role)
  if (!user || role !== 'admin') {
    return <Navigate to="/login" replace />; // Redirect to login if not authenticated or not admin
  }

  return children;
};

export default ProtectedRoute;
