import React from "react";
import DropDown from "../Components/DropDown";
import Card from "../Components/Card";

const Movies = () => {
  return (
    <div className="w-100vw h-100vh bg-[#04152d] pt-[100px] px-[100px]">
      <div className="flex justify-between items-center h-[100px]">
        <div>
          <p className="text-white text-2xl font-light">Explore Movies</p>
        </div>
        <div className="flex justify-center items-center">
          <DropDown dropDownName="Select genres" />
          <DropDown dropDownName="Sort by" />
        </div>
      </div>
      <div className="flex flex-wrap w-full gap-16">
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>

      </div>
    </div>
  );
};

export default Movies;
