import React, { useState, useEffect } from 'react';

const Carousel = () => {
  const items = [
    'https://via.placeholder.com/600x300?text=Slide+1',
    'https://via.placeholder.com/600x300?text=Slide+2',
    'https://via.placeholder.com/600x300?text=Slide+3',
    'https://via.placeholder.com/600x300?text=Slide+4',
    'https://via.placeholder.com/600x300?text=Slide+5',
    'https://via.placeholder.com/600x300?text=Slide+6',
    'https://via.placeholder.com/600x300?text=Slide+7',
    'https://via.placeholder.com/600x300?text=Slide+8',
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  const prevSlide = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? items.length - 1 : prevIndex - 1
    );
  };

  const nextSlide = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === items.length - 1 ? 0 : prevIndex + 1
    );
  };


  useEffect(() => {
    const intervalId = setInterval(() => {
      nextSlide();
    }, 2000); 

    return () => clearInterval(intervalId); 
  }, [currentIndex]);

  return (
    <div className="relative w-full max-w-lg mx-auto">
      <div className="overflow-hidden relative h-[300px] w-full">
        {items.map((item, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-transform duration-500 ${
              index === currentIndex
                ? 'translate-x-0 opacity-100'
                : index < currentIndex
                ? '-translate-x-full opacity-0'
                : 'translate-x-full opacity-0'
            }`}
          >
            <img
              src={item}
              alt={`Slide ${index + 1}`}
              className="w-full h-full object-cover"
            />
          </div>
        ))}
      </div>

      {/* Navigation Buttons */}
      <button
        onClick={prevSlide}
        className="absolute top-1/2 left-0 transform -translate-y-1/2 bg-black bg-opacity-50 text-white px-4 py-2"
      >
        Prev
      </button>

      <button
        onClick={nextSlide}
        className="absolute top-1/2 right-0 transform -translate-y-1/2 bg-black bg-opacity-50 text-white px-4 py-2"
      >
        Next
      </button>

      {/* <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {items.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`w-3 h-3 rounded-full ${
              currentIndex === index ? 'bg-white' : 'bg-gray-400'
            }`}
          ></button>
        ))}
      </div> */}
    </div>
  );
};

export default Carousel;
