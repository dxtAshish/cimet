import mongoose, { Schema } from "mongoose";
import mongooseAggregatePaginate from "mongoose-aggregate-paginate-v2";
const venueSchema = new Schema(
  {

    title: {
      type: String,
      required: true,
    },
    thumbnail: {
        type: String,
        required: true,
      },
    description: {
      type: String,
      required: true,
    },
    location: {
        type: String,
        required: true,
      },
    menu:[{
        type:Schema.Types.ObjectId,
        ref:"cuisine"
       }
    ],

  },
  {
    timestamps: true,
  }
);
venueSchema.plugin(mongooseAggregatePaginate);
export const Venue = mongoose.model("Venue", venueSchema);