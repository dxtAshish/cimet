import { useLoaderData, Link } from 'react-router-dom';
import { CarouselCustomNavigation } from '../components/Slider'; 
import Card from '../components/Card';

const Home = () => {
    const data = useLoaderData();
    console.log(data, "data");

    return (
        <div className='w-full'>
            
            <div className='flex flex-wrap justify-center items-center'>
                
                {data.map((item) => (
                    <Card item={item} key={item.id} />
                ))}
            </div>
        </div>
    );
}

export default Home;