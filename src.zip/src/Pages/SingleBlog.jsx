import React from 'react'
import { useLoaderData } from 'react-router-dom'

const SingleBlog = () => {
    const data=useLoaderData()
  return (
    <div className='w-[500px] py-10 bg-gray-900 text-gray-300'>
      {data.title}
    </div>
  )
}

export default SingleBlog
