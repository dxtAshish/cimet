// src/components/VenueList.js

import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchAllVenues } from "../../Redux/Slices/venueSlice";
import Pagination from "../../components/Pagination";

const VenueList = ({ Component }) => {
  const dispatch = useDispatch();
  const { venues, loading, error } = useSelector((state) => state.venues);

  const [page, setPage] = useState(1);
  const limit = 10;

  useEffect(() => {
    dispatch(fetchAllVenues({ page, limit }));
  }, [dispatch, page]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  const hasNextPage = venues.length === limit;

  return (
    <div>
      <Component data={venues} />
      <Pagination page={page} setPage={setPage} hasNextPage={hasNextPage} />
    </div>
  );
};

export default VenueList;
