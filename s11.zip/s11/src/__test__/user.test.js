import request from 'supertest';
import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';
import { app } from '../app.js';  // Assuming app is exported from your Express setup
import { User } from '../models/user.model.js';  // Assuming the User model is here

let mongoServer;

beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  const uri = mongoServer.getUri();
  await mongoose.connect(uri);
});

afterAll(async () => {
  await mongoose.disconnect();
  await mongoServer.stop();
});

describe('User Controller', () => {

  // Test the register user functionality
  describe('POST /register', () => {
    it('should register a new user successfully', async () => {
      const response = await request(app)
        .post('/api/v1/users/register')
        .send({
          fullName: 'John Doe',
          email: 'johndoe@example.com',
          password: 'password123',
          role: 'user'
        });
      expect(response.status).toBe(201);
      expect(response.body.data.email).toBe('johndoe@example.com');
    });

    it('should throw an ApiError with message if email already exists', async () => {
       // await User.create({ fullName: 'John Doe', email: 'johndoe@example.com', password: 'password123' });
      
        try {
          await request(app).post('/api/v1/users/register').send({
            fullName: 'Jane Doe',
            email: 'johndoe@example.com',
            password: 'password123',
          });
        } catch (error) {
          expect(error.statusCode).toBe(409);
          expect(error.message).toBe('User with this email already exists');
        }
      });
      
    it('should return a 400 error if required fields are missing', async () => {
        try {
            const response = await request(app)
            .post('/api/v1/users/register')
            .send({
              email: 'johndoe@example.com'
            });
        } catch (error) {
            expect(error.statusCode).toBe(400);
            expect(error.message).toBe('All fields are required');
        }
     

    });
  });

  // Test the login functionality
  describe('POST /login', () => {
    it('should log in a user successfully', async () => {
    //   const user = await User.create({ fullName: 'John Doe', email: 'johndoe@example.com', password: 'password123', role: 'user' });
      const response = await request(app)
        .post('/api/v1/users/login')
        .send({
          email: 'johndoe@example.com',
          password: 'password123',
        });
      expect(response.status).toBe(200);
      expect(response.body.data.user.email).toBe('johndoe@example.com');
      expect(response.body.data.accessToken).toBeDefined();
    });

    it('should return 401 if password is incorrect', async () => {
    //   await User.create({ fullName: 'John Doe', email: 'johndoe@example.com', password: 'password123', role: 'user' });
      try {
        const response = await request(app)
        .post('/api/v1/users/login')
        .send({
          email: 'johndoe@example.com',
          password: 'wrongpassword',
        });
      } catch (error) {
        expect(error.statusCode).toBe(401);
        expect(error.message).toBe('Password incorrect');
      }


    });

    it('should return 404 if user is not found', async () => {
        try {
            const response = await request(app)
            .post('/api/v1/users/login')
            .send({
              email: 'nonexistent@example.com',
              password: 'password123',
            });
        } catch (error) {
            
      expect(error.statusCode).toBe(404);
      expect(error.message).toBe('User not found');
        }

    });
  });

  // Test the logout functionality
  describe('POST /logout', () => {
    it('should log out a user and clear tokens', async () => {
    //   const user = await User.create({ fullName: 'John Doe', email: 'johndoe@example.com', password: 'password123', role: 'user' });
      const loginResponse = await request(app)
        .post('/api/v1/users/login')
        .send({
          email: 'johndoe@example.com',
          password: 'password123',
        });

      const cookies = loginResponse.headers['set-cookie'];
      const response = await request(app)
        .post('/api/v1/users/logout')
        .set('Cookie', cookies)
        .send();
      expect(response.status).toBe(200);
    });
  });

  // Test refreshing the access token
  describe('POST /refresh-token', () => {
   
  

    it('should return 401 if refresh token is invalid', async () => {
        try { // it('should refresh access token', async () => {
            const response = await request(app)
            .post('/api/v1/users/refresh-token')
            .send({ refreshToken: 'invalidtoken' });
        } catch (error) {
            
      expect(error.statusCode).toBe(401);
      expect(error.message).toBe('Invalid refresh token');
        }

    });
  });

 
 

});
