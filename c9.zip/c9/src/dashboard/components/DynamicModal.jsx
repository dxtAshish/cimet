import React, { useState } from "react";

const DynamicFormModal = ({ isOpen, onClose, title, fields, onSubmit }) => {
  const [formData, setFormData] = useState({});

  // Handle changes in form inputs
  const handleInputChange = (e, fieldKey) => {
    // Check if the field is a file input
    if (e.target.type === "file") {
      setFormData((prevData) => ({
        ...prevData,
        [fieldKey]: e.target.files[0], // Store the file object
      }));
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [fieldKey]: e.target.value,
      }));
    }
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData); // Pass the form data to the parent onSubmit handler
  };

  // Return null if modal is not open
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
      <div className="bg-white p-6 rounded-lg w-1/3">
        <h3 className="text-lg font-bold mb-4">{title}</h3>
        <form onSubmit={handleSubmit}>
          {fields.map((field) => (
            <div key={field.key} className="mb-4">
              <label className="block text-sm font-medium text-gray-700">
                {field.label}
              </label>
              {field.type === "text" && (
                <input
                  type="text"
                  className="w-full border p-2"
                  value={formData[field.key] || ""}
                  onChange={(e) => handleInputChange(e, field.key)}
                />
              )}
              {field.type === "textarea" && (
                <textarea
                  className="w-full border p-2"
                  value={formData[field.key] || ""}
                  onChange={(e) => handleInputChange(e, field.key)}
                />
              )}
              {field.type === "file" && (
                <input
                  type="file"
                  className="w-full border p-2"
                  onChange={(e) => handleInputChange(e, field.key)}
                />
              )}
            </div>
          ))}

          <div className="flex justify-end">
            <button
              type="button"
              className="bg-gray-500 text-white px-4 py-2 mr-2"
              onClick={onClose}
            >
              Close
            </button>
            <button
              type="submit"
              className="bg-blue-500 text-white px-4 py-2"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DynamicFormModal;
