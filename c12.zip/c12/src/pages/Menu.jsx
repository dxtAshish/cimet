import React from 'react'
import MenuCard from '../components/MenuCard'
import CuisineList from './fetchList/FetchCuisine'
import { useParams } from 'react-router-dom';

const Menu = () => {
  const { venueId } = useParams();
  return (
    <div>
        <CuisineList venueId={venueId} Component={MenuCard}/>
    </div>
  )
}

export default Menu