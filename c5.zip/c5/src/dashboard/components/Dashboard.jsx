import React, { Component } from 'react';
import Sidebar from './Sidebar';
import Menu from './Menu';
import PageView from './PageView';

class Dashboard extends Component {
  constructor(props) {
    super(props);
    
    this.state = {
      pages: [
        { id: '1', name: 'Dashboard', icon: 'home' },
        { id: '2', name: 'Reports', icon: 'file' },
        { id: '3', name: 'Settings', icon: 'cogs' },
        { id: '4', name: 'Users', icon: 'users' },
        { id: '5', name: 'Analytics', icon: 'chart-bar' },
      ],
      selectedPage: { id: '1', name: 'Dashboard', icon: 'home' }, // Default selected page
    };
  }

  handleMenuItemClick = (page) => {
    this.setState({ selectedPage: page });
  };

  render() {
    return (
      <div className="container-fluid">
        <div className="flex">
          <Sidebar>
            <Menu 
              pages={this.state.pages} 
              onMenuItemClick={this.handleMenuItemClick} 
            />
          </Sidebar>
          <PageView page={this.state.selectedPage} />
        </div>
      </div>
    );
  }
}

export default Dashboard;
