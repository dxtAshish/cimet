import mongoose, { isValidObjectId } from "mongoose";
import { Video } from "../models/video.model.js";
import { User } from "../models/user.model.js";
import { ApiError } from "../utils/APIErrors.js";
import { ApiResponse } from "../utils/ApiResponse.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { uploadOnCloudinary } from "../utils/Cloudinary.js";

const getAllVenues = asyncHandler(async (req, res) => {
  const { page = 1, limit = 10, query, sortBy, sortType, userId } = req.query;
  //TODO: get all videos based on query, sort, pagination
  page = isNaN(page) ? 1 : Number(page);
  limit = isNaN(limit) ? 10 : Number(limit);

  if (page <= 0) {
    page = 1;
  }
  if (limit <= 0) {
    limit = 10;
  }

  let pipeline = [];

  if (isValidObjectId(userId)) {
    pipeline.push({
      $match: {
        owner: new mongoose.Types.ObjectId(userId),
      },
    });
    console.log(pipeline);
  } else {
    pipeline.push({
      $match: {
        $or: [
          { title: { $regex: query, $options: "i" } },
          { description: { $regex: query, $options: "i" } },
        ],
      },
    });
  }

  pipeline.push(
    {
      $project: {
        title: 1,
        videoFile: 1,
        thumbnail: 1,
      },
    },

    {
      $sort: {
        [sortBy]: sortType === "asc" ? 1 : -1,
      },
    },

    { $skip: (page - 1) * limit },

    { $limit: limit }
  );

  const videos = await Video.aggregate(pipeline);

  return res
    .status(200)
    .json(new ApiResponse(200, videos, "Venue fetched successfully"));
});

const publishAVenue = asyncHandler(async (req, res) => {
  const { title, description,location } = req.body;
  
  const thumbnailLocalPath = req.files?.thumbnail[0].path;

  if (!thumbnailLocalPath) {
    throw new ApiError(400, "does not find venue path");
  }
  if (!title) {
    throw new ApiError(400, "title is missing");
  }
  if (!description) {
    throw new ApiError(400, "description is missing");
  }
  if(!location)
  {
    throw new ApiError(400, "location is missing");
  }
  //fetching thumbnail
 
  const thumbnail = await uploadOnCloudinary(thumbnailLocalPath);

  if (!thumbnail) {
    throw new ApiError(400, "thumbanil not found");
  }
 

  const newVenue = await Venue.create({

    image: thumbnail.url,
    title,
    description,
    menu,
  });
});

const getVenueById = asyncHandler(async (req, res) => {
  const { venueId } = req.params;
  const venue = Venue.findById(venueId);
  if (!venue) {
    throw new ApiError(400, "no venue found by id");
  }
  res
    .status(200)
    .json(new ApiResponse(200, venue, "venue fetched successfully "));
});

const updateVenue = asyncHandler(async (req, res) => {
  const { venueId } = req.params;
  //TODO: update video details like title, description, thumbnail
  const { title, description,location } = req.body;
  const thumbnailLocalPath = req.file?.path;
  if (!venueId?.trim()) {
    throw new ApiError(400, "no video id found");
  }
  const venue = Venue.findById(venueId);
  if (!venue) {
    throw new ApiError(400, "No videos exists");
  }

  if (!title || !description || !thumbnailLocalPath ||!location) {
    throw new ApiError(
      400,
      "Please give title or description or thumbnail or location to change"
    );
  }
  const thumbmail = await uploadOnCloudinary(thumbnailLocalPath);
  if (!thumbmail) {
    throw new ApiError(500, "There is some problem in uploading thumbnail");
  }

  const updatedVenue = await Venue.findByIdAndUpdate(
    venueId,
    {
      $set: {
        title,
        description,
        location,
        thumbnail: thumbmail.url,
      },
    },
    { new: true }
  );
  await destroyOnCloudinary(oldThumbnailUrl);

  return res
    .status(200)
    .json(new ApiResponse(200, updatedVenue, "Venue details updated"));
});

const deleteVenue = asyncHandler(async (req, res) => {
  const { venueId } = req.params;
  if (!isValidObjectId(venueId)) {
    throw new ApiError(400, "venue id is not valid while deleting the video");
  }
  const venue = Venue.findById(venueId);
  if (!venue) {
    throw new ApiError(400, "venue did not found while deleting the video");
  }

  const { _id, image, owner } = venue;
  if (req.user?._id?.toString() !== owner?._id?.toString()) {
    throw new ApiError(400, "unauthorized access");
  }
 

  if (!image) {
    throw new ApiError(400, "No thumbnail exists");
  }

  const response = await Venue.findByIdAndDelete(_id);
  if (!response) {
    throw new ApiError(400, "Delete action failed");
  }
  
  await destroyOnCloudinary(image);
  return res
    .status(200)
    .json(new ApiResponse(200, {}, "Video deleted successfully"));

});



export {
  getAllVenues,
  publishAVenue,
  getVenueById,
  updateVenue,
  deleteVenue,
 
};