import React from "react";
import { Link } from "react-router-dom";
import { IoSearchSharp } from "react-icons/io5";

const Header = () => {
  return (
    <div className="w-full h-[70px] bg-[#0d131bee] flex justify-between items-center p-4 fixed top-0 left-0 z-50">
      <div className="flex justify-center items-center gap-2">
        <img
          src="https://movix-app-murex.vercel.app/assets/movix-logo-HTlvmwAF.svg"
          alt="Movix Logo"
          className="h-8" // Adjust the size as needed
        />
        <Link
          to="/"
          className="bg-[#374151] hover:bg-blue-900 text-white rounded-full py-3 px-8 shadow-md hover:shadow-2xl transition duration-500 font-semibold font-mono"
        >
          D X T
        </Link>
      </div>
      <div className=" flex justify-center items-center gap-10">
        <div className="group relative">
          <div className="absolute -inset-1 rounded-lg bg-gradient-to-r from-rose-400 via-fuchsia-500 to-indigo-500 opacity-75 blur transition duration-500 group-hover:opacity-100"></div>
          <Link to="/tvShows">
            <button className="relative rounded-lg bg-black px-5 py-2 text-white">
              TV Show
            </button>
          </Link>
        </div>

        <div className="max-w-[95%] relative group">
          <div className="glowing-bg absolute -inset-0.5 bg-gradient-to-r from-green-600 via-yellow-600 to-blue-600 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-tilt"></div>
          <Link to="/movies">
            <button type="button" className="relative bg-black px-5 py-3 text-white rounded-md leading-none">
              Movies
            </button>
          </Link>
        </div>

        <div>
          <IoSearchSharp color="white" size={25} className="hover:scale-110 transition duration-200" />
        </div>
      </div>
    </div>
  );
};

export default Header;
