import React from 'react';
import Category from '../components/Category';
import Card from '../components/Card';
import CategoryList from './fetchList/FetchCategorgy';
import VenueList from './fetchList/FetchVenue';


const Home = () => {
  return (
    <div>
    <div className='flex flex-col justify-center items-center'>
      <h1>Category</h1>
      <CategoryList Component={Category}/>
    </div>
    <div className='flex flex-col justify-center items-center'>
      <h1>You Like these venues</h1>
      <VenueList Component={Card}/>
    </div>

    </div>
  );
};

export default Home;
