import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, Link } from 'react-router-dom';
import { registerUser } from '../Redux/Slices/userSlice';

const Register = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  
  const dispatch = useDispatch();
  const navigate = useNavigate(); // Initialize the useNavigate hook

  const { registerStatus, error } = useSelector((state) => state.user);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      alert('Passwords do not match!');
      return;
    }

    // Send form data without confirmPassword to the backend
    const { confirmPassword, ...backendData } = formData;
    dispatch(registerUser(backendData));
  };

  // Effect to navigate to login page after successful registration
  useEffect(() => {
    if (registerStatus === 'success') {
      navigate('/login'); // Navigate to the login page on success
    }
  }, [registerStatus, navigate]);

  return (
    <div className="antialiased bg-gray-200 text-gray-900 font-sans min-h-screen flex items-center justify-center">
      <div className="w-full bg-white rounded shadow-lg p-8 m-4 md:max-w-sm md:mx-auto">
        <span className="block w-full text-xl uppercase font-bold mb-4">Register</span>
        
        {registerStatus === 'failed' && <p className="text-red-600 mb-4">{error}</p>}
        
        <form className="mb-4" onSubmit={handleSubmit}>
          <div className="mb-4 md:w-full">
            <label htmlFor="fullName" className="block text-xs mb-1">Name</label>
            <input 
              className="w-full border rounded p-2 outline-none focus:shadow-outline" 
              type="text" 
              name="fullName" 
              id="fullName" 
              value={formData.fullName}
              onChange={handleChange}
              placeholder="Your Name" 
            />
          </div>

          <div className="mb-4 md:w-full">
            <label htmlFor="email" className="block text-xs mb-1">Email</label>
            <input 
              className="w-full border rounded p-2 outline-none focus:shadow-outline" 
              type="email" 
              name="email" 
              id="email" 
              value={formData.email}
              onChange={handleChange}
              placeholder="Email" 
            />
          </div>

          <div className="mb-4 md:w-full">
            <label htmlFor="password" className="block text-xs mb-1">Password</label>
            <input 
              className="w-full border rounded p-2 outline-none focus:shadow-outline" 
              type="password" 
              name="password" 
              id="password" 
              value={formData.password}
              onChange={handleChange}
              placeholder="Password" 
            />
          </div>

          <div className="mb-4 md:w-full">
            <label htmlFor="confirmPassword" className="block text-xs mb-1">Confirm Password</label>
            <input 
              className="w-full border rounded p-2 outline-none focus:shadow-outline" 
              type="password" 
              name="confirmPassword" 
              id="confirmPassword" 
              value={formData.confirmPassword}
              onChange={handleChange}
              placeholder="Confirm Password" 
            />
          </div>

          <button className="bg-green-500 hover:bg-green-700 text-white uppercase text-sm font-semibold px-4 py-2 rounded">
            Register
          </button>
          <p className='text-gray-700 p-2'>already have an account? <Link to="/login" className='text-blue-400 hover:underline'>login</Link></p>
        </form>
      </div>
    </div>
  );
};

export default Register;
