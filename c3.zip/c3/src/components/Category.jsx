import React from 'react'

const Category = ({data}) => {
    console.log(data)
  return (
    <div className='w-1/5 bg-slate-500 flex flex-col'>
        <img src={data.image} alt="" />
    </div>
  )
}

export default Category