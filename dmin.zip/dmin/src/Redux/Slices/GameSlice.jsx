import { createSlice } from "@reduxjs/toolkit";

const initialState=[]
 

export const gameSlice=createSlice({
    name:"game",
    initialState,
    reducers:{
        getAllGame:(state,action)=>{
            state.push(action.payload)
        },
        addGame:(state,action)=>{
            state.push(action.payload)
        },
        deleteGame:(state,action)=>{
         state.filter((game) => game.id !== action.payload);
        }
    }
})
 export const {addGame,deleteGame,getAllGame}=gameSlice.actions
 export default gameSlice.reducer

