import React from 'react';
import { useCart } from '../Context/CartContext';

const CartButtons = ({ id }) => {
  const { cart, addToCart, removeFromCart } = useCart();

  const item = cart.find((ele) => ele.id === id); // Use find instead of filter for a single item

  // If the item doesn't exist in the cart, you can return null or a message
  if (!item) {
    return null; // Or you can return a placeholder or message
  }

  return (
    <div className='flex justify-evenly items-center'>
      <button onClick={() => addToCart(item, "inc")} className='w-10 h-10 rounded-full bg-green-700 text-yellow-50'>+</button>
      <p className='w-10 h-10 rounded-full bg-gray-500 flex items-center justify-center text-yellow-50'>{item.quantity}</p>
      <button onClick={() => addToCart(item, "dec")} disabled={item.quantity === 1} className='w-10 h-10 rounded-full bg-green-700 text-yellow-50'>-</button>
      <button onClick={() => removeFromCart(item.id)} className='w-10 h-10 rounded-full bg-red-400 text-yellow-50'>X</button>
    </div>
  );
}

export default CartButtons;
