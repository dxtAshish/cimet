import Avatar from "./component/Avatar"
import AvatarCircle from "./component/AvatarCircle"
import Modal from "./component/Modal"



function App() {

  return (
    <>
    <Avatar/>
    {/* <AvatarCircle/> */}
    {/* <Modal/>  */}
    </>
  )
}

export default App
