import axios from 'axios';

const token = localStorage.getItem("TOKEN");

export const API = axios.create({
  baseURL: `http://localhost:5001/`,
  timeout: 10000,
  headers: {
    common: {
      'Content-Type': 'application/json',
      'Authorization': token ? `Bearer ${token}` : null
    }
  }
});

export const setToken = (token) => {
  API.defaults.headers.common['Authorization'] = `Bearer ${token}`;
}