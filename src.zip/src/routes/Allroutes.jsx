

const Allroutes = () => {
  return (
    <div>
      
    </div>
  )
}

export default Allroutes
