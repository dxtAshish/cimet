import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const DashboardTable = ({ columns, data, actions }) => {
  return (
    <div className="flex">
      <div className="flex-1 overflow-x-auto">
        <table className="min-w-full table-fixed bg-white border border-gray-200 rounded-lg shadow-lg">
          <thead className="sticky top-0 bg-yellow-800 text-white z-10">
            <tr>
              {columns.map((column) => (
                <th
                  key={column.key}
                  className="w-1/5 px-4 py-3 text-left text-xs sm:text-sm font-semibold border-b border-gray-200 uppercase tracking-wider"
                >
                  {column.header}
                </th>
              ))}
              {actions && (
                <th className="w-1/5 px-4 py-3 text-left text-xs sm:text-sm font-semibold border-b border-gray-200 uppercase tracking-wider">
                  Actions
                </th>
              )}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-100">
            {data.map((row, rowIndex) => (
              <tr
                key={rowIndex}
                className="hover:bg-yellow-100 transition-colors duration-200"
              >
                {columns.map((column) => (
                  <td
                    key={column.key}
                    className="w-1/5 px-4 sm:px-6 py-4 whitespace-normal text-gray-700 text-xs sm:text-sm font-medium"
                  >
                    {column.render
                      ? column.render(row[column.key], row)
                      : row[column.key]}
                  </td>
                ))}
                {actions && (
                  <td className="w-1/5 px-4 sm:px-6 py-4 whitespace-normal text-center text-xs sm:text-sm">
                    {actions.map((action, actionIndex) => (
                      <button
                        key={actionIndex}
                        onClick={() => action.onClick(row)}
                        className={`mx-1 px-2 sm:px-3 py-1 sm:py-2 rounded-full bg-red-100 hover:bg-red-200 text-red-700 transition-colors duration-200 ${action.className}`}
                      >
                        <FontAwesomeIcon icon={action.icon} />
                      </button>
                    ))}
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DashboardTable;
