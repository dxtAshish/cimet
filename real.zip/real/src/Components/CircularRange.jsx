import React from 'react';


const getColorForValue = (value) => {
    const hue = (value / 10) * 120; 
    return `hsl(${hue}, 100%, 50%)`;
  };
  

const CircularRange = ({ value }) => {
 
  const percentage = (value / 10) * 100;


  const dynamicColor = getColorForValue(value);

  return (
    <div className="relative w-16 h-16 flex items-center justify-center">
      <div
        className="absolute top-0 left-0 w-full h-full rounded-full"
        style={{
          background: `conic-gradient(${dynamicColor} ${percentage}%, #e2e8f0 ${percentage}%)`,
        }}
      ></div>
      <div className="flex items-center justify-center absolute w-14 h-14 bg-white rounded-full">
        <span className="text-lg font-bold text-gray-800">{value}</span>
      </div>
    </div>
  );
};

export default CircularRange;
