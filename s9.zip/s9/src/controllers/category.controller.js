import mongoose from "mongoose";
import { Category } from "../models/category.models.js";
import { ApiError } from "../utils/APIErrors.js";
import { ApiResponse } from "../utils/ApiResponse.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { uploadOnCloudinary } from "../utils/Cloudinary.js";

const getAllCategory = asyncHandler(async (req, res) => {
  const { page = 1, limit = 10 } = req.query;

  const aggregateQuery = Category.aggregate([{ $match: {} }]);

  const categories = await Category.aggregatePaginate(aggregateQuery, {
    page: parseInt(page, 10),
    limit: parseInt(limit, 10),
  });

  if (!categories.docs.length) {
    throw new ApiError(404, "No categories found");
  }

  res
    .status(200)
    .json(new ApiResponse(200, "Categories fetched successfully", categories));
});

const addCategory = asyncHandler(async (req, res) => {
  const { dishName } = req.body;
  // console.log(req.body);
  const thumbnailLocalPath = req.files?.thumbnail?.[0]?.path;
  // console.log(dishName,  "both");
  if (!dishName) {
    throw new ApiError(400, "Category dishName is required");
  }

  if (!thumbnailLocalPath) {
    throw new ApiError(400, "Category image is required");
  }

  const thumbnail = await uploadOnCloudinary(thumbnailLocalPath);

  if (!thumbnail) {
    throw new ApiError(400, "Image upload failed");
  }

  const newCategory = await Category.create({
    dishName,
    thumbnail: thumbnail.url,
  });

  res
    .status(201)
    .json(new ApiResponse(201, "Category created successfully", newCategory));
});

const editCategory = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { title } = req.body;
  const imageLocalPath = req.files?.image[0]?.path;

  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, "Invalid category ID");
  }

  const category = await Category.findById(id);
  if (!category) {
    throw new ApiError(404, "Category not found");
  }

  if (imageLocalPath) {
    const image = await uploadOnCloudinary(imageLocalPath);
    if (!image) {
      throw new ApiError(400, "Image upload failed");
    }
    category.image = image.url;
  }

  category.title = title || category.title;

  const updatedCategory = await category.save();
  res
    .status(200)
    .json(
      new ApiResponse(200, "Category updated successfully", updatedCategory)
    );
});

const deleteCategory = asyncHandler(async (req, res) => {
  const { id } = req.params;

  // Validate the category ID
  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, "Invalid category ID");
  }

  // Find the category by ID
  const category = await Category.findById(id);
  if (!category) {
    throw new ApiError(404, "Category not found");
  }

  // Remove the category using deleteOne
  await Category.deleteOne({ _id: id }); // Corrected method

  // Respond with success
  res.status(200).json(new ApiResponse(200, "Category deleted successfully"));
});


export { getAllCategory, addCategory, editCategory, deleteCategory };
