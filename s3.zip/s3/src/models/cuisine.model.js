import mongoose, { Schema } from "mongoose";
import mongooseAggregatePaginate from "mongoose-aggregate-paginate-v2";
const cuisineSchema = new Schema(
  {

    title: {
      type: String,
      required: true,
    },
    image: {
        type: String,
        required: true,
      },
     
    description: {
      type: String,
      required: true,
    },
      price: {
      type: Number,
      required: true,
    },
    venue:{
        type:Schema.Types.ObjectId,
        ref:"Venue"
    },
    category:{
      type:Schema.Types.ObjectId,
      ref:"Category"
    }
  },
  {
    timestamps: true,
  }
);
cuisineSchema.plugin(mongooseAggregatePaginate);
export const Video = mongoose.model("Cuisine", cuisineSchema);