import express from "express"
import cors from "cors"
import cookieParser from "cookie-parser"
import userRouter from "./routes/user.routes.js"
const app=express()
app.use(cors({
    // origin: "*",
    credential:true
}))
app.use(express.json({limit:"16kb"}))
app.use(express.urlencoded({extended:true,limit:"16kb"}))
app.use(express.static("public"))
app.use(cookieParser())

app.use("/api/v1/users",userRouter)
// app.use("/api/v1/cuisine",commentRouter)
// app.use("/api/v1/venue",videoRouter)
// app.use("/api/v1/category",playlistRouter)
export {app}