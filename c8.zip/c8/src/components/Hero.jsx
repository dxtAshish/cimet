import React from 'react';
import welcome from "../assests/welcome.png";
import CustomButton from './CustomButtons';

const Hero = () => {
    return (
        <div className="bg-yellow-400 min-h-[50vh] flex items-center">
            <div className="container mx-auto px-4">
                <div className="flex justify-center items-center gap-20  md:text-center md:gap-10">
                    {/* Left Section */}
                    <div className="flex-1">
                        <p className="text-lg text-gray-500 font-medium mt-5 mb-4">
                            Welcome to Hungry Restaurant
                        </p>
                        <h1 className="text-5xl text-white font-bold mb-6 md:text-4xl">
                            Discover a place where you'll love to Eat.
                        </h1>
                        <p className="text-lg text-gray-600 mb-6 md:text-base">
                            Immerse yourself in the elegant ambiance as you savor each bite, accompanied by our extensive selection of hand-picked wines and carefully curated cocktails.
                        </p>
                        <CustomButton
                            backgroundColor="#0F1B4C"
                            color="#fff"
                            buttonText="More About Us"
                            welcomeBtn={true}
                        />
                    </div>

                    {/* Right Section */}
                    <div className="flex-[1.25]">
                        <img
                            src={welcome}
                            alt="welcome"
                            className="max-w-full h-auto mb-8 md:max-w-[80%]"
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Hero;
